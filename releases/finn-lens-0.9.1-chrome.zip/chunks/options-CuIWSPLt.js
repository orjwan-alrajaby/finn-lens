import{n as e}from"./rolldown-runtime-CbXtAM7H.js";import{A as t,D as n,E as r,M as i,_ as a,g as o,i as s,j as c,k as l,n as u,r as d,t as f,u as p,v as m,w as h,y as g}from"./store-BJo-hvPI.js";import{Rt as ee,n as te,t as ne,x as re,zt as _}from"./ImportanceKey-Co3qN_tR.js";import{t as ie}from"./download-DWi37lrD.js";import{n as ae,r as oe,t as se}from"./trash-KjL4Rdbs.js";import{n as ce,t as le}from"./constants-JoR4GXEO.js";import{t as ue}from"./brand-spinner-vMG1tQqO.js";var de=t(`book-open`,[[`path`,{d:`M12 5v16`,key:`1f6ucr`}],[`path`,{d:`M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z`,key:`1fyvmf`}]]),fe=t(`car-front`,[[`path`,{d:`m21 8-2 2-1.5-3.7A2 2 0 0 0 15.646 5H8.4a2 2 0 0 0-1.903 1.257L5 10 3 8`,key:`1imjwt`}],[`path`,{d:`M7 14h.01`,key:`1qa3f1`}],[`path`,{d:`M17 14h.01`,key:`7oqj8z`}],[`rect`,{width:`18`,height:`8`,x:`3`,y:`10`,rx:`2`,key:`a7itu8`}],[`path`,{d:`M5 18v2`,key:`ppbyun`}],[`path`,{d:`M19 18v2`,key:`gy7782`}]]),pe=t(`chevron-left`,[[`path`,{d:`m15 18-6-6 6-6`,key:`1wnfg3`}]]),me=t(`circle-check`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`path`,{d:`m16 9-5.5 5.5L8 12`,key:`xofnsj`}]]),he=t(`compass`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`path`,{d:`m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z`,key:`9ktpf1`}]]),ge=t(`database`,[[`ellipse`,{cx:`12`,cy:`5`,rx:`9`,ry:`3`,key:`msslwz`}],[`path`,{d:`M3 5V19A9 3 0 0 0 21 19V5`,key:`1wlel7`}],[`path`,{d:`M3 12A9 3 0 0 0 21 12`,key:`mv7ke4`}]]),_e=t(`file-text`,[[`path`,{d:`M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z`,key:`1oefj6`}],[`path`,{d:`M14 2v5a1 1 0 0 0 1 1h5`,key:`wfsgrz`}],[`path`,{d:`M10 9H8`,key:`b1mrlr`}],[`path`,{d:`M16 13H8`,key:`t4e002`}],[`path`,{d:`M16 17H8`,key:`z1uh3a`}]]),ve=t(`flask-conical`,[[`path`,{d:`M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2`,key:`18mbvz`}],[`path`,{d:`M6.453 15h11.094`,key:`3shlmq`}],[`path`,{d:`M8.5 2h7`,key:`csnxdl`}]]),ye=t(`hammer`,[[`path`,{d:`m15 12-9.373 9.373a1 1 0 0 1-3.001-3L12 9`,key:`1hayfq`}],[`path`,{d:`m18 15 4-4`,key:`16gjal`}],[`path`,{d:`m21.5 11.5-1.914-1.914A2 2 0 0 1 19 8.172v-.344a2 2 0 0 0-.586-1.414l-1.657-1.657A6 6 0 0 0 12.516 3H9l1.243 1.243A6 6 0 0 1 12 8.485V10l2 2h1.172a2 2 0 0 1 1.414.586L18.5 14.5`,key:`15ts47`}]]),be=t(`lightbulb`,[[`path`,{d:`M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5`,key:`1gvzjb`}],[`path`,{d:`M9 18h6`,key:`x1upvd`}],[`path`,{d:`M10 22h4`,key:`ceow96`}]]),xe=t(`list-checks`,[[`path`,{d:`M13 5h8`,key:`a7qcls`}],[`path`,{d:`M13 12h8`,key:`h98zly`}],[`path`,{d:`M13 19h8`,key:`c3s6r1`}],[`path`,{d:`m3 17 2 2 4-4`,key:`1jhpwq`}],[`path`,{d:`m3 7 2 2 4-4`,key:`1obspn`}]]),Se=t(`message-square-text`,[[`path`,{d:`M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z`,key:`18887p`}],[`path`,{d:`M7 11h10`,key:`1twpyw`}],[`path`,{d:`M7 15h6`,key:`d9of3u`}],[`path`,{d:`M7 7h8`,key:`af5zfr`}]]),Ce=t(`monitor-play`,[[`path`,{d:`M15.033 9.44a.647.647 0 0 1 0 1.12l-4.065 2.352a.645.645 0 0 1-.968-.56V7.648a.645.645 0 0 1 .967-.56z`,key:`vbtd3f`}],[`path`,{d:`M12 17v4`,key:`1riwvh`}],[`path`,{d:`M8 21h8`,key:`1ev6f3`}],[`rect`,{x:`2`,y:`3`,width:`20`,height:`14`,rx:`2`,key:`x3v2xh`}]]),we=t(`rotate-ccw`,[[`path`,{d:`M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8`,key:`1357e3`}],[`path`,{d:`M3 3v5h5`,key:`1xhq8a`}]]),Te=t(`scale`,[[`path`,{d:`M12 3v18`,key:`108xh3`}],[`path`,{d:`m19 8 3 8a5 5 0 0 1-6 0zV7`,key:`zcdpyk`}],[`path`,{d:`M3 7h1a17 17 0 0 0 8-2 17 17 0 0 0 8 2h1`,key:`1yorad`}],[`path`,{d:`m5 8 3 8a5 5 0 0 1-6 0zV7`,key:`eua70x`}],[`path`,{d:`M7 21h10`,key:`1b0cd5`}]]),Ee=t(`sliders-horizontal`,[[`path`,{d:`M10 5H3`,key:`1qgfaw`}],[`path`,{d:`M12 19H3`,key:`yhmn1j`}],[`path`,{d:`M14 3v4`,key:`1sua03`}],[`path`,{d:`M16 17v4`,key:`1q0r14`}],[`path`,{d:`M21 12h-9`,key:`1o4lsq`}],[`path`,{d:`M21 19h-5`,key:`1rlt1p`}],[`path`,{d:`M21 5h-7`,key:`1oszz2`}],[`path`,{d:`M8 10v4`,key:`tgpxqk`}],[`path`,{d:`M8 12H3`,key:`a7s4jb`}]]),De=t(`telescope`,[[`path`,{d:`m10.065 12.493-6.18 1.318a.934.934 0 0 1-1.108-.702l-.537-2.15a1.07 1.07 0 0 1 .691-1.265l13.504-4.44`,key:`k4qptu`}],[`path`,{d:`m13.56 11.747 4.332-.924`,key:`19l80z`}],[`path`,{d:`m16 21-3.105-6.21`,key:`7oh9d`}],[`path`,{d:`M16.485 5.94a2 2 0 0 1 1.455-2.425l1.09-.272a1 1 0 0 1 1.212.727l1.515 6.06a1 1 0 0 1-.727 1.213l-1.09.272a2 2 0 0 1-2.425-1.455z`,key:`m7xp4m`}],[`path`,{d:`m6.158 8.633 1.114 4.456`,key:`74o979`}],[`path`,{d:`m8 21 3.105-6.21`,key:`1fvxut`}],[`circle`,{cx:`12`,cy:`13`,r:`2`,key:`1c1ljs`}]]),Oe=t(`users`,[[`path`,{d:`M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2`,key:`1yyitq`}],[`path`,{d:`M16 3.128a4 4 0 0 1 0 7.744`,key:`16gr8j`}],[`path`,{d:`M22 21v-2a4 4 0 0 0-3-3.87`,key:`kshegd`}],[`circle`,{cx:`9`,cy:`7`,r:`4`,key:`nufk8`}]]),ke=t(`zoom-out`,[[`circle`,{cx:`11`,cy:`11`,r:`8`,key:`4ej97u`}],[`line`,{x1:`21`,x2:`16.65`,y1:`21`,y2:`16.65`,key:`13gj7c`}],[`line`,{x1:`8`,x2:`14`,y1:`11`,y2:`11`,key:`durymu`}]]),Ae=t(`zoom-in`,[[`circle`,{cx:`11`,cy:`11`,r:`8`,key:`4ej97u`}],[`line`,{x1:`21`,x2:`16.65`,y1:`21`,y2:`16.65`,key:`13gj7c`}],[`line`,{x1:`11`,x2:`11`,y1:`8`,y2:`14`,key:`1vmskp`}],[`line`,{x1:`8`,x2:`14`,y1:`11`,y2:`11`,key:`durymu`}]]),v=e(i(),1),je=e(c(),1),y=[{id:`chats`,title:`Your chats`,description:`Every conversation with Lens, and the judgement each one made. The chips on finn.com come from these.`,keys:[u,f],consequence:`Every chat goes, and the chips come off finn.com's cards.`},{id:`settings`,title:`Your saved answers`,description:`The answers you asked Lens to keep, so new chats start from them.`,keys:[s],consequence:`New chats will ask you everything again. Existing chats keep their own answers.`},{id:`cars`,title:`Cars Lens has read`,description:`FINN's details for the cars you've browsed past — prices, equipment, emissions — kept so Lens doesn't ask FINN twice.`,keys:[`loadedCarsFromFinnApi`],consequence:`Lens reads the cars again from FINN as you browse. Chats judged on cars it no longer holds will say so.`},{id:`preferences`,title:`Small things Lens remembers`,description:`The size you dragged the chat to, and a pending request to open the bubble.`,keys:[`finnLensChatSize`,d],consequence:`The chat opens at its usual size.`},{id:`leftovers`,title:`From an earlier version of Lens`,description:`Pinned cars, priorities, profiles and conversations kept by the version of Lens before the chat. Nothing reads them any more.`,keys:[`pinnedCars`,`finnLensPreferences`,`finnLensPriorities`,`finnLensPriorityDefinitions`,`finnLensProfiles`,`finnLensCategoryFeatures`,`finnLensDefaultProfileId`,`finnLensBasedOn`,`finnLensSession`,`finnLensSessionHandOff`,`finnLensSavedSearches`,`finnLensJudgeBy`,`finnLensChatTranscript`,`finnLensOnboarding`,`finnLensAi`,`finnLensAiResting`,`lensAi`],consequence:`Nothing changes in how Lens works; this is only clearing out.`}];async function Me(){let e=await n.storage.local.get(null),t=Object.values(e.finnLensChats??{}),r=e.loadedCarsFromFinnApi?.cars??{};return{present:y.filter(t=>t.keys.some(t=>t in e)).map(e=>e.id),chats:t.length,judged:t.filter(e=>e.judgement).length,hasSettings:!!e[s],cars:Object.keys(r).length,kilobytes:Math.round(new Blob([JSON.stringify(e)]).size/1024)}}async function Ne(e){let t=y.filter(t=>e.includes(t.id)).flatMap(e=>e.keys);await n.storage.local.remove(t)}var b=r();function x({id:e,icon:t,title:n,subtitle:r,children:i}){return(0,b.jsxs)(`section`,{id:e,className:`scroll-mt-6 rounded-[28px] bg-white/60 p-6 ring-1 ring-black/5`,children:[(0,b.jsxs)(`div`,{className:`mb-4 flex items-center gap-3`,children:[(0,b.jsx)(`span`,{className:`flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-finn-pale-blue text-finn-accent-blue`,children:t}),(0,b.jsxs)(`div`,{children:[(0,b.jsx)(`h2`,{className:`text-[17px] font-black leading-tight`,children:n}),r?(0,b.jsx)(`p`,{className:`mt-0.5 text-[12.5px] text-finn-iron`,children:r}):null]})]}),i]})}function Pe(){return{async:!1,breaks:!1,extensions:null,gfm:!0,hooks:null,pedantic:!1,renderer:null,silent:!1,tokenizer:null,walkTokens:null}}var S=Pe();function Fe(e){S=e}var C={exec:()=>null};function w(e){let t=[];return n=>{let r=Math.max(0,Math.min(3,n-1)),i=t[r];return i||(i=e(r),t[r]=i),i}}function T(e,t=``){let n=typeof e==`string`?e:e.source,r={replace:(e,t)=>{let i=typeof t==`string`?t:t.source;return i=i.replace(E.caret,`$1`),n=n.replace(e,i),r},getRegex:()=>new RegExp(n,t)};return r}var Ie=((e=``)=>{try{return!!RegExp(`(?<=1)(?<!1)`+e)}catch{return!1}})(),E={codeRemoveIndent:/^(?: {0,3}\t| {1,4})/gm,outputLinkReplace:/\\([\[\]])/g,indentCodeCompensation:/^(\s+)(?:```)/,beginningSpace:/^\s+/,endingHash:/#$/,startingSpaceChar:/^ /,endingSpaceChar:/ $/,endingSpaceTabChar:/[ \t]$/,nonSpaceChar:/[^ ]/,newLineCharGlobal:/\n/g,tabCharGlobal:/\t/g,leadingSpaceTab:/^[ \t]+/,multipleSpaceGlobal:/\s+/g,blankLine:/^[ \t]*$/,doubleBlankLine:/\n[ \t]*\n[ \t]*$/,blockquoteStart:/^ {0,3}>/,blockquoteSetextReplace:/\n {0,3}((?:=+|-+) *)(?=\n|$)/g,blockquoteSetextReplace2:/^ {0,3}>[ \t]?/gm,listReplaceNesting:/^ {1,4}(?=( {4})*[^ ])/g,listIsTask:/^\[[ xX]\] +\S/,listReplaceTask:/^\[[ xX]\] +/,listTaskCheckbox:/\[[ xX]\]/,anyLine:/\n.*\n/,hrefBrackets:/^<(.*)>$/,tableDelimiter:/[:|]/,tableAlignChars:/^\||\| *$/g,tableRowBlankLine:/\n[ \t]*$/,tableAlignRight:/^ *-+: *$/,tableAlignCenter:/^ *:-+: *$/,tableAlignLeft:/^ *:-+ *$/,startATag:/^<a /i,endATag:/^<\/a>/i,startPreScriptTag:/^<(pre|code|kbd|script)(\s|>)/i,endPreScriptTag:/^<\/(pre|code|kbd|script)(\s|>)/i,startAngleBracket:/^</,endAngleBracket:/>$/,pedanticHrefTitle:/^([^'"]*[^\s])\s+(['"])(.*)\2/,unicodeAlphaNumeric:/[\p{L}\p{N}]/u,numericCharacterReference:/&#(?:(\d{1,7})|[Xx]([A-Fa-f0-9]{1,6}));/,numericCharacterReferenceOrAmpersand:/&#(?:(\d{1,7})|[Xx]([A-Fa-f0-9]{1,6}));|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,escapeTest:/[&<>"']/,escapeReplace:/[&<>"']/g,escapeTestNoEncode:/[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,escapeReplaceNoEncode:/[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,caret:/(^|[^\[])\^/g,percentDecode:/%25/g,findPipe:/\|/g,splitPipe:/ \|/,slashPipe:/\\\|/g,carriageReturn:/\r\n|\r/g,spaceLine:/^ +$/gm,notSpaceStart:/^\S*/,endingNewline:/\n$/,listItemRegex:e=>RegExp(`^( {0,3}${e})((?:[	 ][^\\n]*)?(?:\\n|$))`),nextBulletRegex:w(e=>RegExp(`^ {0,${e}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`)),hrRegex:w(e=>RegExp(`^ {0,${e}}((?:-[ 	]*){3,}|(?:_[ 	]*){3,}|(?:\\*[ 	]*){3,})(?:\\n+|$)`)),fencesBeginRegex:w(e=>RegExp(`^ {0,${e}}(?:\`\`\`|~~~)`)),headingBeginRegex:w(e=>RegExp(`^ {0,${e}}#`)),htmlBeginRegex:w(e=>RegExp(`^ {0,${e}}(?:</?(?:${O})(?: +|$|/?>)|<(?:(?:script|pre|style|textarea)(?:[\\s>]|$)|!--)|<\\?|<![A-Za-z]|<!\\[CDATA\\[)`,`i`)),blockquoteBeginRegex:w(e=>RegExp(`^ {0,${e}}>`))},Le=/^(?:[ \t]*(?:\n|$))+/,Re=/^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/,ze=/^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/,D=/^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/,Be=/^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/,Ve=/ {0,3}(?:[*+-]|\d{1,9}[.)])/,He=/^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |fences|blockquote|heading|hr|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/,Ue=T(He).replace(/bull/g,Ve).replace(/blockCode/g,/(?: {4}| {0,3}\t)/).replace(/fences/g,/ {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g,/ {0,3}>/).replace(/heading/g,/ {0,3}#{1,6}(?:\s|$)/).replace(/hr/g,/ {0,3}(?:(?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/).replace(/html/g,/ {0,3}<[^\n>]+>\n/).replace(/\|table/g,``).getRegex(),We=T(He).replace(/bull/g,Ve).replace(/blockCode/g,/(?: {4}| {0,3}\t)/).replace(/fences/g,/ {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g,/ {0,3}>/).replace(/heading/g,/ {0,3}#{1,6}(?:\s|$)/).replace(/hr/g,/ {0,3}(?:(?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/).replace(/html/g,/ {0,3}<[^\n>]+>\n/).replace(/table/g,/ {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(),Ge=/^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table|[ \t]+\n)[^\n]+)*)/,Ke=/^[^\n]+/,qe=/(?!\s*\])(?:\\[\s\S]|[^\[\]\\])+/,Je=T(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace(`label`,qe).replace(`title`,/(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(),Ye=T(/^(bull)([ \t][^\n]*?)?(?:\n|$)/).replace(/bull/g,Ve).getRegex(),O=`address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul`,Xe=/<!--(?:-?>|[\s\S]*?(?:-->|$))/,Ze=T(`^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n*|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>[^\\n]*\\n*|$)|<![A-Z][\\s\\S]*?(?:>[^\\n]*\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>[^\\n]*\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!(?:script|pre|style|textarea)(?![a-z0-9-]))([a-z][a-z0-9-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</[a-z][a-z0-9-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))`,`i`).replace(`comment`,Xe).replace(`tag`,O).replace(`attribute`,/ +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(),Qe=e=>T(Ge).replace(`hr`,D).replace(`heading`,` {0,3}#{1,6}(?:\\s|$)`).replace(`|lheading`,``).replace(`|table`,``).replace(`blockquote`,` {0,3}>`).replace(`fences`," {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)").replace(`list`,e).replace(`html`,` {0,3}(?:</?(?:tag)(?: +|\\n|/?>)|<(?:(?:script|pre|style|textarea)(?:[\\s>]|$)|!--)|<\\?|<![A-Za-z]|<!\\[CDATA\\[)`).replace(`tag`,O).getRegex(),$e=Qe(/ {0,3}(?:[*+-]|1[.)])[ \t]+[^ \t\n]/),et=Qe(/ {0,3}(?:[*+-]|\d{1,9}[.)])(?:[ \t]|\n|$)/),tt={blockquote:T(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace(`paragraph`,et).getRegex(),code:Re,def:Je,fences:ze,heading:Be,hr:D,html:Ze,lheading:Ue,list:Ye,newline:Le,paragraph:$e,table:C,text:Ke},nt=T(`^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)`).replace(`hr`,D).replace(`heading`,` {0,3}#{1,6}(?:\\s|$)`).replace(`blockquote`,` {0,3}>`).replace(`code`,`(?: {4}| {0,3}	)[^\\n]`).replace(`fences`," {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)").replace(`list`,` {0,3}(?:[*+-]|1[.)])[ \\t]`).replace(`html`,` {0,3}(?:</?(?:tag)(?: +|\\n|/?>)|<(?:(?:script|pre|style|textarea)(?:[\\s>]|$)|!--)|<\\?|<![A-Za-z]|<!\\[CDATA\\[)`).replace(`tag`,O).getRegex(),rt={...tt,lheading:We,table:nt,paragraph:T(Ge).replace(`hr`,D).replace(`heading`,` {0,3}#{1,6}(?:\\s|$)`).replace(`|lheading`,``).replace(`table`,nt).replace(`blockquote`,` {0,3}>`).replace(`fences`," {0,3}(?:`{3,}(?=[^`\\n]*(?:\\n|$))|~~~)[^\\n]*(?:\\n|$)").replace(`list`,` {0,3}(?:[*+-]|1[.)])[ \\t]+[^ \\t\\n]`).replace(`html`,` {0,3}(?:</?(?:tag)(?: +|\\n|/?>)|<(?:(?:script|pre|style|textarea)(?:[\\s>]|$)|!--)|<\\?|<![A-Za-z]|<!\\[CDATA\\[)`).replace(`tag`,O).getRegex()},it={...tt,html:T(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace(`comment`,Xe).replace(/tag/g,`(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b`).getRegex(),def:/^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,heading:/^(#{1,6})(.*)(?:\n+|$)/,fences:C,lheading:/^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,paragraph:T(Ge).replace(`hr`,D).replace(`heading`,` *#{1,6} *[^
]`).replace(`lheading`,Ue).replace(`|table`,``).replace(`blockquote`,` {0,3}>`).replace(`|fences`,``).replace(`|list`,``).replace(`|html`,``).replace(`|tag`,``).getRegex()},at=/^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/,ot=/^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/,st=/^( {2,}|\\)\n(?!\s*$)[ \t]*/,ct=/^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/,k=/[\p{P}\p{S}]/u,A=/[\s\p{P}\p{S}]/u,j=/[^\s\p{P}\p{S}]/u,lt=T(/^((?![*_])punctSpace)/,`u`).replace(/punctSpace/g,A).getRegex(),ut=/[\p{Pi}\p{Ps}"']/u,dt=/(?!~)[\p{P}\p{S}]/u,ft=/(?!~)[\s\p{P}\p{S}]/u,pt=/(?:[^\s\p{P}\p{S}]|~)/u,mt=T(/link|precode-code|html/,`g`).replace(`link`,/\[(?:[^\[\]`]|(?<a>`+)[^`]+\k<a>(?!`))*?\]\((?:\\[\s\S]|[^\\\(\)]|\((?:\\[\s\S]|[^\\\(\)])*\))*\)/).replace(`precode-`,Ie?"(?<!`)()":"(^^|[^`])").replace(`code`,/(?<b>`+)[^`]+\k<b>(?!`)/).replace(`html`,/<(?! )[^<>]*?>/).getRegex(),ht=/^(?:\*+(?:((?!\*)punct)|([^\s*]))?)|^_+(?:((?!_)punct)|([^\s_]))?/,gt=T(ht,`u`).replace(/punct/g,k).getRegex(),_t=T(ht,`u`).replace(/punct/g,dt).getRegex(),vt=T(/^(?:\*+(?:((?!\*)(?!openQuote)punct)|([^\s*]))?)|^_+(?:((?!_)(?!openQuote)punct)|([^\s_]))?/,`u`).replace(/openQuote/g,ut).replace(/punct/g,k).getRegex(),yt=`^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)`,bt=T(yt,`gu`).replace(/notPunctSpace/g,j).replace(/punctSpace/g,A).replace(/punct/g,k).getRegex(),xt=T(yt,`gu`).replace(/notPunctSpace/g,pt).replace(/punctSpace/g,ft).replace(/punct/g,dt).getRegex(),St=T(`^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)[\\s](\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|(?:(?!\\*)punct|notPunctSpace)(\\*+)(?!\\*)(?=notPunctSpace)`,`gu`).replace(/notPunctSpace/g,j).replace(/punctSpace/g,A).replace(/punct/g,k).getRegex(),Ct=T(`^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)`,`gu`).replace(/notPunctSpace/g,j).replace(/punctSpace/g,A).replace(/punct/g,k).getRegex(),wt=T(`^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)[\\s](_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)|(?:(?!_)punct|notPunctSpace)(_+)(?!_)(?=notPunctSpace)`,`gu`).replace(/notPunctSpace/g,j).replace(/punctSpace/g,A).replace(/punct/g,k).getRegex(),Tt=T(/^~~?(?:((?!~)punct)|[^\s~])/,`u`).replace(/punct/g,k).getRegex(),Et=T(`^[^~]+(?=[^~])|(?!~)punct(~~?)(?=[\\s]|$)|notPunctSpace(~~?)(?!~)(?=punctSpace|$)|(?!~)punctSpace(~~?)(?=notPunctSpace)|[\\s](~~?)(?!~)(?=punct)|(?!~)punct(~~?)(?!~)(?=punct)|notPunctSpace(~~?)(?=notPunctSpace)`,`gu`).replace(/notPunctSpace/g,j).replace(/punctSpace/g,A).replace(/punct/g,k).getRegex(),Dt=T(/\\(punct)/,`gu`).replace(/punct/g,k).getRegex(),Ot=T(/(`+)(?:[^`]|[^`][\s\S]*?[^`])\1(?!`)|`+|\\(punct)/,`gu`).replace(/punct/g,k).getRegex(),kt=T(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace(`scheme`,/[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace(`email`,/[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(),At=T(Xe).replace(`(?:-->|$)`,`-->`).getRegex(),jt=T(`^comment|^</[a-zA-Z][a-zA-Z0-9-]*\\s*>|^<[a-zA-Z][a-zA-Z0-9-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>`).replace(`comment`,At).replace(`attribute`,/\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(),Mt=/\[(?:\\[\s\S]|[^\[\]\\])*\]/,Nt=T(/(?:\[(?:brackets|\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+(?!`)[^`]*?`+(?!`)|``+(?=\])|[^\[\]\\`])*?/).replace(`brackets`,Mt).getRegex(),Pt=T(/^!?\[(label)\]\([ \t\n]*(href)(?:(?:[ \t]+(?:\n[ \t]*)?|\n[ \t]*)(title))?[ \t\n]*\)/).replace(`label`,Nt).replace(`href`,/<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]+|(?=\))/).replace(`title`,/"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(),Ft=T(/^!?\[(label)\]\[(ref)\]/).replace(`label`,Nt).replace(`ref`,qe).getRegex(),It=T(/^!?\[(ref)\](?:\[\])?/).replace(`ref`,qe).getRegex(),Lt=/(?!\s*\])(?:\\[\s\S]|[^\[\]\\]){1,999}/,Rt=T(/(?:[^\[\]\\`]*(?:\[(?:brackets|\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+(?!`)[^`]*?`+(?!`)|``+(?=\]))){0,999}?[^\[\]\\`]*?/).replace(`brackets`,Mt).getRegex(),zt=T(`reflink|nolink(?!\\()`,`g`).replace(`reflink`,T(/^!?\[(label)\]\[(ref)\]/).replace(`label`,Rt).replace(`ref`,Lt).getRegex()).replace(`nolink`,T(/^!?\[(ref)\](?:\[\])?/).replace(`ref`,Lt).getRegex()).getRegex(),Bt=/[hH][tT][tT][pP][sS]?|[fF][tT][pP]/,Vt=T(/(?:mailto:email|xmpp:email(?:\/[A-Za-z0-9@.]+)?)/).replace(/email/g,/[A-Za-z0-9._+-]+@[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![\w-])/).getRegex(),Ht={_backpedal:C,anyPunctuation:Dt,anyPunctuationOutsideCode:Ot,autolink:kt,blockSkip:mt,br:st,code:ot,del:C,delLDelim:C,delRDelim:C,emStrongLDelim:gt,emStrongRDelimAst:bt,emStrongRDelimUnd:Ct,escape:at,link:Pt,nolink:It,punctuation:lt,reflink:Ft,reflinkSearch:zt,tag:jt,text:ct,url:C},Ut={...Ht,emStrongLDelim:vt,emStrongRDelimAst:St,emStrongRDelimUnd:wt,link:T(/^!?\[(label)\]\((.*?)\)/).replace(`label`,Nt).getRegex(),reflink:T(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace(`label`,Nt).getRegex()},Wt={...Ht,emStrongRDelimAst:xt,emStrongLDelim:_t,delLDelim:Tt,delRDelim:Et,url:T(/^emailProtocol|^((?:protocol):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/).replace(`emailProtocol`,Vt).replace(`protocol`,Bt).replace(`email`,/[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![\w-])/).getRegex(),_backpedal:/(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,del:/^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/,text:T(/^(?:[^a-zA-Z0-9](?=emailProtocol)|(`+|~+|[^`~])(?:(?=[`~])|(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|protocol:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9](?=emailProtocol)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@))))/).replace(`protocol`,Bt).replace(/emailProtocol/g,/(?:mailto|xmpp):/).getRegex()},Gt={...Wt,br:T(st).replace(`{2,}`,`*`).getRegex(),text:T(Wt.text).replace(`\\b_`,`\\b_| {2,}\\n`).replace(/\{2,\}/g,`*`).getRegex()},Kt={normal:tt,gfm:rt,pedantic:it},M={normal:Ht,gfm:Wt,breaks:Gt,pedantic:Ut},qt={"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`},Jt=e=>qt[e];function N(e,t){if(t){if(E.escapeTest.test(e))return e.replace(E.escapeReplace,Jt)}else if(E.escapeTestNoEncode.test(e))return e.replace(E.escapeReplaceNoEncode,Jt);return e}function Yt(e){return E.numericCharacterReference.test(e)?e.replace(E.numericCharacterReferenceOrAmpersand,(e,t,n)=>{if(t===void 0&&n===void 0)return`&amp;`;let r=t===void 0?Number.parseInt(n,16):Number.parseInt(t,10);return r===0||r>1114111||r>=55296&&r<=57343?`�`:r===38?`&amp;`:String.fromCodePoint(r)}):e}function Xt(e){try{e=encodeURI(e).replace(E.percentDecode,`%`)}catch{return null}return e}function Zt(e,t){let n=e.replace(E.findPipe,(e,t,n)=>{let r=!1,i=t;for(;--i>=0&&n[i]===`\\`;)r=!r;return r?`|`:` |`}).split(E.splitPipe),r=0;if(n[0].trim()||n.shift(),n.length>0&&!n.at(-1)?.trim()&&n.pop(),t){if(n.length>t)n.splice(t);else for(;n.length<t;)n.push(``)}for(;r<n.length;r++)n[r]=n[r].trim().replace(E.slashPipe,`|`);return n}function P(e,t,n){let r=e.length;if(r===0)return``;let i=0;for(;i<r;){let a=e.charAt(r-i-1);if(a===t&&!n)i++;else if(a!==t&&n)i++;else break}return e.slice(0,r-i)}function Qt(e){let t=e.split(`
`),n=t.length-1;for(;n>=0&&E.blankLine.test(t[n]);)n--;return t.length-n<=2?e:t.slice(0,n+1).join(`
`)}function F(e){return e.trim().toLowerCase().toUpperCase().toLowerCase()}function $t(e,t){if(e.indexOf(t[0])===-1&&e.indexOf(t[1])===-1)return-1;let n=0;for(let r=0;r<e.length;r++)if(e[r]===`\\`)r++;else if(e[r]===t[0])n++;else if(e[r]===t[1]&&(n--,n<0))return r;return n>0?-2:-1}function en(e,t=0){let n=t,r=``;for(let t of e)if(t===`	`){let e=4-n%4;r+=` `.repeat(e),n+=e}else r+=t,n++;return r}function tn(e,t,n,r,i){let a=t.href,o=t.title||null,s=e[1].replace(i.other.outputLinkReplace,`$1`),c=e[0].charAt(0)===`!`,l=r.state.inLink,u=r.state.linkEmitted,d=r.state.inRawBlock;r.state.inLink=!0,r.state.linkEmitted=!1;let f=r.inlineTokens(s),p=r.state.linkEmitted;if(r.state.linkEmitted=u,r.state.inLink=l,!c){if(p){r.state.inRawBlock=d;return}r.state.linkEmitted=!0}return{type:c?`image`:`link`,raw:n,href:a,title:o,text:s,tokens:f}}function nn(e,t,n){let r=e.match(n.other.indentCodeCompensation);if(r===null)return t;let i=r[1];return t.split(`
`).map(e=>{let t=e.match(n.other.beginningSpace);if(t===null)return e;let[r]=t;return e.slice(Math.min(r.length,i.length))}).join(`
`)}function rn(e,t,n,r){if(!t.includes(`<`))return!1;for(let i=0;i<t.length;i++){if(t[i]===`\\`){i++;continue}if(t[i]==="`"){let e=r.inline.code.exec(t.slice(i));if(e){i+=e[0].length-1;continue}}if(t[i]!==`<`)continue;let a=e.slice(n+i),o=r.inline.tag.exec(a)||r.inline.autolink.exec(a);if(o){if(o[0].length>t.length-i)return!0;i+=o[0].length-1}}return!1}var an=class{options;rules;lexer;constructor(e){this.options=e||S}space(e){let t=this.rules.block.newline.exec(e);if(t&&t[0].length>0)return{type:`space`,raw:t[0]}}code(e){let t=this.rules.block.code.exec(e);if(t){let e=this.options.pedantic?t[0]:Qt(t[0]);return{type:`code`,raw:e,codeBlockStyle:`indented`,text:e.replace(this.rules.other.codeRemoveIndent,``)}}}fences(e){let t=this.rules.block.fences.exec(e);if(t){let e=t[0],n=nn(e,t[3]||``,this.rules);return{type:`code`,raw:e,lang:t[2]?t[2].trim().replace(this.rules.inline.anyPunctuation,`$1`):t[2],text:n}}}heading(e){let t=this.rules.block.heading.exec(e);if(t){let e=t[2].trim();if(this.rules.other.endingHash.test(e)){let t=P(e,`#`);(this.options.pedantic||!t||this.rules.other.endingSpaceTabChar.test(t))&&(e=t.trim())}return{type:`heading`,raw:P(t[0],`
`),depth:t[1].length,text:e,tokens:this.lexer.inline(e)}}}hr(e){let t=this.rules.block.hr.exec(e);if(t)return{type:`hr`,raw:P(t[0],`
`)}}blockquote(e){let t=this.rules.block.blockquote.exec(e);if(t){let e=P(t[0],`
`).split(`
`),n=``,r=``,i=[];for(;e.length>0;){let t=!1,a=[],o;for(o=0;o<e.length;o++)if(this.rules.other.blockquoteStart.test(e[o]))a.push(e[o]),t=!0;else if(!t)a.push(e[o]);else break;e=e.slice(o);let s=a.join(`
`),c=s.replace(this.rules.other.blockquoteSetextReplace,`
    $1`).replace(this.rules.other.blockquoteSetextReplace2,``);n=n?`${n}
${s}`:s,r=r?`${r}
${c}`:c;let l=this.lexer.state.top;if(this.lexer.state.top=!0,this.lexer.blockTokens(c,i,!0),this.lexer.state.top=l,e.length===0)break;let u=i.at(-1);if(u?.type===`code`||u?.type===`heading`||u?.type===`hr`||u?.type===`html`)break;if(u?.type===`blockquote`){let t=u,a=e.join(`
`),o=t.raw+`
`+a.replace(this.rules.other.blockquoteSetextReplace2,``),s=this.blockquote(o);i[i.length-1]=s;let c=o.substring(s.raw.length).replace(/^\n/,``),l=c?c.split(`
`).length:0,d=l?e.slice(0,-l):e;d.length>0&&(n=`${n}
${d.join(`
`)}`),r=r.substring(0,r.length-t.text.length)+s.text;break}if(u?.type===`list`){let t=u,a=t.raw+`
`+e.join(`
`),o=this.list(a);i[i.length-1]=o,n=n.substring(0,n.length-u.raw.length)+o.raw,r=r.substring(0,r.length-t.raw.length)+o.raw,e=a.substring(i.at(-1).raw.length).split(`
`);continue}}return{type:`blockquote`,raw:n,tokens:i,text:r}}}list(e){let t=this.rules.block.list.exec(e);if(t){let n=e,r=()=>n.length-e.length,i=t[1].trim(),a=i.length>1,o={type:`list`,raw:``,ordered:a,start:a?+i.slice(0,-1):``,loose:!1,items:[]};i=a?`\\d{1,9}\\${i.slice(-1)}`:`\\${i}`,this.options.pedantic&&(i=a?i:`[*+-]`);let s=this.rules.other.listItemRegex(i),c=!1;for(;e;){let i=!1,a=``;if(!(t=s.exec(e))||this.rules.block.hr.test(e))break;let l=r();e=e.substring(t[0].length);let u=t[2].split(`
`,1)[0],d=t[1].length,f=this.options.pedantic?en(u,d):u.replace(this.rules.other.leadingSpaceTab,e=>en(e,d)),p=e.split(`
`,1)[0],m=!f.trim(),h=0;if(this.options.pedantic?(h=2,a=f.trimStart()):m?h=d+1:(h=f.search(this.rules.other.nonSpaceChar),h=h>4?1:h,a=f.slice(h),h+=d),m&&this.rules.other.blankLine.test(p)&&(e=e.substring(p.length+1),i=!0),!i){let t=this.rules.other.nextBulletRegex(h),n=this.rules.other.hrRegex(h),r=this.rules.other.fencesBeginRegex(h),i=this.rules.other.headingBeginRegex(h),o=this.rules.other.htmlBeginRegex(h),s=this.rules.other.blockquoteBeginRegex(h);for(;e;){let c=e.split(`
`,1)[0],l;if(p=c,this.options.pedantic?(p=p.replace(this.rules.other.listReplaceNesting,`  `),l=p):l=p.replace(this.rules.other.leadingSpaceTab,e=>en(e)),r.test(p)||i.test(p)||o.test(p)||s.test(p)||t.test(p)||n.test(p))break;if(l.search(this.rules.other.nonSpaceChar)>=h||!p.trim())a+=`
`+l.slice(h);else{if(m||f.replace(this.rules.other.tabCharGlobal,`    `).search(this.rules.other.nonSpaceChar)>=4||r.test(f)||i.test(f)||n.test(f))break;a+=`
`+p}m=!p.trim(),e=e.substring(c.length+1),f=l.slice(h)}}let g=n.slice(l,r());o.loose||(c?o.loose=!0:this.rules.other.doubleBlankLine.test(g)&&(c=!0)),o.items.push({type:`list_item`,raw:g,task:!!this.options.gfm&&this.rules.other.listIsTask.test(a),loose:!1,text:a,tokens:[]})}let l=o.items.at(-1);if(l)l.raw=l.raw.trimEnd(),l.text=l.text.trimEnd();else return;o.raw=n.slice(0,r()).trimEnd();for(let e of o.items)if(this.lexer.state.top=!1,e.tokens=this.lexer.blockTokens(e.text,[]),!o.loose){let t=e.tokens.filter(e=>e.type===`space`);o.loose=t.length>0&&t.some(e=>this.rules.other.anyLine.test(e.raw))}for(let e of o.items){let t=e.tokens[0];if(e.task&&(t?.type===`text`||t?.type===`paragraph`)){e.text=e.text.replace(this.rules.other.listReplaceTask,``),t.raw=t.raw.replace(this.rules.other.listReplaceTask,``),t.text=t.text.replace(this.rules.other.listReplaceTask,``);for(let e=this.lexer.inlineQueue.length-1;e>=0;e--)if(this.rules.other.listIsTask.test(this.lexer.inlineQueue[e].src)){this.lexer.inlineQueue[e].src=this.lexer.inlineQueue[e].src.replace(this.rules.other.listReplaceTask,``);break}let n=this.rules.other.listTaskCheckbox.exec(e.raw);if(n){let t={type:`checkbox`,raw:n[0]+` `,checked:n[0]!==`[ ]`};e.checked=t.checked,o.loose?e.tokens[0]&&[`paragraph`,`text`].includes(e.tokens[0].type)&&`tokens`in e.tokens[0]&&e.tokens[0].tokens?(e.tokens[0].raw=t.raw+e.tokens[0].raw,e.tokens[0].text=t.raw+e.tokens[0].text,e.tokens[0].tokens.unshift(t)):e.tokens.unshift({type:`paragraph`,raw:t.raw,text:t.raw,tokens:[t]}):e.tokens.unshift(t)}}else e.task&&=!1}if(o.loose)for(let e of o.items){e.loose=!0;for(let t of e.tokens)t.type===`text`&&(t.type=`paragraph`)}return o}}html(e){let t=this.rules.block.html.exec(e);if(t){let e=Qt(t[0]);return{type:`html`,block:!0,raw:e,pre:t[1]===`pre`||t[1]===`script`||t[1]===`style`,text:e}}}def(e){let t=this.rules.block.def.exec(e);if(t){if(!this.rules.other.startAngleBracket.test(t[2])&&$t(t[2],`()`)!==-1)return;let e=F(t[1]).replace(this.rules.other.multipleSpaceGlobal,` `),n=t[2]?t[2].replace(this.rules.other.hrefBrackets,`$1`).replace(this.rules.inline.anyPunctuation,`$1`):``,r=t[3]?t[3].substring(1,t[3].length-1).replace(this.rules.inline.anyPunctuation,`$1`):t[3];return{type:`def`,tag:e,raw:P(t[0],`
`),href:n,title:r}}}table(e){let t=this.rules.block.table.exec(e);if(!t||!this.rules.other.tableDelimiter.test(t[2]))return;let n=Zt(t[1]),r=t[2].replace(this.rules.other.tableAlignChars,``).split(`|`),i=t[3]?.trim()?t[3].replace(this.rules.other.tableRowBlankLine,``).split(`
`):[],a={type:`table`,raw:P(t[0],`
`),header:[],align:[],rows:[]};if(n.length===r.length){for(let e of r)this.rules.other.tableAlignRight.test(e)?a.align.push(`right`):this.rules.other.tableAlignCenter.test(e)?a.align.push(`center`):this.rules.other.tableAlignLeft.test(e)?a.align.push(`left`):a.align.push(null);for(let e=0;e<n.length;e++)a.header.push({text:n[e],tokens:this.lexer.inline(n[e]),header:!0,align:a.align[e]});for(let e of i)a.rows.push(Zt(e,a.header.length).map((e,t)=>({text:e,tokens:this.lexer.inline(e),header:!1,align:a.align[t]})));return a}}lheading(e){let t=this.rules.block.lheading.exec(e);if(t){let e=t[1].trim();return{type:`heading`,raw:P(t[0],`
`),depth:t[2].charAt(0)===`=`?1:2,text:e,tokens:this.lexer.inline(e)}}}paragraph(e){let t=this.rules.block.paragraph.exec(e);if(t){let e=t[1].charAt(t[1].length-1)===`
`?t[1].slice(0,-1):t[1];return{type:`paragraph`,raw:t[0],text:e,tokens:this.lexer.inline(e)}}}text(e){let t=this.rules.block.text.exec(e);if(t)return{type:`text`,raw:t[0],text:t[0],tokens:this.lexer.inline(t[0])}}escape(e){let t=this.rules.inline.escape.exec(e);if(t)return{type:`escape`,raw:t[0],text:t[1]}}tag(e){let t=this.rules.inline.tag.exec(e);if(t)return!this.lexer.state.inLink&&this.rules.other.startATag.test(t[0])?this.lexer.state.inLink=!0:this.lexer.state.inLink&&this.rules.other.endATag.test(t[0])&&(this.lexer.state.inLink=!1),!this.lexer.state.inRawBlock&&this.rules.other.startPreScriptTag.test(t[0])?this.lexer.state.inRawBlock=!0:this.lexer.state.inRawBlock&&this.rules.other.endPreScriptTag.test(t[0])&&(this.lexer.state.inRawBlock=!1),{type:`html`,raw:t[0],inLink:this.lexer.state.inLink,inRawBlock:this.lexer.state.inRawBlock,block:!1,text:t[0]}}link(e){if(this.lexer.state.linkParenPossible===!1)return;let t=this.rules.inline.link.exec(e);if(t){let n=t[0].charAt(0)===`!`?2:1;if(!this.options.pedantic&&rn(e,t[1],n,this.rules))return;let r=t[2].trim();if(!this.options.pedantic&&this.rules.other.startAngleBracket.test(r)){if(!this.rules.other.endAngleBracket.test(r))return;let e=P(r.slice(0,-1),`\\`);if((r.length-e.length)%2==0)return}else{let e=$t(t[2],`()`);if(e===-2)return;if(e>-1){let n=(t[0].indexOf(`!`)===0?5:4)+t[1].length+e;t[2]=t[2].substring(0,e),t[0]=t[0].substring(0,n).trim(),t[3]=``}}let i=t[2],a=``;if(this.options.pedantic){let e=this.rules.other.pedanticHrefTitle.exec(i);e&&(i=e[1],a=e[3])}else a=t[3]?t[3].slice(1,-1):``;return i=i.trim(),this.rules.other.startAngleBracket.test(i)&&(i=this.options.pedantic&&!this.rules.other.endAngleBracket.test(r)?i.slice(1):i.slice(1,-1)),tn(t,{href:i&&i.replace(this.rules.inline.anyPunctuation,`$1`),title:a&&a.replace(this.rules.inline.anyPunctuation,`$1`)},t[0],this.lexer,this.rules)}}reflink(e,t){let n;if((n=this.rules.inline.reflink.exec(e))||(n=this.rules.inline.nolink.exec(e))){let r=n[0].charAt(0)===`!`?2:1;if(!this.options.pedantic&&rn(e,n[1],r,this.rules))return;let i=t[F((n[2]||n[1]).replace(this.rules.other.multipleSpaceGlobal,` `))];if(!i){let e=n[0].charAt(0);return{type:`text`,raw:e,text:e}}return tn(n,i,n[0],this.lexer,this.rules)}}emStrong(e,t,n=``){let r=this.rules.inline.emStrongLDelim.exec(e);if(!(!r||!r[1]&&!r[2]&&!r[3]&&!r[4]||r[4]&&n.match(this.rules.other.unicodeAlphaNumeric))&&(!(r[1]||r[3])||!n||this.rules.inline.punctuation.exec(n))){let i=[...r[0]].length-1,a,o,s=i,c=0,l=r[0][0],u=n===l,d=l===`*`?this.rules.inline.emStrongRDelimAst:this.rules.inline.emStrongRDelimUnd;for(d.lastIndex=0,t=t.slice(-1*e.length+i);(r=d.exec(t))!==null;){if(a=r[1]||r[2]||r[3]||r[4]||r[5]||r[6],!a)continue;if(o=[...a].length,r[3]||r[4]){s+=o;continue}if(r[5]||r[6]){if(i%3&&!((i+o)%3)){c+=o;continue}if(u)break}if(s-=o,s>0)continue;o=Math.min(o,o+s+c);let t=[...r[0]][0].length,n=e.slice(0,i+r.index+t+o);if(Math.min(i,o)%2){let e=n.slice(1,-1);return{type:`em`,raw:n,text:e,tokens:this.lexer.inlineTokens(e)}}let l=n.slice(2,-2);return{type:`strong`,raw:n,text:l,tokens:this.lexer.inlineTokens(l)}}}}codespan(e){let t=this.rules.inline.code.exec(e);if(t){let e=t[2].replace(this.rules.other.newLineCharGlobal,` `),n=this.rules.other.nonSpaceChar.test(e),r=this.rules.other.startingSpaceChar.test(e)&&this.rules.other.endingSpaceChar.test(e);return n&&r&&(e=e.substring(1,e.length-1)),{type:`codespan`,raw:t[0],text:e}}}br(e){let t=this.rules.inline.br.exec(e);if(t)return{type:`br`,raw:t[0]}}del(e,t,n=``){let r=this.rules.inline.delLDelim.exec(e);if(r&&(!r[1]||!n||this.rules.inline.punctuation.exec(n))){let n=[...r[0]].length-1,i,a,o=n,s=this.rules.inline.delRDelim;for(s.lastIndex=0,t=t.slice(-1*e.length+n);(r=s.exec(t))!==null;){if(i=r[1]||r[2]||r[3]||r[4]||r[5]||r[6],!i||(a=[...i].length,a!==n))continue;if(r[3]||r[4]){o+=a;continue}if(o-=a,o>0)continue;a=Math.min(a,a+o);let t=[...r[0]][0].length,s=e.slice(0,n+r.index+t+a),c=s.slice(n,-n);return{type:`del`,raw:s,text:c,tokens:this.lexer.inlineTokens(c)}}}}autolink(e){let t=this.rules.inline.autolink.exec(e);if(t){let e,n;return t[2]===`@`?(e=t[1],n=`mailto:`+e):(e=t[1],n=e),{type:`link`,raw:t[0],text:e,href:n,autolink:!0,tokens:[{type:`text`,raw:e,text:e}]}}}url(e){let t;if(t=this.rules.inline.url.exec(e)){let e,n;if(t[2]===`@`)e=t[0],n=`mailto:`+e;else{let r;do r=t[0],t[0]=this.rules.inline._backpedal.exec(t[0])?.[0]??``;while(r!==t[0]);e=t[0],n=t[1]===`www.`?`http://`+t[0]:t[0]}return{type:`link`,raw:t[0],text:e,href:n,autolink:!0,tokens:[{type:`text`,raw:e,text:e}]}}}inlineText(e){let t=this.rules.inline.text.exec(e);if(t){let e=this.lexer.state.inRawBlock;return{type:`text`,raw:t[0],text:e?t[0]:Yt(t[0]),escaped:e}}}},I=class e{tokens;options;state;inlineQueue;tokenizer;constructor(e){this.tokens=[],this.tokens.links=Object.create(null),this.options=e||S,this.options.tokenizer=this.options.tokenizer||new an,this.tokenizer=this.options.tokenizer,this.tokenizer.options=this.options,this.tokenizer.lexer=this,this.inlineQueue=[],this.state={inLink:!1,inRawBlock:!1,linkEmitted:!1,linkParenPossible:!0,top:!0};let t={other:E,block:Kt.normal,inline:M.normal};this.options.pedantic?(t.block=Kt.pedantic,t.inline=M.pedantic):this.options.gfm&&(t.block=Kt.gfm,t.inline=this.options.breaks?M.breaks:M.gfm),this.tokenizer.rules=t}static get rules(){return{block:Kt,inline:M}}static lex(t,n){return new e(n).lex(t)}static lexInline(t,n){return new e(n).inlineTokens(t)}lex(e){e=e.replace(E.carriageReturn,`
`),this.blockTokens(e,this.tokens);for(let e=0;e<this.inlineQueue.length;e++){let t=this.inlineQueue[e];this.inlineTokens(t.src,t.tokens)}return this.inlineQueue=[],this.tokens}blockTokens(e,t=[],n=!1){this.tokenizer.lexer=this,this.options.pedantic&&(e=e.replace(E.tabCharGlobal,`    `).replace(E.spaceLine,``));let r=1/0;for(;e;){if(e.length<r)r=e.length;else{this.infiniteLoopError(e.charCodeAt(0));break}let i;if(this.options.extensions?.block?.some(n=>(i=n.call({lexer:this},e,t))?(e=e.substring(i.raw.length),t.push(i),!0):!1))continue;if(i=this.tokenizer.space(e)){e=e.substring(i.raw.length);let n=t.at(-1);i.raw.length===1&&n!==void 0?n.raw+=`
`:t.push(i);continue}if(i=this.tokenizer.code(e)){e=e.substring(i.raw.length);let n=t.at(-1);n?.type===`paragraph`||n?.type===`text`?(n.raw+=(n.raw.endsWith(`
`)?``:`
`)+i.raw,n.text+=`
`+i.text,this.inlineQueue.at(-1).src=n.text):t.push(i);continue}if(i=this.tokenizer.fences(e)){e=e.substring(i.raw.length),t.push(i);continue}if(i=this.tokenizer.heading(e)){e=e.substring(i.raw.length),t.push(i);continue}if(i=this.tokenizer.hr(e)){e=e.substring(i.raw.length),t.push(i);continue}if(i=this.tokenizer.blockquote(e)){e=e.substring(i.raw.length),t.push(i);continue}if(i=this.tokenizer.list(e)){e=e.substring(i.raw.length),t.push(i);continue}if(i=this.tokenizer.html(e)){e=e.substring(i.raw.length),t.push(i);continue}if(i=this.tokenizer.def(e)){e=e.substring(i.raw.length);let n=t.at(-1);n?.type===`paragraph`||n?.type===`text`?(n.raw+=(n.raw.endsWith(`
`)?``:`
`)+i.raw,n.text+=`
`+i.raw,this.inlineQueue.at(-1).src=n.text):this.tokens.links[i.tag]||(this.tokens.links[i.tag]={href:i.href,title:i.title},t.push(i));continue}if(i=this.tokenizer.table(e)){e=e.substring(i.raw.length),t.push(i);continue}if(i=this.tokenizer.lheading(e)){e=e.substring(i.raw.length),t.push(i);continue}let a=e;if(this.options.extensions?.startBlock){let t=1/0,n=e.slice(1),r;this.options.extensions.startBlock.forEach(e=>{r=e.call({lexer:this},n),typeof r==`number`&&r>=0&&(t=Math.min(t,r))}),t<1/0&&t>=0&&(a=e.substring(0,t+1))}if(this.state.top&&(i=this.tokenizer.paragraph(a))){let r=t.at(-1);n&&r?.type===`paragraph`?(r.raw+=(r.raw.endsWith(`
`)?``:`
`)+i.raw,r.text+=`
`+i.text,this.inlineQueue.pop(),this.inlineQueue.at(-1).src=r.text):t.push(i),n=a.length!==e.length,e=e.substring(i.raw.length);continue}if(i=this.tokenizer.text(e)){e=e.substring(i.raw.length);let n=t.at(-1);n?.type===`text`?(n.raw+=(n.raw.endsWith(`
`)?``:`
`)+i.raw,n.text+=`
`+i.text,this.inlineQueue.pop(),this.inlineQueue.at(-1).src=n.text):t.push(i);continue}if(e){this.infiniteLoopError(e.charCodeAt(0));break}}return this.state.top=!0,t}inline(e,t=[]){return this.inlineQueue.push({src:e,tokens:t}),t}linkInText(e){if(!e.includes(`[`))return!1;let t=this.tokenizer.rules.inline.link;for(let n of e.matchAll(this.tokenizer.rules.inline.blockSkip))if(t.test(n[0])&&e.charAt(n.index-1)!==`!`)return!0;for(let t of e.matchAll(this.tokenizer.rules.inline.reflinkSearch)){let e=t[0],n=e.lastIndexOf(`[`);if(!(e.charAt(0)===`!`||!Object.hasOwn(this.tokens.links,F(e.slice(n+1,-1))))&&!(n>1&&this.linkInText(e.slice(1,n-1))))return!0}return!1}inlineTokens(e,t=[]){this.tokenizer.lexer=this;let n=this.state.linkParenPossible;this.state.linkParenPossible=n&&e.includes(`)`);try{return this.#e(e,t)}finally{this.state.linkParenPossible=n}}#e(e,t){let n=e;if(this.tokens.links&&e.includes(`[`)){let e=this.tokenizer.rules.inline.reflinkSearch,t=n=>{let r=n.lastIndexOf(`[`);if(!Object.hasOwn(this.tokens.links,F(n.slice(r+1,-1))))return n;if(r>1&&n.charAt(0)!==`!`){let i=n.slice(1,r-1);if(this.linkInText(i))return`[`+i.replace(e,t)+`][`+`a`.repeat(n.length-r-2)+`]`}return`[`+`a`.repeat(n.length-2)+`]`};n=n.replace(e,t)}n=n.replace(this.tokenizer.rules.inline.anyPunctuationOutsideCode,(e,t,n)=>n?`+`.repeat(e.length):t?t+e.slice(t.length,-t.length).replace(/`/g,`+`)+t:e),n=n.replace(this.tokenizer.rules.inline.blockSkip,(e,t,n)=>{let r=n?n.length:0;return e.slice(0,r)+`[`+`a`.repeat(e.length-r-2)+`]`}),n=this.options.hooks?.emStrongMask?.call({lexer:this},n)??n;let r=!1,i=``,a=1/0;for(;e;){if(e.length<a)a=e.length;else{this.infiniteLoopError(e.charCodeAt(0));break}r||(i=``),r=!1;let o;if(this.options.extensions?.inline?.some(n=>(o=n.call({lexer:this},e,t))?(e=e.substring(o.raw.length),t.push(o),!0):!1))continue;if(o=this.tokenizer.escape(e)){e=e.substring(o.raw.length),t.push(o);continue}if(o=this.tokenizer.tag(e)){e=e.substring(o.raw.length),t.push(o);continue}if(o=this.tokenizer.link(e)){e=e.substring(o.raw.length),t.push(o);continue}if(o=this.tokenizer.reflink(e,this.tokens.links)){e=e.substring(o.raw.length);let n=t.at(-1);o.type===`text`&&n?.type===`text`?(n.raw+=o.raw,n.text+=o.text):t.push(o);continue}if(o=this.tokenizer.emStrong(e,n,i)){e=e.substring(o.raw.length),t.push(o);continue}if(o=this.tokenizer.codespan(e)){e=e.substring(o.raw.length),t.push(o);continue}if(o=this.tokenizer.br(e)){e=e.substring(o.raw.length),t.push(o);continue}if(o=this.tokenizer.del(e,n,i)){e=e.substring(o.raw.length),t.push(o);continue}if(o=this.tokenizer.autolink(e)){e=e.substring(o.raw.length),t.push(o);continue}if(!this.state.inLink&&(o=this.tokenizer.url(e))){e=e.substring(o.raw.length),t.push(o);continue}let s=e;if(this.options.extensions?.startInline){let t=1/0,n=e.slice(1),r;this.options.extensions.startInline.forEach(e=>{r=e.call({lexer:this},n),typeof r==`number`&&r>=0&&(t=Math.min(t,r))}),t<1/0&&t>=0&&(s=e.substring(0,t+1))}if(o=this.tokenizer.inlineText(s)){e=e.substring(o.raw.length),o.raw.slice(-1)!==`_`&&(i=o.raw.slice(-1)),r=!0;let n=t.at(-1);n?.type===`text`?(n.raw+=o.raw,n.text+=o.text):t.push(o);continue}if(e){this.infiniteLoopError(e.charCodeAt(0));break}}return t}infiniteLoopError(e){let t=`Infinite loop on byte: `+e;if(this.options.silent)console.error(t);else throw Error(t)}},on=class{options;parser;constructor(e){this.options=e||S}space(e){return``}code({text:e,lang:t,escaped:n}){let r=(t||``).match(E.notSpaceStart)?.[0],i=e?e.replace(E.endingNewline,``)+`
`:``;return r?`<pre><code class="language-`+N(r)+`">`+(n?i:N(i,!0))+`</code></pre>
`:`<pre><code>`+(n?i:N(i,!0))+`</code></pre>
`}blockquote({tokens:e}){return`<blockquote>
${this.parser.parse(e)}</blockquote>
`}html({text:e}){return e}def(e){return``}heading({tokens:e,depth:t}){return`<h${t}>${this.parser.parseInline(e)}</h${t}>
`}hr(e){return`<hr>
`}list(e){let t=e.ordered,n=e.start,r=``;for(let t=0;t<e.items.length;t++){let n=e.items[t];r+=this.listitem(n)}let i=t?`ol`:`ul`,a=t&&n!==1?` start="`+n+`"`:``;return`<`+i+a+`>
`+r+`</`+i+`>
`}listitem(e){return`<li>${this.parser.parse(e.tokens)}</li>
`}checkbox({checked:e}){return`<input `+(e?`checked="" `:``)+`disabled="" type="checkbox"> `}paragraph({tokens:e}){return`<p>${this.parser.parseInline(e)}</p>
`}table(e){let t=``,n=``;for(let t=0;t<e.header.length;t++)n+=this.tablecell(e.header[t]);t+=this.tablerow({text:n});let r=``;for(let t=0;t<e.rows.length;t++){let i=e.rows[t];n=``;for(let e=0;e<i.length;e++)n+=this.tablecell(i[e]);r+=this.tablerow({text:n})}return r&&=`<tbody>${r}</tbody>`,`<table>
<thead>
`+t+`</thead>
`+r+`</table>
`}tablerow({text:e}){return`<tr>
${e}</tr>
`}tablecell(e){let t=this.parser.parseInline(e.tokens),n=e.header?`th`:`td`;return(e.align?`<${n} align="${e.align}">`:`<${n}>`)+t+`</${n}>
`}strong({tokens:e}){return`<strong>${this.parser.parseInline(e)}</strong>`}em({tokens:e}){return`<em>${this.parser.parseInline(e)}</em>`}codespan({text:e}){return`<code>${N(e,!0)}</code>`}br(e){return`<br>`}del({tokens:e}){return`<del>${this.parser.parseInline(e)}</del>`}link({href:e,title:t,text:n,tokens:r,autolink:i}){let a=i?N(n,!0):this.parser.parseInline(r),o=Xt(e);if(o===null)return a;e=N(o,i);let s=`<a href="`+e+`"`;return t&&(s+=` title="`+N(t)+`"`),s+=`>`+a+`</a>`,s}image({href:e,title:t,text:n,tokens:r}){r&&(n=this.parser.parseInline(r,this.parser.textRenderer));let i=Xt(e);if(i===null)return N(n);e=i;let a=`<img src="${N(e)}" alt="${N(n)}"`;return t&&(a+=` title="${N(t)}"`),a+=`>`,a}text(e){return`tokens`in e&&e.tokens?this.parser.parseInline(e.tokens):`escaped`in e&&e.escaped?e.text:N(e.text)}},sn=class{strong({text:e}){return e}em({text:e}){return e}codespan({text:e}){return e}del({text:e}){return e}html({text:e}){return e}text({text:e}){return e}link({text:e}){return``+e}image({text:e}){return``+e}br(){return``}checkbox({raw:e}){return e}},L=class e{options;renderer;textRenderer;constructor(e){this.options=e||S,this.options.renderer=this.options.renderer||new on,this.renderer=this.options.renderer,this.renderer.options=this.options,this.renderer.parser=this,this.textRenderer=new sn}static parse(t,n){return new e(n).parse(t)}static parseInline(t,n){return new e(n).parseInline(t)}parse(e){this.renderer.parser=this;let t=``;for(let n=0;n<e.length;n++){let r=e[n];if(this.options.extensions?.renderers?.[r.type]){let e=r,n=this.options.extensions.renderers[e.type].call({parser:this},e);if(n!==!1||![`space`,`hr`,`heading`,`code`,`table`,`blockquote`,`list`,`checkbox`,`html`,`def`,`paragraph`,`text`].includes(e.type)){t+=n||``;continue}}let i=r;switch(i.type){case`space`:t+=this.renderer.space(i);break;case`hr`:t+=this.renderer.hr(i);break;case`heading`:t+=this.renderer.heading(i);break;case`code`:t+=this.renderer.code(i);break;case`table`:t+=this.renderer.table(i);break;case`blockquote`:t+=this.renderer.blockquote(i);break;case`list`:t+=this.renderer.list(i);break;case`checkbox`:t+=this.renderer.checkbox(i);break;case`html`:t+=this.renderer.html(i);break;case`def`:t+=this.renderer.def(i);break;case`paragraph`:t+=this.renderer.paragraph(i);break;case`text`:t+=this.renderer.text(i);break;default:{let e=`Token with "`+i.type+`" type was not found.`;if(this.options.silent)return console.error(e),``;throw Error(e)}}}return t}parseInline(e,t=this.renderer){this.renderer.parser=this;let n=``;for(let r=0;r<e.length;r++){let i=e[r];if(this.options.extensions?.renderers?.[i.type]){let e=this.options.extensions.renderers[i.type].call({parser:this},i);if(e!==!1||![`escape`,`html`,`link`,`image`,`checkbox`,`strong`,`em`,`codespan`,`br`,`del`,`text`].includes(i.type)){n+=e||``;continue}}let a=i;switch(a.type){case`escape`:n+=t.text(a);break;case`html`:n+=t.html(a);break;case`link`:n+=t.link(a);break;case`image`:n+=t.image(a);break;case`checkbox`:n+=t.checkbox(a);break;case`strong`:n+=t.strong(a);break;case`em`:n+=t.em(a);break;case`codespan`:n+=t.codespan(a);break;case`br`:n+=t.br(a);break;case`del`:n+=t.del(a);break;case`text`:n+=t.text(a);break;default:{let e=`Token with "`+a.type+`" type was not found.`;if(this.options.silent)return console.error(e),``;throw Error(e)}}}return n}},R=class{options;block;constructor(e){this.options=e||S}static passThroughHooks=new Set([`preprocess`,`postprocess`,`processAllTokens`,`emStrongMask`]);static passThroughHooksRespectAsync=new Set([`preprocess`,`postprocess`,`processAllTokens`]);preprocess(e){return e}postprocess(e){return e}processAllTokens(e){return e}emStrongMask(e){return e}provideLexer(e=this.block){return e?I.lex:I.lexInline}provideParser(e=this.block){return e?L.parse:L.parseInline}};function z(e,t){if(Array.isArray(t))for(let n=0;n<t.length;n++)e.push(t[n]);else e.push(t)}var B=new class{defaults=Pe();options=this.setOptions;parse=this.parseMarkdown(!0);parseInline=this.parseMarkdown(!1);Parser=L;Renderer=on;TextRenderer=sn;Lexer=I;Tokenizer=an;Hooks=R;constructor(...e){this.use(...e)}walkTokens(e,t){let n=[];for(let r of e)switch(z(n,t.call(this,r)),r.type){case`table`:{let e=r;for(let r of e.header)z(n,this.walkTokens(r.tokens,t));for(let r of e.rows)for(let e of r)z(n,this.walkTokens(e.tokens,t));break}case`list`:{let e=r;z(n,this.walkTokens(e.items,t));break}default:{let e=r;this.defaults.extensions?.childTokens?.[e.type]?this.defaults.extensions.childTokens[e.type].forEach(r=>{let i=e[r].flat(1/0);z(n,this.walkTokens(i,t))}):e.tokens&&z(n,this.walkTokens(e.tokens,t))}}return n}use(...e){let t=this.defaults.extensions||{renderers:{},childTokens:{}};return e.forEach(e=>{let n={...e};if(n.async=this.defaults.async||n.async||!1,e.extensions&&(e.extensions.forEach(e=>{if(!e.name)throw Error(`extension name required`);if(`renderer`in e){let n=t.renderers[e.name];n?t.renderers[e.name]=function(...t){let r=e.renderer.apply(this,t);return r===!1&&(r=n.apply(this,t)),r}:t.renderers[e.name]=e.renderer}if(`tokenizer`in e){if(!e.level||e.level!==`block`&&e.level!==`inline`)throw Error(`extension level must be 'block' or 'inline'`);let n=t[e.level];n?n.unshift(e.tokenizer):t[e.level]=[e.tokenizer],e.start&&(e.level===`block`?t.startBlock?t.startBlock.push(e.start):t.startBlock=[e.start]:e.level===`inline`&&(t.startInline?t.startInline.push(e.start):t.startInline=[e.start]))}`childTokens`in e&&e.childTokens&&(t.childTokens[e.name]=e.childTokens)}),n.extensions=t),e.renderer){let t=this.defaults.renderer||new on(this.defaults);for(let n in e.renderer){if(!(n in t))throw Error(`renderer '${n}' does not exist`);if([`options`,`parser`].includes(n))continue;let r=n,i=e.renderer[r],a=t[r];t[r]=(...e)=>{let n=i.apply(t,e);return n===!1&&(n=a.apply(t,e)),n||``}}n.renderer=t}if(e.tokenizer){let t=this.defaults.tokenizer||new an(this.defaults);for(let n in e.tokenizer){if(!(n in t))throw Error(`tokenizer '${n}' does not exist`);if([`options`,`rules`,`lexer`].includes(n))continue;let r=n,i=e.tokenizer[r],a=t[r];t[r]=(...e)=>{let n=i.apply(t,e);return n===!1&&(n=a.apply(t,e)),n}}n.tokenizer=t}if(e.hooks){let t=this.defaults.hooks||new R;for(let n in e.hooks){if(!(n in t))throw Error(`hook '${n}' does not exist`);if([`options`,`block`].includes(n))continue;let r=n,i=e.hooks[r],a=t[r];t[r]=R.passThroughHooks.has(n)?e=>{if(this.defaults.async&&R.passThroughHooksRespectAsync.has(n))return(async()=>{let n=await i.call(t,e);return a.call(t,n)})();let r=i.call(t,e);return a.call(t,r)}:(...e)=>{if(this.defaults.async)return(async()=>{let n=await i.apply(t,e);return n===!1&&(n=await a.apply(t,e)),n})();let n=i.apply(t,e);return n===!1&&(n=a.apply(t,e)),n}}n.hooks=t}if(e.walkTokens){let t=this.defaults.walkTokens,r=e.walkTokens;n.walkTokens=function(e){let n=[];return n.push(r.call(this,e)),t&&z(n,t.call(this,e)),n}}this.defaults={...this.defaults,...n}}),this}setOptions(e){return this.defaults={...this.defaults,...e},this}lexer(e,t){return I.lex(e,t??this.defaults)}parser(e,t){return L.parse(e,t??this.defaults)}parseMarkdown(e){return(t,n)=>{let r={...n},i={...this.defaults,...r},a=this.onError(!!i.silent,!!i.async);if(this.defaults.async===!0&&r.async===!1)return a(Error(`marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise.`));if(typeof t>`u`||t===null)return a(Error(`marked(): input parameter is undefined or null`));if(typeof t!=`string`)return a(Error(`marked(): input parameter is of type `+Object.prototype.toString.call(t)+`, string expected`));if(i.hooks&&(i.hooks.options=i,i.hooks.block=e),i.async)return(async()=>{let n=i.hooks?await i.hooks.preprocess(t):t,r=await(i.hooks?await i.hooks.provideLexer(e):e?I.lex:I.lexInline)(n,i),a=i.hooks?await i.hooks.processAllTokens(r):r;i.walkTokens&&await Promise.all(this.walkTokens(a,i.walkTokens));let o=await(i.hooks?await i.hooks.provideParser(e):e?L.parse:L.parseInline)(a,i);return i.hooks?await i.hooks.postprocess(o):o})().catch(a);try{i.hooks&&(t=i.hooks.preprocess(t));let n=(i.hooks?i.hooks.provideLexer(e):e?I.lex:I.lexInline)(t,i);i.hooks&&(n=i.hooks.processAllTokens(n)),i.walkTokens&&this.walkTokens(n,i.walkTokens);let r=(i.hooks?i.hooks.provideParser(e):e?L.parse:L.parseInline)(n,i);return i.hooks&&(r=i.hooks.postprocess(r)),r}catch(e){return a(e)}}}onError(e,t){return n=>{if(n.message+=`
Please report this to https://github.com/markedjs/marked.`,e){let e=`<p>An error occurred:</p><pre>`+N(n.message+``,!0)+`</pre>`;return t?Promise.resolve(e):e}if(t)return Promise.reject(n);throw n}}};function V(e,t){return B.parse(e,t)}V.options=V.setOptions=function(e){return B.setOptions(e),V.defaults=B.defaults,Fe(V.defaults),V},V.getDefaults=Pe,V.defaults=S;function cn(...e){return B.use(...e),V.defaults=B.defaults,Fe(V.defaults),V}V.use=cn,V.walkTokens=function(e,t){return B.walkTokens(e,t)},V.parseInline=B.parseInline,V.Parser=L,V.parser=L.parse,V.Renderer=on,V.TextRenderer=sn,V.Lexer=I,V.lexer=I.lex,V.Tokenizer=an,V.Hooks=R,V.parse=V,V.options,V.setOptions,V.walkTokens,V.parseInline,L.parse,I.lex;function ln(e){let[t,n]=(0,v.useState)(e[0]??null),r=e.join(` `);return(0,v.useEffect)(()=>{let t=()=>{let t=e[0]??null;for(let n of e){let e=document.getElementById(n)?.getBoundingClientRect().top;e!=null&&e<=window.innerHeight*.3&&(t=n)}window.innerHeight+window.scrollY>=document.documentElement.scrollHeight-2&&(t=e[e.length-1]??t),n(t)};return t(),window.addEventListener(`scroll`,t,{passive:!0}),window.addEventListener(`resize`,t),()=>{window.removeEventListener(`scroll`,t),window.removeEventListener(`resize`,t)}},[r]),t}function un(){(0,v.useEffect)(()=>{let e=decodeURIComponent(window.location.hash.slice(1));e&&document.getElementById(e)?.scrollIntoView({block:`start`})},[])}function H({groups:e,active:t,variant:n}){return n===`rail`?(0,b.jsxs)(`nav`,{"aria-label":`Contents`,className:`text-[13px]`,children:[(0,b.jsx)(`p`,{className:`mb-3 text-[11px] font-black uppercase tracking-widest text-finn-black/60`,children:`Contents`}),(0,b.jsx)(`div`,{className:`space-y-4`,children:e.map((e,n)=>(0,b.jsxs)(`div`,{children:[e.label?(0,b.jsx)(`p`,{className:`mb-1.5 text-[11px] font-black uppercase tracking-wide text-finn-black/60`,children:e.label}):null,(0,b.jsx)(`ol`,{className:`border-l border-finn-black/10`,children:e.items.map(e=>(0,b.jsx)(`li`,{children:(0,b.jsx)(dn,{item:e,current:e.id===t})},e.id))})]},e.label??n))}),(0,b.jsx)(`a`,{href:`#top`,className:`mt-5 inline-block text-[12.5px] font-bold text-finn-accent-blue hover:underline`,onClick:fn,children:`↑ Back to top`})]}):(0,b.jsxs)(`nav`,{"aria-label":`Contents`,className:`rounded-2xl bg-white p-5 ring-1 ring-finn-cotton`,children:[(0,b.jsx)(`p`,{className:`text-[11px] font-black uppercase tracking-widest text-finn-black/60`,children:`Contents`}),(0,b.jsx)(`div`,{className:`mt-3 divide-y divide-finn-cotton`,children:e.map((e,t)=>(0,b.jsxs)(`div`,{className:`grid gap-1 py-2.5 first:pt-0 last:pb-0 sm:grid-cols-[140px_1fr] sm:gap-4`,children:[e.label?(0,b.jsx)(`p`,{className:`pt-1.5 text-[11px] font-black uppercase tracking-wide text-finn-black/60`,children:e.label}):(0,b.jsx)(`span`,{}),(0,b.jsx)(`ol`,{children:e.items.map(e=>(0,b.jsx)(`li`,{children:(0,b.jsxs)(`a`,{href:`#${e.id}`,className:`flex items-baseline gap-3 rounded-lg px-2 py-1.5 text-[13.5px] font-bold text-finn-black/85 transition-colors hover:bg-finn-pale-blue hover:text-finn-accent-blue focus-visible:outline-2 focus-visible:outline-finn-accent-blue`,children:[(0,b.jsx)(`span`,{"aria-hidden":`true`,className:`w-5 shrink-0 font-mono text-[12px] tabular-nums text-finn-black/50`,children:e.number}),e.label]})},e.id))})]},e.label??t))})]})}function dn({item:e,current:t}){return(0,b.jsxs)(`a`,{href:`#${e.id}`,"aria-current":t?`location`:void 0,className:[`-ml-px flex items-baseline gap-2.5 border-l-2 py-1.5 pl-3 pr-1 leading-snug transition-colors focus-visible:outline-2 focus-visible:outline-finn-accent-blue`,t?`border-finn-accent-blue font-black text-finn-highlight-navy`:`border-transparent font-semibold text-finn-black/70 hover:border-finn-black/30 hover:text-finn-black`].join(` `),children:[(0,b.jsx)(`span`,{"aria-hidden":`true`,className:`shrink-0 font-mono text-[11.5px] tabular-nums ${t?`text-finn-accent-blue`:`text-finn-black/45`}`,children:e.number}),e.label]})}function fn(e){e.preventDefault(),window.scrollTo({top:0,behavior:`smooth`})}function pn({icon:e,eyebrow:t,title:n,badge:r,children:i}){return(0,b.jsx)(`header`,{className:`rounded-2xl border border-[#e8e5df] bg-white p-5 sm:p-6`,children:(0,b.jsxs)(`div`,{className:`flex items-start gap-3`,children:[(0,b.jsx)(`div`,{className:`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-[#eaf3ff] text-[#0072ea] [&>svg]:h-5 [&>svg]:w-5`,children:e}),(0,b.jsxs)(`div`,{className:`min-w-0 flex-1`,children:[(0,b.jsxs)(`p`,{className:`text-xs font-bold uppercase tracking-widest text-[#0072ea]`,children:[`Finn Lens · `,t]}),(0,b.jsxs)(`div`,{className:`mt-1 flex flex-wrap items-center gap-2`,children:[(0,b.jsx)(`h2`,{className:`text-xl font-black text-[#17243b] sm:text-2xl`,children:n}),r]}),(0,b.jsx)(`div`,{className:`mt-2 space-y-3 text-[13.5px] leading-relaxed text-[#17243b]/80`,children:i})]})]})})}var U=[{id:`overview`,file:`README.md`,label:`Overview`,number:`01`,source:`README.md`,markdown:`# Finn Lens

A browser extension that helps you choose between FINN car subscriptions by chatting with Lens. You tell it what the car has to do for you, and it judges the cars on finn.com against what you said and explains its pick.

## Try it

- **Read about it:** the beta guide, a product demo in screenshots, and this documentation are published at **[orjwan-alrajaby.github.io/finn-lens](https://orjwan-alrajaby.github.io/finn-lens/)**.
- **Install it** (Chrome on a computer): download **[\`finn-lens-0.9.1-chrome.zip\`](https://github.com/orjwan-alrajaby/finn-lens/raw/main/releases/finn-lens-0.9.1-chrome.zip)** and unzip it. Open \`chrome://extensions\`, switch on **Developer mode**, click **Load unpacked** and choose the unzipped folder. Lens opens finn.com with its chat open. [The beta note](docs/BETA.md#install-it-chrome-on-a-computer-about-two-minutes) has the steps in full.

## What the reader sees

1. **Install.** Lens opens finn.com, and a bubble in the corner opens by itself. Lens says hello, explains what's about to happen, and asks its first question.
2. **Questions.** Short ones, each a screen of its own (see [\`docs/LIFE-BUBBLES-SPEC-v2.md\`](docs/LIFE-BUBBLES-SPEC-v2.md)):
   - **The reader's life, in four sections of bubbles:** who rides with you (kids, adults, a dog); where and how you drive (city, traffic, long distances, night); what the car has to cope with (weather, what you carry); and what else matters (help driving & parking, comfort, the environment — how green: clean for its fuel type, moderately green, or totally green — and a budget). Some bubbles open a row of chips under themselves where the answer changes what Lens checks — which child seat, where you park, what the weather's like, which comforts, how green, how firm the budget is — and every chip is one the reader picks themselves. Every answer changes something: what's counted, checked or suggested, how much it counts, or a limit (\`bubbles.test.ts\` holds them to it). Labels are short; the "i" on each is a tooltip saying what it means and what Lens checks. Questions take taps, and a number of the reader's own where one fits (another amount, length, distance, or months from now). Words typed in the chat's message box that mean a bubble land on it, whichever section it's in.
   - **How often**, only for long distances and time in traffic, straight after the driving: it sets how much those count.
   - **The monthly limit, all costs together** (FINN's price, fuel or charging, mileage), **how long**, **from when**, then how far the reader drives — only when a bubble makes it matter; otherwise Lens assumes 1,000 km a month and says so.
   - **What it can run on**: electric, plug-in hybrid, petrol, diesel — the ones on the page, any or all — with stars where how green the reader wants points (totally green: electric; moderately green: the fuels most of whose cars on the page are low CO₂). Not asked when the page has only one fuel. The fuels not picked are set aside before scoring. FINN lists only a plug-in hybrid's official fuel figure, so Lens takes the electricity half of the same official test from the EU's registration data (see below), and says so.
   - **Deal-breakers & deal-sealers**: a row each — low CO₂ emissions, an automatic gearbox, a towbar, six seats and more — set to "Doesn't matter", a deal-breaker ("Must have" / "Must be" / "Mustn't be", which sets cars aside before anything is scored) or a deal-sealer ("Seals it", which counts as a top priority without setting any car aside). Each option says what it means on hover. Each row offers only what Lens can do with it here — one it can only rule on says it can't seal the deal — and the ones the bubbles point to come first, saying why.

   Every question says why it's asked. Anything already said isn't asked again. "Edit this answer" under the last answer takes it back — everything it changed with it — and asks that question again.
3. **Here's what you told me, and what I understood.** A short, read-only card in the chat: each thing the reader said, how much it counts and what Lens will check for it, then the money, the dates and the deal-breakers. Two choices: **"Looks good to me — continue"**, after which Lens asks whether to keep it as their settings or use it for this chat only; or **"This doesn't look right"**, which opens the **Adjust panel** — beside the chat, which the page widens for it, or over it in a narrow window. There each thing is a card: what Lens will check (each can be taken out), standard equipment it checks without rewarding (named only where it can mark a car down: inside a priority something else is scored in), what might matter too (each can be added), and how much it counts — Top priority · Important · Nice to have, the one scale used wherever Lens asks how much something counts, each counting twice the next and each saying what it means, marked as Lens's guess when nothing the reader said set it — with "Change" on each line to answer that question again in the chat. **Done** says back what Lens understood now, with the same two choices.
4. **Judgement.** Lens judges the cars on the page. On a filtered listing, that's the cars matching the filters — up to about 150 at once, and when more match it says how many it judged of how many. The result is short: the pick and its price, why — one line per bubble naming what this car has — and one thing to know. "See why" opens what it got right for each thing the reader said, and the next closest; open it on two results in a row and later ones open that way too, until "Keep it short". "The whole case" opens the winner's drawer.
5. **Chips.** Every car Lens judged gets a chip on its FINN card: its verdict, its place, and whether it's over budget or not for the reader's dates. The pick gets a gold chip with a trophy: "Best for you", or "Closest match" when nothing here fits the budget, the dates or a deal-breaker the reader kept — as the result in the chat and the drawer say it. There are no chips before a judgement.
6. **Drawers.** Clicking a chip opens a drawer beside the page. Every result stays in the chat, and one from earlier — before more cars were added, say — opens on what it said then, marked as an earlier result:
   - **Any car:** how it fits each thing the reader said, what's worth knowing, how it lost to the winner, and what it costs.
   - **The winner:** why it won and what it costs, open; how it fits, what the reader gives up, why not the others, how Lens weighed it and the costs of use, a tap each.
   - **Save as PDF** on every car's drawer but a ruled-out car's, with everything open.
7. **Many chats.** Every chat is kept, and "Your chats" lists them like a messenger. Opening one carries on where it was, and the chips move to its judgement.
8. **Popup.** It says what Lens is and whether it's online on this finn.com tab (it only works on finn.com, and it's unofficial). It also shows how many cars it detected and judged here, the current pick and chats, and a way to Settings and the beta guide.
9. **Settings.** Shows the saved answers (changed by talking to Lens, or forgotten from here), and everything Lens stores, each part clearable: chats, answers, the car cache, and leftovers from earlier versions. Its **Beta guide** tab (\`options.html#guide\`) explains Lens to someone who has never seen it: what it does and why, how it decides, how to read its results, its known limits, what might come next, and what a bug report needs. Its **Product demo** tab (\`options.html#demo\`) walks through a reader's journey in screenshots, and its **Documentation** tab (\`options.html#docs\`) shows this README, the beta note, the changelog and the docs. All three are also published as a web page, at [orjwan-alrajaby.github.io/finn-lens](https://orjwan-alrajaby.github.io/finn-lens/).

## How it's built

The extension lives in [\`browser-extension/\`](browser-extension/); the paths below are inside it.

| Where | What |
|---|---|
| \`lib/reasoning-engine/\` | The engine: scoring, cost, emissions, and the narrative it writes about a result. Pure functions over FINN's data. See \`docs/FINN-LENS-EMISSIONS-SCORING.md\`. |
| \`lib/lens-chat/\` | What Lens understands from a reader (\`understanding.ts\`), the life bubbles and what each counts, checks and suggests (\`bubbles.ts\`), its guided questions (\`guide.ts\`), a run of the engine for a chat (\`run.ts\`), and the readings of it: \`fit-story.ts\` (one car against the reader's needs) and \`why-not.ts\`. |
| \`lib/lens-ai/mock.ts\` | The built-in reader for typed messages: keyword rules, no model and no key. A model can stand behind the same \`LensAiAdapter\` later. |
| \`lib/chats/\` | A chat as data. \`flow.ts\` holds the conversation's rules as pure functions. \`follow-ups.ts\` applies the second questions saved in chats from before the bubbles. \`judge.ts\` makes the judgement: one engine run gives both the chat's result and every chip's verdict. \`store.ts\` handles storage, and \`data.ts\` is the single list of everything stored. |
| \`entrypoints/content/\` | The content script on finn.com. It keeps the cars FINN's pages load (\`data/\`, \`car-data.ts\`) and reads the page (\`page/\`). \`lens/\` holds the bubble, the drawer's shell, the chips, and the bridge the frames talk to the page through. |
| \`entrypoints/lens-chat/\` | The chat: a React page framed into finn.com. |
| \`entrypoints/lens-drawer/\` | The drawer: a React page framed beside finn.com. It re-runs the chat's judgement and reads one car out of it. |
| \`entrypoints/popup/\` | The toolbar popup. |
| \`entrypoints/options/\` | Settings: saved answers and the reader's data; the beta guide (\`Guide.tsx\`), the product demo (\`ProductWalkthrough.tsx\`) and the documentation (\`Docs.tsx\`, the repository's markdown), each with its contents (\`OnThisPage.tsx\`). |
| \`site/\` | The beta guide, product demo and documentation as a plain web page, for GitHub Pages: the same components, without the extension. |
| \`entrypoints/background.ts\` | Relays frame requests to their tab (token-checked), and opens finn.com on install. |

**Storage** (\`browser.storage.local\`):

- \`finnLensChats\`: every chat.
- \`finnLensActiveChat\`: the chat whose judgement the chips show.
- \`finnLensSettings\`: the answers the reader kept.
- \`finnLensOpenBubble\`: a one-off request to open the bubble.
- \`loadedCarsFromFinnApi\`: FINN's cars, as the page loaded them.
- \`finnLensChatSize\`: the size the reader dragged the chat to.

And in \`browser.storage.session\`, \`lensChatTokens\`: each tab's secret, which its Lens frames prove themselves with (cleared when the tab closes). \`lib/chats/data.ts\` lists every \`local\` key, with how Settings lets the reader delete it.

## Who built it

Finn Lens is an independent project by Orjwan Al-Rajaby. It isn't a FINN
product, and it isn't for sale.

- **Orjwan's work:** the idea and the problem it starts from; investigating
  finn.com — how its pages are rendered, on the server and in the browser, and
  how an extension can work alongside them; working out what each field in
  FINN's car data means; the product's direction and its decision model (what
  Lens asks, what counts, what rules a car out, how much each answer weighs);
  and the first versions — the extension's foundation and its reading of
  FINN's car data (August 2026).
- **Built with Claude Code:** from September 2026, Orjwan directed the
  development with Claude Code, Anthropic's AI coding assistant, which wrote
  most of the code from then on — every commit in this version's history since
  then is marked as co-authored with it. Orjwan decided what to build and what
  to change, and tested it on finn.com.

Lens went through several designs before this one — pinning cars to compare, a
settings screen of priorities, a chat answered by an AI model — before the
guided conversation in this beta.

The code is a beta codebase: it typechecks, has around 950 automated tests,
and was audited for this release, but it grew with the product rather than to
engineering standards set up front, and hasn't had the review a production
product would.

## Beta

This is the **0.9.1 beta** ([\`CHANGELOG.md\`](browser-extension/CHANGELOG.md)), for its first outside reviewer; [\`docs/BETA.md\`](docs/BETA.md) is the note that goes with the build. The beta is frozen: only fixes go in until it's been tried. \`npm run release\` checks the types, runs the tests, zips the build into \`.output/\` and copies the zip into [\`releases/\`](releases/), which is what the download above links to — commit it with the version it's for.

## Developing

\`\`\`sh
cd browser-extension
npm install
npm run dev        # Chrome, with reload
npm run compile    # typecheck
npm test           # vitest
npm run build      # .output/chrome-mv3
npm run site:dev   # the beta guide and product demo as a web page
\`\`\`

The beta guide and the product demo are also published as a web page: \`site/\` renders the same components the extension's Settings shows, and \`.github/workflows/pages.yml\` builds it (\`npm run site:build\`, into \`.output/site\`) and deploys it to GitHub Pages, at [orjwan-alrajaby.github.io/finn-lens](https://orjwan-alrajaby.github.io/finn-lens/), on every push to \`main\` that touches the extension or the docs, or by hand from the Actions tab.

To try it by hand, load \`.output/chrome-mv3\` as an unpacked extension. Installing opens finn.com with the bubble open.

## Next

The shortlist: pinning from the drawers, judging the pinned cars against each other, and exporting them. It's agreed but not built; see [\`docs/FUTURE-SHORTLIST.md\`](docs/FUTURE-SHORTLIST.md).

## Left on the \`playground\` branch

Pinning cars, the pinned-cars page, the earlier Settings screen (priorities and profiles), the Compare/recommendation page, the setup flow, and Lens AI with a Gemini key. The engine and the chat's understanding came from there, and so did the reasoning behind most of it. The playground's \`docs/FINN-LENS-HANDOFF.md\` is the long version.


How Lens decides — every mechanism, number and source, and the decisions behind them — is written up in [\`docs/HOW-FINN-LENS-DECIDES.md\`](docs/HOW-FINN-LENS-DECIDES.md).

## Figures that aren't FINN's

Lens says where every figure it didn't get from FINN comes from, links it, and says what it can't tell you.

- **A plug-in hybrid's electricity.** FINN lists a plug-in hybrid's official CO₂ and fuel figures but not the electricity half of the same test. Every new car registered in the EU is reported with that figure — "Electric energy consumption (EC_AC,weighted)" — to the European Environment Agency under Regulation (EU) 2019/631. \`scripts/snapshot-eu-plug-in-electricity.mjs\` reads the EEA's 2025 (provisional) data into \`lib/reasoning-engine/data/eu-plug-in-electricity.json\`, keeping FINN's makers only; \`lib/reasoning-engine/eu-electricity.ts\` matches a FINN car on make, official CO₂ and fuel figures, and the words that name it (not "xDrive" or "PHEV"). Where versions differ, the highest figure is used and said; where nothing matches, the electricity is named as missing and the car can't be confirmed within a budget — and is set aside under a hard one. Every use says both figures assume the EU test's mix of electric and fuel driving, and that the reader's own depends on how they drive and charge. Re-run the script as FINN adds models or the EEA finalises its data.
- **Other figures and rules from European standards or studies** are in \`lib/sources.ts\`, each named and linked wherever it's used — in the chat's "i" tooltips (which stay open long enough to click a link), under the drawer's story lines and cost lines, and at the foot of its environment panel: the German CO₂ label rules (Pkw-EnVKV) for the A–G classes; the ICCT's figures for new cars' CO₂ and electric cars' consumption, behind Lens's comparison points; and the European Commission's real-world CO₂ report, said with its date — plug-ins registered in 2021 emitted 3.5 times their official figure, before the EU changed the method from 2025, which FINN's figures follow. Each link was checked against the document when it was added.
`},{id:`beta`,file:`BETA.md`,label:`The beta note`,number:`02`,source:`docs/BETA.md`,markdown:`# Finn Lens — beta 0.9.1

**Finn Lens** is a browser extension that helps someone choose between FINN car
subscriptions by chatting with it on finn.com. It asks what the car has to do
for them, judges the cars on the page against that, puts its verdict on each
car's card, and explains its pick.

It's **unofficial**: built independently, not by or with FINN. This is a beta,
and this build is for its first outside review.

## Install it (Chrome on a computer, about two minutes)

1. Download [\`finn-lens-0.9.1-chrome.zip\`](https://github.com/orjwan-alrajaby/finn-lens/raw/main/releases/finn-lens-0.9.1-chrome.zip) and unzip it. You get
   a folder holding \`manifest.json\`.
2. Open \`chrome://extensions\` and switch on **Developer mode** (top right).
3. Click **Load unpacked** and choose that folder. Keep the folder where it
   is: Chrome loads Lens from it each time.
4. Lens opens finn.com in a new tab, and its chat opens by itself. If it
   doesn't, click the **Lens** bubble in the bottom-right corner.

It runs only on \`www.finn.com\`. Tabs that were already open need a reload.
Lens isn't published on the Chrome Web Store; this beta is shared as a package
to load directly. Chrome may warn about extensions in developer mode; that's
expected for a build that isn't from the store.

## Start with the beta guide

Click the Lens icon in Chrome's toolbar (under the puzzle piece, if it isn't
pinned) and choose **Beta guide**. It explains what Lens does, how it decides,
how to read its results, and what this beta can't do yet. It's also a tab in
Lens's Settings, beside a **Product demo** tab that walks through a chat in
screenshots. Both are also published, with the documentation, at
[orjwan-alrajaby.github.io/finn-lens](https://orjwan-alrajaby.github.io/finn-lens/), to read before installing.

## Try it (five minutes)

1. On a car listing — apply any filters you like — answer the chat's
   questions. The **i** beside an answer says what it means and what Lens
   checks for it.
2. Read **"Here's what you told me, and what I understood"**. "This doesn't
   look right" opens a panel to correct it.
3. After the judgement, every car on the page wears a chip. Click one for how
   that car fits; click the gold one for why it won. Every car that wasn't
   ruled out can be saved as a PDF from its drawer.
4. Try a limit nothing fits — a very low budget, or a long rental — and see
   how Lens says so.

## How it decides

Lens compares the cars on the page against the reader's stated needs, preferences and deal-breakers. It uses FINN's vehicle data where available, supplemented by published external reference data for some values, such as plug-in hybrid electricity consumption and German CO₂ classification rules. Lens labels its own estimates and assumptions separately.

For cost estimates, Lens assumes petrol at €1.75/L, diesel at €1.70/L and electricity at €0.32/kWh. It estimates 1,000 km/month if the reader hasn't specified a distance. Mileage packages come from FINN's data, which lists for every car what each package adds to the monthly price — 500 km/month at no extra cost, up to 5,000 km. Lens adds the smallest package that covers the reader's distance, and FINN's per-kilometre price only beyond the largest. For a car whose data doesn't list its packages, Lens assumes 500 km/month is included and says so. Parking and tolls aren't included.

Every mechanism, number and source is written up in
[\`HOW-FINN-LENS-DECIDES.md\`](HOW-FINN-LENS-DECIDES.md).

## Data and privacy

- Everything Lens keeps — chats, saved answers, the cars it has read — stays
  in the browser, up to the 40 most recent chats. Settings shows all of it and
  deletes any of it, and uninstalling Lens removes it.
- There's no account and no Lens server. Its only requests are to finn.com —
  for FINN's own API, for cars on the page it hasn't seen yet — and for the
  car photos FINN's data links to.
- No AI model is involved. Typed words are read by fixed keyword rules.

## Known limits

The beta guide lists these in full, with what hasn't been checked yet. In
short:

- **Tried in Chrome only.** Firefox and other browsers are untested.
- **English only**, on finn.com's German pages.
- **It depends on finn.com's pages and data as they are now.** A change to
  either can stop Lens reading cars until it's updated.
- **Typed words are read by keyword rules**, not a model. They understand
  needs, money, distance and deal-breakers, but not dates ("from March"):
  Lens says when it didn't catch something, and every question can be tapped.
- **Costs are estimates**: FINN's price, plus fuel or electricity at the
  assumed prices above, plus the mileage package the distance needs. Parking
  and tolls aren't included.
- **Dates count as fixed until the reader loosens them**, and many FINN cars
  are offered only on a 12-month term, so a longer rental can leave few cars.
  Lens then offers the nearest dates a car on the page can be rented for.
- **Some things FINN's data can't say aren't judged**: boot space (FINN's
  figure doesn't say whether the seats are up), seat comfort, crash-test
  results.
- In a car's drawer, **"Why it won" names Lens's own categories** (for example, "city & parking") rather than only the reader's words. A preference marked "Seals it" increases its importance in scoring; it isn't a hard requirement. "Must have" is a hard requirement.
- **Large listings**: on a filtered listing, Lens compares up to about 150 of the matching cars at once. That's Lens's own limit, not FINN's: when more match, it says how many it compared out of how many there are (for example, 150 of the 408 petrol cars). Larger comparisons haven't been tried.
- **Score bands are provisional**: Strong starts at 65/100, Good at 45, Partial at 25, and Limited is below 25. These thresholds may change as the beta is tested.

## How it was built

Finn Lens is an independent project by Orjwan Al-Rajaby. It isn't a FINN
product, and it isn't for sale.

- **Orjwan's work:** the idea and the problem it starts from; investigating
  finn.com — how its pages are rendered, on the server and in the browser, and
  how an extension can work alongside them; working out what each field in
  FINN's car data means; the product's direction and its decision model (what
  Lens asks, what counts, what rules a car out, how much each answer weighs);
  and the first versions — the extension's foundation and its reading of
  FINN's car data (August 2026).
- **Built with Claude Code:** from September 2026, Orjwan directed the
  development with Claude Code, Anthropic's AI coding assistant, which wrote
  most of the code from then on — every commit in this version's history since
  then is marked as co-authored with it. Orjwan decided what to build and what
  to change, and tested it on finn.com.

Lens went through several designs before this one — pinning cars to compare, a
settings screen of priorities, a chat answered by an AI model — before the
guided conversation in this beta.

The code is a beta codebase: it typechecks, has around 950 automated tests,
and was audited for this release, but it grew with the product rather than to
engineering standards set up front, and hasn't had the review a production
product would.

## Feedback and bug reports

Found a bug, an incorrect result, something confusing, or an idea for improvement? Send your report to the person who supplied you with this beta.

You don't need to diagnose the problem. Describe what you were trying to do, what happened, and how someone else could reproduce it.

**What to put in a report**

Your chats are kept only on your computer, so whoever reads your report can't
open them. Lens can only be checked by doing what you did, step by step.
Include whatever you can, in this order:

1. **What kind of issue it is:** a bug (something broke, didn't respond, or
   behaved unexpectedly), or a faulty or incomplete result (a pick or score
   looks wrong, something is missing, or the explanation doesn't match the
   recommendation). Suggestions are welcome too.
2. **Steps to reproduce it:** the full finn.com address you were on, including
   any filters; each answer you gave Lens, in order, tapped or typed; anything
   you changed under "This doesn't look right"; and what you did after the
   result.
3. **What happened:** what Lens showed or did, the car it concerns, and any
   error message.
4. **What you expected,** and why.
5. **Screenshots and the PDF:** screenshots of the chat and the page, and for a
   result, the PDF (click the car's chip, then **Save as PDF** in its drawer).
6. **Anything else that might help:** your browser and its version, and
   anything you noticed along the way. The Lens version is **0.9.1**.

**A useful report doesn't need to be technical.**

For example: "I selected these answers, changed this priority, and expected this car to win, but Lens picked another one. Here's why I expected a different result."

A surprising result is useful even if it isn't a bug. It may reveal a scoring issue, missing data, or a trade-off Lens should explain more clearly.
`},{id:`changelog`,file:`CHANGELOG.md`,label:`Changelog`,number:`03`,source:`browser-extension/CHANGELOG.md`,markdown:`# Changelog

## 0.9.1 beta — 12 October 2026

The build for the first outside review. Everything 0.9.0 does, plus:

- **A beta guide** in Settings (its own tab, and a link from the popup): what
  Lens is and why, how it decides, how to read its results, its known limits,
  what might come next, and what a bug report needs to be reproduced — with
  its contents pinned beside it on a wide screen, following the reading.
- **A product demo** in Settings: a reader's journey through Lens, in
  screenshots — each opens full size, to zoom into and step through.
- **The guide and the demo as a web page**, published to GitHub Pages by a
  workflow (\`site/\`, \`.github/workflows/pages.yml\`), with the branch's
  documentation as a third tab, read from the repository's own markdown —
  a tab in Settings too.
- **How it was built**, in the guide, the beta note and the README: whose
  work the idea, the research and the decision model are, and how Claude Code
  built the rest.
- **"What you told me" and the Adjust panel** say each question once, with
  every answer under it; the Adjust panel slides in beside a widened chat, and
  the chat can be expanded from its header and resized from its corner.
- **Every car's drawer saves as a PDF**, not only the winner's — all but a car
  that was ruled out. The PDF links each car it names to FINN and keeps its
  blocks whole across pages.
- **The winner is called the winner** wherever another car is compared with
  it, in its gold; each car's drawer tags what it runs on, how much it uses
  and its CO₂.
- **No car fits the dates:** Lens offers the nearest dates a car on the page
  can be rented for, and "a month either way" only where that finds one.
- **Each chat has a short name of its own**, such as "Chat 7KQ-M4X".

Fixed in the final check:

- When every car was over the budget, the winner's headline called it "the
  strongest match for what you told Lens" without saying it was over budget.
- On a filtered listing broader than Lens takes in at once (about 150 cars),
  the chat said it had judged "the cars matching your filters"; it now says
  how many of them it judged.
- Settings' delete confirmations lowercased Lens's name.
- The package no longer ships two unused logos from the project template.
- Answers that changed nothing are gone: "Driveway" (where you park) and
  "Keyless entry & start" (a comfort on 653 of FINN's 698 cars, which could
  only be checked and moved no score beside most comforts). "Booster seat"
  stays — it's the answer for kids past a baby seat — and now says what it
  means. Every answer left changes something, and a test holds them to it.
- Standard equipment Lens says it checks ("Also making sure it has") is now
  said only where it can mark a car down: inside a priority something else is
  scored in. "In traffic" alone no longer claims an automatic gearbox, nor
  "In the city" emergency braking.
- The demo's screenshots are retaken from this build on live finn.com, as
  WebP, named for what they show.
- The previous version's settings layer is gone from the engine: loading,
  saving and migrating stored priorities, profiles and feature picks, which
  nothing in this build called. Settings still clears what that version
  stored.
- Other code nothing used is gone too — a filters-to-answers reader, plain
  sentence summaries, offers and what-ifs, the old follow-up catalogue, and
  pieces meant for an AI model — and unused code is now a type error.

## 0.9.0 beta — 7 October 2026

The first build shared outside development, for FINN's team to try. From here
the beta is frozen: only fixes go in until it's been tried.

What it does:

- **Chats on finn.com.** A bubble in the corner opens Lens. It asks about the
  reader's life a section at a time (who rides along, how and where they
  drive, what the car copes with, what else matters), then the monthly limit,
  dates, distance, fuels and deal-breakers, and says back what it understood
  before judging anything.
- **Judges the cars on the page** — every car matching the reader's filters
  on a listing — against what they said, using only FINN's own data and
  arithmetic on it, plus named, linked European sources where FINN has no
  figure.
- **Chips on FINN's cards** with each car's verdict, and a gold chip on the
  pick; **drawers** behind them with how each car fits, what it costs, and
  why the pick won. The pick's drawer saves as a PDF.
- **The "i"** beside an answer opens a small panel beside the chat, on its
  left, saying what it means and what Lens checks.
- **Many chats**, kept in the browser; **saved answers** new chats start from;
  **Settings** to see and delete everything Lens keeps.

Made for the beta:

- The pick past a limit — nothing within the budget, nothing for the dates —
  is called the closest match everywhere, and the result says which limit.
- Typed words are read the way a tap would set them ("I don't want an
  electric car", "I need an automatic", "30,000 km a year").
- A broken page shows a way out instead of a blank frame.
`},{id:`how-lens-decides`,file:`HOW-FINN-LENS-DECIDES.md`,label:`How Lens decides`,number:`04`,source:`docs/HOW-FINN-LENS-DECIDES.md`,markdown:`# How Finn Lens decides

> **What this is.** The reference for how Lens turns a conversation into a judgement of the cars on a
> finn.com page: every mechanism, every number, the reasoning behind each decision, and what each one
> rests on — FINN's own data, arithmetic on it, a published European source, or Lens's own labelled
> assumption. Written for anyone changing the engine, reviewing it, or checking a claim it makes.
>
> **State described:** branch \`life-bubbles\`, beta 0.9.1 (12 October 2026). \`npx tsc --noEmit\` clean,
> \`npx vitest run\` green (957 tests).
>
> **Related documents.** [\`FINN-LENS-EMISSIONS-SCORING.md\`](FINN-LENS-EMISSIONS-SCORING.md) is the long
> form of the CO₂ and efficiency scoring (§7 here summarises it).
> [\`LIFE-BUBBLES-SPEC-v2.md\`](LIFE-BUBBLES-SPEC-v2.md) is the design of the conversation, with an "As
> built" log of what changed after trying it. The code comments are the last word on any detail; this
> document points to the files.

---

## Contents

1. [The rule behind everything: where a claim may come from](#1-the-rule-behind-everything-where-a-claim-may-come-from)
2. [The pipeline, end to end](#2-the-pipeline-end-to-end) — and [reading FINN's data](#21-reading-finns-data)
3. [What the reader is asked, and what each answer does](#3-what-the-reader-is-asked-and-what-each-answer-does)
4. [From answers to engine settings](#4-from-answers-to-engine-settings)
5. [Scoring one car in one priority](#5-scoring-one-car-in-one-priority)
6. [Measurements: size, range, charging](#6-measurements-size-range-charging)
7. [CO₂ and efficiency](#7-co₂-and-efficiency)
8. [The fit, and the bands](#8-the-fit-and-the-bands)
9. [Hard constraints: what sets a car aside](#9-hard-constraints-what-sets-a-car-aside)
10. [Cost](#10-cost)
11. [Who may win](#11-who-may-win)
12. [What the reader is shown](#12-what-the-reader-is-shown)
13. [Sources register](#13-sources-register)
14. [Lens's own assumptions](#14-lenss-own-assumptions)
15. [Decisions considered and rejected](#15-decisions-considered-and-rejected)
16. [Known gaps and open items](#16-known-gaps-and-open-items)
17. [Refreshing the data](#17-refreshing-the-data)

---

## 1. The rule behind everything: where a claim may come from

Every figure Lens shows, every link between a need and a piece of equipment, every score input and every
cost must come from one of four places — and the reader must be able to see which:

| Source | What counts | How it's shown |
|---|---|---|
| **FINN's data** | What FINN's API returns for a car: equipment flags, fuel type, consumption, CO₂ figure and class, dimensions, electric range, prices per term, mileage packages, delivery windows, tyre setup. | As the car's own fact. "Listed" and "not listed" are facts; only an absent field is unknown. |
| **Arithmetic on FINN's data** | Anything derived from FINN's figures: a shorter car needs a shorter gap; consumption × price; how many cars on this page are low CO₂. | As Lens's working, with the inputs named. |
| **Published European sources** | EU regulations and data (EEA registrations, Regulation (EU) 2019/631), German law (Pkw-EnVKV), the European Commission's reports, studies and tests by the ICCT and the ADAC. | Named **and linked** where the claim is made, with the caveat that it's that source's figure or finding, and what it can't tell the reader. Each figure was checked in the actual document before use (§13). |
| **Lens's own assumptions** | A number Lens has to pick with no source to take it from: a fuel price, a band threshold. | Labelled as an assumption every time ("an assumed fuel price of €1.75"). Listed in §14. |

What is **not** allowed, and has been removed when found:

- **General knowledge dressed as fact.** "Petrol, including hybrids you don't plug in", "a plug-in's figure
  assumes it's charged often", "typically more speakers", "making electricity isn't free of emissions" —
  none of these is in FINN's data, and none was sourced. Cut, or replaced by what FINN's data says and
  doesn't say (§15).
- **An unsourced number presented as a bound.** The "30 kWh/100 km allowance" for plug-in hybrids had no
  source; it was replaced by the EU's official figure for each car (§10.3).
- **Claiming more than FINN's field says.** FINN's "Sitzheizung" doesn't say which seats; "Parkassistent"
  doesn't say whether it steers; "Anhängerlast" doesn't say braked. The copy says exactly that much.
- **A claim out of its context.** The Commission's 3.5× real-world gap for plug-ins is for cars registered
  in 2021, before the EU changed the method in 2025 — so it's always said with that date (§7.3).

**Unknown is never no.** A field FINN doesn't send is unknown. An unknown item is left out of a score
entirely — never counted as absent, never as average (§5). A cost that can't be calculated is never €0
(§10). A hard constraint can't be met by a car whose data can't confirm it (§9).

---

## 2. The pipeline, end to end

\`\`\`
 Conversation (lib/chats/flow.ts)
   bubbles · how often · limit · period · from when · distance · fuel · deal-breakers & sealers
        │
        ▼
 Understanding (lib/lens-chat/understanding.ts, bubbles.ts, deals.ts)
   needs (each: importance + evidence it counts / checks)   rules (must / mustn't)
   budget (amount, hard / some give)   rental (from → to)   monthly km
        │  toAnswers()
        ▼
 Engine settings — "Answers"
   priorities in order + each one's share     items raised per priority, at a level
   standard items to check                    preferences (budget ceiling, dates, km, prices)
        │  runLens() (lib/lens-chat/run.ts)
        ▼
 1. Rules set cars aside (deal-breakers, fuel)        → if none left: rank all, ask what to let go
 2. buildRecommendation() (lib/reasoning-engine/index.ts)
      cost for every car → budget status → score every car → eligibility tiers → winner
 3. A firm limit sets aside cars over it, or not confirmed within it
 4. Nothing within the limit → rank the cars nearest it
        │
        ▼
 Judgement (lib/chats/judge.ts) → a verdict per car, the result card, chips on finn.com
 Fit story (lib/lens-chat/fit-story.ts) → the drawer's "whole case" for any car
\`\`\`

Two separations run through it:

- **Budget never touches the score.** Cost decides who is *allowed* to win; the score decides who is
  *best*. A cheap car scores no higher for being cheap (\`buildRecommendation\`, index.ts).
- **A car's score depends on that car and the reader's settings only.** No other car on the page can move
  it (\`scoreVehicle\`, scoring.ts). Viewing one car alone and the same car in a comparison give the same
  score; adding a car never reorders the others. The exceptions are explicit and said: efficiency is read
  against cars on the same fuel (§7.2), and "N of the cars here" counts are about the page.

### 2.1 Reading FINN's data

Every car enters Lens through one mapper: \`mapFinnConfig\` (\`entrypoints/content/manipulateApiData.ts\`),
with the field readers in \`lib/helpers.ts\` and FINN's shape in \`FinnApiConfig\` (\`lib/types.ts\`). The
readings below were checked on 7 October 2026 against six pages of \`/api/cars\` exactly as finn.com sent
them — 127 of the 151 cars FINN listed that day — against the listing those pages drew, and against the
fleet snapshot (§17).

| FINN sends | Lens reads | Why |
|---|---|---|
| \`price.b2c_12\`, \`b2b_12\`, … — the monthly price per term, nothing upfront | The term's price from \`price.available_price_list\` first, the top level where the list leaves a term out (\`extractContract\`) | On an early-booking offer ("Frühbucherangebot") the top level still holds the price before the discount — the list's \`b2c_12_old\` — and only the list holds what FINN charges now: 5 of the 127 cars, €10 a month each, and 10 of the 698 in the fleet snapshot. Everywhere else the two agree. finn.com's cards show the same: the CLA electric's card strikes through €799 and charges €789 (with €1,500 down), and €789 plus €1,500 over 12 months is the list's €914. All 35 single-configuration cards match the list this way. |
| \`downpayment_prices\` — the same prices after a €1,500 down payment | Only its list price (\`msrp\`) and per-km price | Its monthly prices are lower by exactly €1,500 spread over the term; quoting them without the €1,500 made every car look cheaper. |
| \`available_terms\`, \`default_term\` | The terms on offer, and the one to quote when the reader gives no period | The price object can carry terms that aren't on offer, so prices are read through \`available_terms\`. |
| \`availability_by_term\` — per term: first delivery, last, the weeks it may slip, and the delivery batches | Each term's window, dates cut to the day | Dates arrive as midnight UTC, so cutting doesn't move the day. The slip belongs to the earliest batch. The car's headline window is the priced term's: FINN's \`default_downpayment_term\` differs from it on 14 cars. |
| \`extra_500\` … \`extra_5000\`, \`extra_km_price\` | Mileage packages, and the per-km price beyond the largest (§10.1) | \`extra_1000_old\` and the like are struck-through prices and are skipped. |
| \`ev_range\` as text — \`"571"\` | A number of kilometres | It's text on every electric car. The facts handed to the model only accepted a number, so the model had no electric car's range until this was read. |
| \`Batteriekapazität\` as text — \`"77.03 kWh"\` | A number of kWh | Listed for some petrol and diesel mild hybrids too; read for electric cars only. |
| \`tires\`: \`all_season\` (110), \`winter\` (13), \`summer_winter\` (4); in the fleet snapshot 581, 44 and 73 | All-season, winter, or a summer and a winter set: shown under Climate Suitability, never scored | Winter tyres were read as "FINN doesn't say" until 7 October 2026. |
| \`co2emission\`: \`null\` on all 25 electric cars; \`consumption\` and \`co2_class\` absent on one petrol car | An electric car's CO₂ as 0 g/km, since it has no tailpipe (\`assessEnvironment\`, §7); any other missing figure as unknown, never 0 | §1: only an absent field is unknown. The petrol car with neither figure gets no environmental reading. |
| \`closed_features_list\` — flags, and text for figures (\`"1500 kg"\`, \`"28 Min."\`, \`"Level 2"\`) | \`true\` is listed, \`false\` is a real no, absent is unknown (§5) | Wireless CarPlay is answered \`"Ja (Kabellos)"\` or \`false\`. Keyless entry & start counts when FINN lists it as one entry or as both halves; on 19 of the 127 the one entry says yes while a half says no (88 of the 698 in the snapshot), and the one entry is taken. |
| \`config_drive\` — six spellings: Frontantrieb, Heckantrieb, Allrad, FWD, RWD, AWD | Front-, rear- or all-wheel drive | |
| \`equipment\`, \`equipment_packages\` — FINN's German prose | Carried verbatim for the model, packages first, without FINN's data-audit notes | 97 of the 127 cars carry notes like "Audit override: hasLeatherSeats" or "Audit override: dcChargeTime10To80 = 0.37" (hours, beside FINN's "22 Min."). They say which field someone corrected, not what the car has; on 18 cars a whole group was nothing else. Items are split on FINN's \`equipment_delimiter\` (", "); a comma inside an item is written "٫". |

---

## 3. What the reader is asked, and what each answer does

The questions, in order (\`STEP_ORDER\` and \`BUBBLE_STEPS\`, flow.ts). Each open question shows
"Answered *n* of *m*"; the total grows or shrinks as answers add or remove questions.

### 3.1 The bubbles: four sections

| Section | Bubbles |
|---|---|
| Who rides with you? | Kids · Adults or teens · A dog |
| Where and how do you drive? | In the city · In traffic · Long distances · At night |
| What does the car have to cope with? | Tough weather · Lots to carry |
| What else matters to you? | Help driving & parking · Comfort · The environment · A budget |

Each bubble (\`BUBBLES\`, bubbles.ts) carries:

- **counts** — equipment Lens scores for it (it earns when listed);
- **checks** — standard equipment Lens checks for it: a car FINN says lacks it loses a little, and having
  it earns nothing (§5.2). A check can only mark a car down inside a priority something else is scored in,
  so it's said only where that's true: the chat's summary card lists it under what Lens checks when the
  reader's answers score its priority (\`summaryBubbles\`, flow.ts), and a bubble's "i" names it ("Also making
  sure it has: Air conditioning", with a hint from the cars on the page — "Nearly every car here has it, so it
  won't set the cars apart — but a car without it would lose out") only when it counts however that bubble's
  own question is answered (\`alwaysChecked\`, flow.ts). An automatic gearbox under "In traffic" counts only
  beside "In the city", so it's on the summary then and not behind the "i";
- **worth** — suggestions shown as "Might matter" on the summary, counted only if the reader adds them;
- **cantCheck** — what FINN's data can't tell Lens, said on the summary and in the drawer **only where it
  changes how an answer reads**. Today that's one: boot space under "Lots to carry" (FINN's figure doesn't say
  whether the seats are up or folded). A list of everything Lens can't check under every need was noise nobody
  asked for, and was removed; gaps the reader of typed words notes aren't shown either;
- **why** — for each item, why it's there for this need. A link with no honest reason is removed, not
  justified.

Some bubbles open a row of **chips** (follow-ups) that change what's counted:

| Bubble | Chips (what each adds) |
|---|---|
| Kids | Which child seat? — Baby or toddler seat (makes kids a top priority; suggests electric tailgate) · Booster seat (kids stay Important, with the rear doors and ISOFIX any child seat needs — the answer for a parent whose kids are past a baby seat). Either or both; both is the same as a baby seat. |
| Adults or teens | No follow-up: taken to ride in the back — rear doors; suggests 3-zone climate and rear USB ports. |
| In the city | Where you park, up to two: street (reversing camera) · home garage (width counts more; folding mirrors checked) · multi-storey (360° camera; folding mirrors) · open car park (rear cross-traffic alert). Optional: a driveway asks nothing of the car, so it isn't an answer. |
| Help driving & parking | Parking (360° camera; sensors checked) · **Parallel parking** (a shorter car, 360° camera; parking assistant and sensors checked) · Traffic & lane changes (blind spot; lane keeping checked) · Reversing out (rear cross-traffic alert, reversing camera) |
| Tough weather | Snow & ice (snow can't come without cold, so it counts heated seats & wheel itself; **recommends all-wheel drive** — §9.2) · Rain & fog (rain & light sensors, fog lights; mild or cold) · Cold winters (heated seats & wheel; wet or dry, so it combines with rain) · Hot summers (ventilated seats). Any combination; snow & ice with cold winters is the same as snow & ice alone. |
| Lots to carry | Shopping (electric tailgate) · Bulky things (split-folding seats) · Bikes, skis, roof box (roof rails) · Trailer or caravan (towbar, 1,500 kg towing; suggests the towbar deal-breaker) |
| Comfort | 13 comforts FINN lists, each by name, up to seven picked (heated seats, heated wheel, ventilated seats, pre-heating, wireless CarPlay / Android Auto, wireless charging, 3-zone climate, electric seats, lumbar support, premium sound, sunroof, rear USB ports, head-up display). Keyless entry & start was one until October 2026: it's standard on 653 of FINN's 698 cars, so it could only be checked, never scored, and changed no car's score alongside most comforts — an answer that did nothing. Nothing picked: the bubble asks which, and counts nothing. |
| The environment | **How green should the car be?** — §7.4 |
| A budget | How firm: Hard limit · Some give — §9.4 |

Chip rules: every chip is one the reader picks — there's no "Select all". Required questions (child seat,
help with what, the weather, what you carry) need at least one; where you park takes up to two and the
comforts up to seven. **Every answer does something**: each changes what's counted, checked or suggested,
how much the bubble counts, the figure it's judged on, a suggested deal-breaker or the budget's firmness —
against leaving the question unanswered where it can be, and against every other answer to it. The one
exception is "Moderately green", which names the default "The environment" has with no answer
(\`bubbles.test.ts\`, "every answer does something").

**Recommended comforts.** Comfort chips that earlier answers point to are starred, first, with the reason
(\`RECOMMENDED\`, \`recommendedBecause\`, bubbles.ts): heated seats and pre-heating for snow & ice or cold winters;
a heated wheel for the same, "and you spend a lot of time on the road" beside long distances or traffic;
lumbar support and wireless CarPlay / charging for long distances or traffic; and so on. Nothing is picked
for the reader. Rain alone doesn't recommend warmth; a bubble's own answers never recommend its own chips.

### 3.2 How often (long distances, traffic)

Asked only for a bubble that has it (\`OFTEN\`, bubbles.ts). It sets how much the bubble counts: every day /
every week → Top priority; about once a month → Important; a few times a year → Nice to have. Traffic:
over 45 min → Top priority; 20–45 → Important; under 20 → Nice to have. Long distances also makes the
distance question matter, and "every day" leaves 500 and 1,000 km a month out of it — daily long drives
can't add up to so little.

### 3.3 How much something counts — one scale

Top priority · Important · Nice to have (\`IMPORTANCE\`, \`lib/lens-chat/importance.ts\`). Each counts twice the
one below (\`NEED_WEIGHT\` 4 : 2 : 1, understanding.ts). Said to the reader in words, never numbers:

- **Top priority** — counts the most, twice as much as Important; a car without it can still win, but only
  by being clearly better at everything else.
- **Important** — counts fully, alongside everything else said to be important.
- **Nice to have** — counts half as much as Important: enough to settle a close call.

None of them rules a car out. "Must have / Must be / Mustn't be" are reserved for deal-breakers, so the two
vocabularies never meet. A bubble starts at Important unless a chip or "how often" says otherwise, shown as
"My guess — tap to change".

### 3.4 Money and time

- **Limit**, "all costs together": FINN's monthly price (VAT included), plus estimated fuel or charging, plus
  the mileage package the reader's distance needs. Parking and tolls are not in it.
- **How long**, then **from when** (next month is the soonest — FINN delivers in weeks — and the three after,
  or later). The length is kept when the start moves.
- **How far**, asked only when something said makes it matter; otherwise 1,000 km/month, said as assumed.

### 3.5 What it can run on

Electric · Plug-in hybrid · Petrol · Diesel, any or all, only the fuels on the page (\`fuelStep\`, flow.ts).
Not asked when the page has one fuel. Fuels not picked are set aside before scoring (§9.1). Each choice says
only what FINN lists:

- FINN has exactly four fuel types — no "hybrid". Where FINN files cars with "Hybrid" in its own engine name
  under petrol (86 in the fleet snapshot, e.g. "Toyota Yaris 1.5-l-VVT-i Hybrid 116 CVT"), Petrol's "i"
  counts them from the page.
- Plug-in hybrid's "i" says FINN gives only the fuel figure, and the electricity is the EU's figure (§10.3).
- Stars from how green (§7.4): totally green → Electric; moderately green → any fuel most of whose cars on
  the page are low CO₂, with the count.

### 3.6 Deal-breakers & deal-sealers

One row per thing (\`DEALS\`, deals.ts): Over my limit · Available for my dates (My dates only · A month either
way — §9.5) · Low CO₂ emissions · Frugal for its kind · Automatic
gearbox · SUV · Rear doors · Six or more seats · Towbar · All-wheel drive. Each set to:

| Option | Means |
|---|---|
| Doesn't matter | Not part of the judgement. |
| Must be / Must have | A deal-breaker: any car without it is set aside before scoring. |
| Mustn't be | A deal-breaker: any car that is one is set aside before scoring. |
| Seals it | A deal-sealer: counts as a top priority, but a car without it can still win. |

The meanings are shown as a key under the question. A row offers only what Lens can do with it here: a rule
only where it would split the cars on the page; "Seals it" only where Lens can score the thing and the cars
here differ on it. A row Lens can only rule on says so ("I can only rule on this, not weigh it — so it can't
seal the deal"). Rows the reader's answers point to come first, starred, each saying which answer
recommended it.

### 3.7 The summary, and adjusting it

"Here's what you told me, and what I understood" is read-only: each thing said, how much it counts, what
Lens will check; then money & time and deal-breakers & sealers. **Looks good to me — continue** goes on;
**This doesn't look right** opens the Adjust panel (beside the chat, which widens for it) with every
editable card: take an item out, add a suggestion, set how much each counts, or change an answer.
"Change" on a single line asks that question again; on "Your life" it first asks whether to go through all the
questions again or pick which. Every question asked because the reader chose to change something offers
**Never mind — keep my answers**, which puts the chat back exactly as it was before the first change
(\`neverMind\`, flow.ts) — summary, open question, Adjust panel and all.

---

## 4. From answers to engine settings

\`toAnswers()\` in understanding.ts. In the chat it runs **asked-only** (\`countOnlyAsked\`): Lens ranks on what
the reader asked for and nothing else.

### 4.1 Which priorities, in what order

The engine scores seven priorities (\`CATEGORIES\`, constants.ts): Safety & Driver Assistance, City & Parking,
Practicality, Long Distance Travel, Climate Suitability, Comfort, plus Environmental Impact and Efficiency
(figure-only, §7). A need **holds** a priority by the equipment of its that is scored there — not by naming
it. "Kids in the back" named Safety and held nothing Safety scores, so parents were once judged on blind
spot warning; that was the bug this rule fixes. A need with no equipment (CO₂) holds the priority it names.

Order: the strongest single need decides a priority's place; how many needs it serves only breaks ties. No
padding: in a chat, a priority nothing the reader said points to isn't scored at all.

### 4.2 How much each priority weighs

- **Chat (asked-only).** Each need contributes its importance weight (4 / 2 / 1) **split evenly across the
  priorities its equipment sits in**; a priority's share is the sum of what its needs put there
  (\`priorityShares\`). So seven items for kids don't outweigh one CO₂ figure seven to one: a need is a need,
  however many items Lens checks for it.
- **Without shares** — the playground branch's settings screen, not part of this build. By rank: with *n*
  priorities the first weighs *n*, the next *n−1*, … over their sum (\`priorityWeights\`, scoring.ts).

### 4.3 How much each item weighs inside a priority

\`FEATURE_IMPORTANCE\`, constants.ts. Every catalogue item counts once (\`BASE_FEATURE_WEIGHT\` = 1). An item
singled out counts again for how much: Somewhat 2, Moderately 3, Highly 4. Steeper than this (the old 5 : 1)
let five picks drown out the ten to fifteen other things a priority is made of.

In the chat, a need's items are raised at its importance (\`RAISE\`: Top priority → Highly, Important →
Moderately, Nice to have → Somewhat). A few chips count an item one step higher (\`STRONGER\`): a home
garage makes width count more. Items a rule already settles aren't raised — every car left has them, so
raising them adds the same to each. Things the reader wants absent are never raised.

---

## 5. Scoring one car in one priority

\`categoryDetail()\` in scoring.ts.

### 5.1 The arithmetic

\`\`\`
featureScore = 100 × max(0, Σ weight × utility  −  Σ weight of standard items FINN says are missing)
                     ───────────────────────────────────────────────────────────────────────────────
                                       Σ weight of items whose utility is known
\`\`\`

- **utility** is 1 (listed), 0 (not listed), or a 0–1 reading for a measurement (§6). Unknown items are left
  out of numerator and denominator alike.
- **Assessed** only when at least half the priority's counted weight is known (\`ASSESSED_SHARE\` = 0.5).
  An unassessed priority is left out of the car's fit and said to be unassessed, never scored as zero.
- An item that means nothing for this car — a heat pump on a petrol car — isn't counted for it.
- **Contributions** add up exactly to the fit, one line per piece of counted evidence, so the drawer can show
  the working.
- **Bounds**: the fit with every unknown at its worst and at its best — the check behind "this could change
  depending on…" (§11.3).

### 5.2 Standard equipment

An item on at least 90% of FINN's cars (\`BASELINE_PREVALENCE\`, evidence.ts; re-checked against the fleet
snapshot on every calibration run) is **expected**: having it earns nothing, a confirmed gap costs its
weight. Counted as earning, it would add the same to every car and only squeeze the differences. Examples:
emergency braking, lane keeping, ISOFIX, parking sensors and parking assistant (685 and 683 of 698 in the
October 2026 snapshot), and keyless entry & start (653 of 698; it was 636 of 728 in September, below the line).

In the chat (asked-only, §4), a standard item weighs anything only when a need **checks** it, and only inside a
priority the reader's answers already score (\`preferences.checked\`, \`toAnswers\`, understanding.ts): the gap
is taken off what the car earned there, so in a priority with nothing scored there is nothing to take it
from. That's why the summary and the bubbles' "i" name a check only where it counts (§3.1).

One item sits on the line and is kept scored on purpose: the **reversing camera**, on 628 of 698 cars (89.97%)
— it was 631 of 701 (90.01%), one car over, in the snapshot before.
As standard, a small car without one would be marked down, which City & Parking is built not to do (a short
car needs cameras less), and street parking could only check it, never count it. The calibration test names
this exception and fails if the camera passes 92%, when it should be re-decided.

### 5.3 What's in each priority

From \`CATEGORIES\`, constants.ts. *Niche* items count only when raised (a towbar matters to someone who tows).

| Priority | Scored items | Standard (checked) |
|---|---|---|
| Safety & Driver Assistance | blind spot assist, rear cross-traffic alert, matrix LED headlights | emergency braking, lane keeping, sign recognition, eCall, tyre-pressure monitoring |
| City & Parking | compact length, compact width (§6), reversing camera, 360° camera | parking sensors, parking assistant, folding mirrors, automatic gearbox |
| Practicality | rear doors, five seats, split-folding rear seats, electric tailgate; *niche:* towbar, 1,500 kg towing, roof rails, six+ seats | ISOFIX |
| Long Distance Travel | level 2 driver assistance, lumbar support, head-up display; *niche:* spare wheel; also matrix LED. Electric cars: range and DC charging limit it (§6) | cruise control, adaptive cruise, navigation |
| Climate Suitability | heated seats, rain & light sensors, heated wheel, cornering lights, seat cooling, fog lights, auxiliary heater, headlight cleaning, heat pump; *niche:* all-wheel drive | air conditioning |
| Comfort | wireless charging, premium sound, 3-zone climate, electric seats, wireless CarPlay / Android Auto, sunroof, rear USB | CarPlay / Android Auto, keyless entry & start |
| Environmental Impact / Efficiency | figures, not equipment (§7) | — |

**Boot space is not scored** (\`BOOT_SCORING_ENABLED = false\`): FINN's litres are seats-up on one car and
seats-folded on the next — the same BMW X1 appears at 1,545 L and 500 L. The curve is ready; it stays off
until a seats-up source is verified.

---

## 6. Measurements: size, range, charging

Fixed curves in evidence.ts, straight lines between anchors, flat beyond the ends — so a car's reading
depends on the car alone. The anchors come from the distribution of FINN's own fleet.

| Reading | Anchors (value → utility) | Why |
|---|---|---|
| Compact length | 4.0 m → 1 · 4.3 → 0.8 · 4.6 → 0.55 · 4.9 → 0.3 · 5.2 → 0 | Flat at 4.0 m and shorter so a tiny car isn't rewarded for being ever tinier. A shorter car needs a shorter gap — the parallel-parking reasoning is this, from FINN's length. |
| Narrow width | 1.75 m → 1 · 1.85 → 0.7 · 1.95 → 0.35 · 2.05 → 0 | FINN's cars run 1.60–2.24 m, most 1.82–1.90 m. |
| Electric range (limits Long Distance) | 300 km → 0.55 · 350 → 0.7 · 400 → 0.85 · 480 → 1 | Can only lower the score. Past 480 km what separates cars on a long drive is charging speed. An electric car with no published range is unassessed there. |
| DC charge 10–80% (limits Long Distance) | 30 min → 1 · 45 → 0.85 · 60 → 0.7 | Flat to 30 min, where most of FINN's electric cars sit (median 26; slowest 52). Gentler than range: a slow charge makes a stop longer, a short range makes more of them. |

---

## 7. CO₂ and efficiency

The long form, with the reasoning and evidence, is [\`FINN-LENS-EMISSIONS-SCORING.md\`](FINN-LENS-EMISSIONS-SCORING.md).
In short (environmental.ts):

### 7.1 Environmental Impact is the CO₂ figure, on the German label

- **One figure, not four.** The old model averaged CO₂ g/km, CO₂ class, consumption and fuel type. Since the
  Pkw-EnVKV amendment of February 2024 the German class is a pure function of WLTP CO₂ (A at 0 g/km, B to
  95, C to 115, D to 135, E to 155, F to 175, G above), and a combustion car's consumption *is* its CO₂ times
  a constant. Scoring them separately counted one measurement several times.
- The class boundaries are the regulation's, not Lens's (Pkw-EnVKV, §13).
- **Electric cars:** FINN sends class A but no g/km figure; class A on the German label is 0 g/km, so Lens
  fills the gap with 0 and says where it comes from. The figure covers driving only, not making the
  electricity, and FINN's data doesn't say where the reader's would come from.
- For comparison, new combustion cars emit about 136 g/km (ICCT: about 134 g/km, flat since 2021, from EEA
  data — §13).

### 7.2 Efficiency is consumption, against cars on the same fuel

A litre and a kilowatt-hour aren't comparable, so efficiency reads each car against **Lens's reference for
its own fuel**: for combustion cars, the litres equivalent of 136 g/km; for electric cars, 17 kWh/100 km,
rounded up from the ICCT's 16.2 kWh/100 km sales-weighted official figure for medium electric cars in
2023 (§13). Said as "Finn Lens's reference", never as what cars "typically" use. A plug-in hybrid isn't
graded on efficiency: there is no petrol or electric car it can fairly be measured against.

### 7.3 Plug-in hybrids

- FINN gives a plug-in hybrid one CO₂ figure and doesn't say how much of the driving behind it is on
  electricity, so the figure can't be checked against how the reader would drive.
- **So it can't be rated Strong**: the best a plug-in can reach is the top of Good (\`PHEV_CEILING\` =
  \`STRONG_FROM − 1\`). No corrected figure is invented; among plug-ins a lower official figure still ranks
  higher.
- **Sourced context, always with its date:** the European Commission found plug-ins registered in 2021
  emitted on average 3.5 times their official CO₂ on the road (SWD(2024) 59). The EU changed the official
  method from 2025 (Euro 6e-bis), and FINN's figures use the new one — so the 3.5× is never applied to
  FINN's cars, only reported with its date.

### 7.4 How green should the car be?

The environment bubble's question (bubbles.ts):

| Answer | Judged on | Suggests / stars |
|---|---|---|
| Clean for its fuel type | Efficiency — consumption against cars on the same fuel, as FINN lists it | Nothing |
| Moderately green | CO₂ class (low CO₂ = class A–C, 115 g/km or less) | Low CO₂ deal-breaker; stars fuels most of whose cars here are low CO₂ |
| Totally green | CO₂ class, as a top priority | Stars Electric (FINN lists electric cars in class A, 0 g/km on the label) |
| *(nothing picked, e.g. "eco-friendly" typed)* | CO₂ class | Low CO₂ deal-breaker |

How much it counts stays on the one scale, on the summary.

---

## 8. The fit, and the bands

- **Fit** = the weighted average of a car's scores over its **assessed** priorities only (\`scoreVehicle\`).
- **Judgeable** = the reader's top two priorities are both assessed. Only a judgeable car can be
  recommended or given an overall band.
- **Bands** (bands.ts) on the 0–100 fit: Strong from 65 · Good from 45 · Partial from 25 · Limited below.
  "Not enough data" for a car that can't be judged. **Provisional**: calibrated against score distributions
  over FINN's inventory, and expected to move when that calibration runs. What each band *means* is fixed in
  fit.ts; these numbers only place the meanings.
- The 0–100 number is shown in one place: the total at the end of the winner's "How I weighed it", "this car
  scored 72 out of 100", beside the band the car's chip shows and where each band starts. Everywhere else the
  reader sees the band and counts they can check ("has 4 of the 5 things you asked for").

---

## 9. Hard constraints: what sets a car aside

Ruling a car out is not scoring it. A reader who says "no SUV" has given a constraint, and the honest answer
is the best car that isn't one (\`runLens\`, run.ts).

### 9.1 Rules: deal-breakers and fuel

\`allowedByRules()\`, run.ts:

- **Must** keeps only cars **confirmed** to have it (\`evidenceMet === true\`). Unknown doesn't pass.
- **Mustn't** sets aside cars confirmed to have it (\`evidenceMet !== false\` passes). Unknown passes. In
  practice the mustn't rules are about fields FINN always sends (fuel type, body type) — see §16.
- **What it can run on**: every fuel not picked is a mustn't rule (\`fuel\` need, flow.ts).
- A rule's own evidence isn't raised in the score (every car left has it).

### 9.2 Deal-sealers, and recommendations

A deal-sealer is a need at Top priority counting exactly that one thing (\`sealerNeed\`, deals.ts). It sets no
car aside. Rows recommended by earlier answers: snow & ice → all-wheel drive (ADAC, §13), trailer or caravan
→ towbar, moderately green → low CO₂.

### 9.3 When no car has every deal-breaker

Lens **puts the choice to the reader before showing any pick** (\`askBeforeResult\`, \`letGoAsk\`, judge.ts) —
the result and the chips on the page come only after they answer: "No car here has all of your
deal-breakers — so which matters least to you?", each with what letting it go opens up ("Let go of ‘must
have all-wheel drive’ and 3 cars fit everything else"), most first. Each one let go becomes a deal-sealer
where Lens can weigh it, or simply stops being a rule where it can only rule on it; then the cars are judged
again (and asked again if still nothing has them all). **Keep them all** shows the result, every car ranked as
if the rules weren't there, and is remembered for those exact rules (\`keptRules\`) so it isn't asked again
until the deal-breakers change. Not something to take back, since the judgement follows straight away.

### 9.4 The limit

\`budgetCeiling\`, understanding.ts; \`runLens\`, run.ts; \`resolveBudgetStatus\`, cost.ts. Each car's cost is
**within**, **over**, or **unknown** (the known part fits but something couldn't be priced). Unknown never
counts as fitting.

| Reader said | What happens |
|---|---|
| **Hard limit** (or "Over my limit: Mustn't be") | Cars over it **and cars not confirmed within it** are set aside, each saying exactly what FINN's data is missing for it. A hard limit isn't met by a car that might be over it. |
| **Some give** | Cars up to 15% over count as within (\`TARGET_HEADROOM\` = 1.15, §14); the summary says where the line is. A named stretch ("€400, maybe €425") is the line instead. |
| A limit, firmness not said | A car over it can't win while a car within it exists; it's still graded. |
| Nothing within the limit | The ranking is redone over the cars nearest the limit, and said so — not the best car at any price. |
| No limit | Cost is reported, never used to rank. |

### 9.5 The rental period and the gearbox

Three-state and eligibility-only by default (contract.ts, decision.ts): never a point added or removed — a car
that fits the dates is preferred, and see §10.4 for how a period is matched to FINN's terms.

**Dates as a rule** — the "Available for my dates" deal row, offered once there are dates (\`runLens\`, run.ts).
Dates are firm from the moment they're given (\`withRental\`, and the typed reading): the row starts on **My
dates only**, and the reader eases it to a month either way or "Doesn't matter". Changing the dates later
keeps whichever they chose.

- **My dates only**: a car that can't be rented for the dates, or that FINN's data can't confirm, is set aside
  before the limit is applied, each saying why from FINN's terms. A car the reader can't have is never the pick.
- **A month either way**: the same, but a car also counts if it fits with the start a month later or earlier
  (\`rentalFlexMonths\`, \`fitContract\`), and its cost says it isn't the exact dates.
- **No car here can be had**: Lens asks before showing any result (\`datesAsk\`, judge.ts). Keeping the dates
  means **no pick on this page**, said plainly, rather than a car they can't have. The choices:
  - **The nearest dates a car here can be had for** (\`nearestPeriod\`, contract.ts). On the first 24 cars of the
    fleet snapshot: "No car here can be rented for December 2026 to November 2029. The nearest dates any car
    here can be rented for are November 2026 to October 2028." — offered as "Make it November 2026 to October
    2028", saying how it differs and how many cars fit: "Starts 1 month earlier, 24 months instead of 36. 4
    cars here can be rented then." (None of them can start in December on a 24-month term.) Found by trying periods
    against each car's own FINN terms and delivery windows, with the same check as the dates themselves, so
    every date offered has a car behind it. **Nearest** is the fewest months moved at the start and the end
    together, up to 36 (§14); among equals, the start moved least, then the shorter period. So a period
    longer than any term keeps its start and ends sooner, and a start no car can make moves the start and
    keeps the end where a term covers it ("Starts 2 months earlier, 14 months instead of 12"). Taking it sets
    those exact dates, still as a rule, and judges again. Not offered when nothing is found within reach.
  - **A month either way** — only where it would find a car (\`aMonthOut\`, run.ts), and only if the reader
    hasn't already said so. When the nearest dates are just that (the start a month out, the same length), the
    nearest isn't offered as well: the question is the month either way.
  - **Change my dates**, or **keep them**.

---

## 10. Cost

\`calculateCost()\` and \`buildCostAnalysis()\`, cost.ts. One question only: what does this car cost? It has no
opinion on fit or winning.

### 10.1 The three lines

| Line | From | Notes |
|---|---|---|
| **FINN subscription** | FINN's monthly price for the shortest term that covers the reader's period (§10.4), private, nothing upfront, from FINN's current price list — so an early-booking discount is in it (§2.1) | VAT included for private prices (FINN advertises them so). Business pricing's VAT isn't in the data, so it's shown as supplied and said. |
| **Fuel / electricity** | FINN's consumption × an assumed price (§14) × the reader's distance | A plug-in hybrid adds the EU's electricity figure (§10.3). |
| **Mileage package** | FINN's own packages: the cheapest that covers the reader's distance, plus FINN's per-km price beyond its largest | FINN's price includes 500 km/month. The old model charged every km past 500 at the per-km price — €125 for 1,000 km where FINN's package costs €9; fixed against FINN's raw data. |

### 10.2 Missing is never €0, and is named

A line that can't be priced is left out of the total and marked, never counted as €0 — a car Lens can't
estimate must not look cheaper than one it can. What's missing is said by name (\`missingPiece\`, cost.ts),
never "part of the estimate": "FINN's private monthly price for the 24-month term — it doesn't list one for
this car", "this car's fuel consumption — FINN doesn't list one", and for an unmatched plug-in, "how much
electricity this plug-in hybrid uses — FINN lists only its fuel figure (3.8 L/100km), and its figures don't
match a car in the EU's registration data".

### 10.3 Plug-in hybrids: the EU's electricity figure

FINN lists a plug-in hybrid's official CO₂ and fuel figures but **not the electricity half of the same
test**. Every new car registered in the EU is reported to the European Environment Agency under Regulation
(EU) 2019/631 with "Electric energy consumption (EC_AC,weighted)" — point 5.2 of its certificate of
conformity (Implementing Regulation (EU) 2020/683). Lens uses that figure for the car.

- **Table** (\`lib/reasoning-engine/data/eu-plug-in-electricity.json\`, built by
  \`scripts/snapshot-eu-plug-in-electricity.mjs\`): the EEA's **2025 provisional** data only, because FINN's
  figures follow the 2025 rules (Euro 6e-bis). 2024 cars were computed under the earlier rules — the X5
  xDrive50e was 19–22 g/km and 0.9 L then, 74 g/km and 3.2 L now — so pairing across years would join
  figures that don't belong together. FINN's makers only; 4,857 variants.
- **Matching** (\`euElectricityFor\`, eu-electricity.ts): make; FINN's CO₂ and fuel figures exactly (fuel to the
  0.1 L the EU reports); and the longest run of FINN's own words that names the car ("GLA250E", "E300DE"),
  never generic ones ("xDrive" alone once paired a 330e with an X1). Engine power isn't used: FINN's is the
  whole system's, the EU's the engine's. 27 of the 39 plug-ins in the fleet snapshot match.
- **More than one version matches** (same figures, different electricity): the highest is used, and said.
- **No match**: the electricity is named as missing; the car can't be confirmed within a budget, and is set
  aside under a hard one.
- **The caveat, every time**: both figures assume the mix of electric and fuel driving set by the EU's test
  rules; how much of each the reader would really use depends on how they drive and charge. The cost line
  links the EEA source.

### 10.4 The rental period

FINN sells fixed terms (6, 12, 18, 24 months), not dates, and its data doesn't say whether a contract can be
extended or ended early. So: the term is the **shortest one on offer that covers the whole period**, priced
as such, with any months it commits the reader past their end date said out loud. Delivery is checked against
that term's own window: the car has to be deliverable in the start month. A car whose longest term is
shorter than the period doesn't cover it.

---

## 11. Who may win

\`pickEligible\`, \`pickWinner\`, decision.ts.

### 11.1 Eligibility tiers

Three hard rules, in this order: **gearbox** (a car the reader isn't allowed to drive is no use on any dates)
→ **rental period** (a car that can't be rented for the dates is no use at any price) → **budget** (a car
over budget is still one they could take). Within each, confirmed beats unknown beats ruled out. The pool
is the cars in the best tier.

### 11.2 The winner

The highest-scoring **judgeable** car in the pool; failing that, the pool's best estimate. A winner from
outside "confirmed within budget" is flagged (\`isFallback\`) and never presented as fitting the budget. Cars
over budget are never hidden — they stay ranked and inspectable.

### 11.3 What could change it

The winner with every unknown at its worst against the runner-up with every unknown at its best
(\`dependsOnFor\`). Only if the runner-up could then come out ahead is any gap named — and then every gap on
either car, since any could be the deciding one.

---

## 12. What the reader is shown

- **The result card**: the winner, a short "Why" (each thing said → what this car has for it), and "One
  thing to know" (a limit note first, else the biggest trade-off).
- **See why**: **only what the car got right** — everything it has for each thing said — and the next
  closest cars. How what was said was weighed, what it lacks and what choosing it gives up are for "The
  whole case". A thing said that the car has nothing for isn't listed as a reason it won.
- **The whole case** (the drawer, fit-story.ts): per need, what the car has and lacks, measurements against
  the scale, CO₂ and efficiency, the cost table with its sources, the rental fit.
- **How I weighed it** (the winner's drawer, \`weighingOf\`, lib/chats/weighing.ts): in the reader's own terms
  only — each thing they said, strongest first, with its importance on the one scale, its part of the decision as
  ten segments and a whole percentage (its 4 / 2 / 1 weight over all of them, rounded so they add up to exactly
  100), and what Lens looked at for it; then the car's total out of 100, with its band; deal-sealers
  as top priorities; then what set cars aside, and the money and dates. Not the engine's priority categories,
  their percentages, or the item-level "Highly / Somewhat" scale.
- **Chips on finn.com**: each judged car's band; the winner's in gold.
- **Sources**: every figure or rule that isn't FINN's is named and linked where it's said — in the chat's
  "i" tooltips (which wait a moment before closing so a link can be clicked), under the drawer's story and
  cost lines, and at the foot of its environment panel (§13).

---

## 13. Sources register

\`lib/sources.ts\` holds the links shown to readers. Every figure below was checked in the document itself.

| Source | What Lens takes from it | Where it's used | Checked |
|---|---|---|---|
| [Pkw-EnVKV](https://www.gesetze-im-internet.de/pkw-envkv/) — Germany's CO₂ labelling rules for new cars | The A–G classes as a function of WLTP CO₂ (A = 0, B ≤ 95, C ≤ 115, D ≤ 135, E ≤ 155, F ≤ 175, G above), since the February 2024 amendment | CO₂ scoring; low CO₂ = class A–C; electric = class A = 0 g/km; how-green answers; low-CO₂ row | Classes per §3a; see the emissions document |
| [EEA — CO₂ emissions from new passenger cars](https://www.eea.europa.eu/data-and-maps/data/co2-cars-emission-18) (2025 provisional, release \`co2cars_2025Pv31\`) | Each registered plug-in's "Electric energy consumption (EC_AC,weighted)", Wh/km | Plug-in electricity cost (§10.3) | Field definition traced to [Regulation (EU) 2019/631](https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:02019R0631-20240101), Annex III (OVC-HEV: CoC 49.5.2) and [Implementing Regulation (EU) 2020/683](https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:32020R0683) (CoC 5.2: "Electric energy consumption (EC_AC, weighted)"); Tucson 62 g/2.7 L → 108 Wh/km and X5 74 g/3.2 L → 205 Wh/km matched by hand |
| [European Commission, SWD(2024) 59](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=celex%3A52024SC0059) — real-world CO₂ emissions gap report | "For the new plug-in hybrid electric cars registered in 2021, the average real-world CO₂ emissions were on average 3.5 times (100 g CO₂/km) higher than their WLTP CO₂ emissions (39.5 g CO₂/km)"; the utility factor changes from 2025 | The plug-in CO₂ note, always with its date | Quoted from the report's text |
| [ICCT, ID 482](https://theicct.org/wp-content/uploads/2025/12/ID-482-%E2%80%93-EEA-briefing-Research-Brief-A4-70179-v7.pdf) — CO₂ from new passenger cars in Europe, 2024 | Combustion cars "have only declined by 3 g/km since 2021, remaining at about 134 g/km" | The 136 g/km comparison point and the combustion efficiency reference | Quoted from the brief |
| [ICCT, ID 392](https://theicct.org/wp-content/uploads/2025/07/ID-392-%E2%80%93-Life-cycle-GHG_report_final.pdf) — life-cycle GHG emissions from passenger cars, 2025 | 16.2 kWh/100 km, sales-weighted official consumption of medium electric cars sold in the EU in 2023 (Table 4) | The 17 kWh/100 km electric efficiency reference | Found in the report |
| [ADAC — "Mit Allradantrieb braucht man keine Winterreifen"](https://www.adac.de/der-adac/regionalclubs/suedbayern/auto-mythen/) | "Beim Anfahren oder beschleunigen hat man eine höhere Traktion" — and "bei einer Bremsung in der Kälte oder auf Schnee hilft kein Allrad"; no substitute for winter tyres | All-wheel drive recommended for snow & ice, said both ways | Quoted from the page |
| [ADAC — "Durch den Winter? Aber sicher!"](https://presse.adac.de/regionalclubs/wuerttemberg/files/adac-infobroschuere-durch-den-winter.pdf) (2015), p. 19 | "in punkto Wintertauglichkeit gibt es zwischen Front- und Heckantrieb keinen eindeutigen Sieger"; with ESP (standard on new cars since 2014) stability and traction problems are largely past | Why Lens doesn't ask about front- vs rear-wheel drive (§15) — not shown to readers | Read in full |

FINN's own API is the source for everything else: \`https://www.finn.com/api/cars\` (snapshot in
\`lib/reasoning-engine/test-data/finn-fleet-snapshot.json\`, taken 2026-10-07, 698 cars). §2.1 says how
each of its fields is read.

---

## 14. Lens's own assumptions

Numbers with no source to take them from. Each is labelled where it's shown.

| Assumption | Value | Where | Status |
|---|---|---|---|
| Fuel and electricity prices | petrol €1.75/L, diesel €1.70/L, electricity €0.32/kWh (\`DEFAULT_PREFERENCES\`) | Energy cost; said as "an assumed fuel price of €1.75 per litre" | **Not yet sourced** — see §16 |
| Monthly distance when not asked | 1,000 km | Mileage and energy cost; said as "assumed — you didn't say" | Lens's default |
| Some-give headroom | 15% over the limit (\`TARGET_HEADROOM\` = 1.15) | Soft budget | Lens's judgement; said with the figure it gives |
| Importance weights | 4 : 2 : 1 (\`NEED_WEIGHT\`); item raises 2/3/4 on a base of 1 | §3.3, §4 | Lens's design, said in words ("twice as much as") |
| Fit band thresholds | 65 / 45 / 25 | §8 | Provisional, to be recalibrated on FINN's inventory |
| Measurement anchors | §6 | Size, range, charging | Set from FINN's fleet distribution |
| Standard-equipment line | 90% of FINN's cars | §5.2 | Re-checked against the fleet on every calibration run |
| Assessed share | 50% of a priority's weight known | §5.1 | Lens's design |
| How far Lens looks for the nearest dates | 36 months moved at the start and end together (\`NEAREST_REACH\`); the start moved least, then the shorter period, among equals | §9.5 | Lens's design: enough to bring the longest period Lens accepts (48 months) down to a 12-month term, with room to move its start |

---

## 15. Decisions considered and rejected

| Considered | Decided | Because |
|---|---|---|
| A "30 kWh/100 km" allowance to bound a plug-in's electricity | **Removed** | It rested on nothing. Real EU data showed it wasn't even a ceiling: 2.8% of plug-ins registered in Germany in 2024, and 2.0% EU-wide, were officially above it. Replaced by each car's EU figure (§10.3). |
| Disqualifying every plug-in under a hard limit, since its cost was never complete | **No** | It would have removed all 44 for any hard budget, including one €400 under an €800 limit. With the EU figure, most are priced in full. |
| Asking about front- vs rear-wheel drive | **No** | The ADAC finds no clear winter winner between them, and with ESP on every new car the difference has largely gone. Rear-wheel drive's better traction when towing is under the same "all else equal" caveat. |
| A "hybrid" fuel choice | **No** | FINN's data has no hybrid type; it files them under petrol. Petrol's "i" says so from the page. |
| "Flexible / Hard line" for deal rows | **Tried, reverted the same day** | "Must be / Mustn't be / Seals it" read better; the meanings now sit under the question instead. |
| An "Electric" deal row | **Replaced** | "What can it run on?" covers it, for all four fuels. |
| "Six seats or more" among who rides with you | **Moved** | It's a count, not a person; it's a deal-breaker or sealer row. |
| Recommending warmth for rain alone | **No** | Rain asks for lights and wipers, not heat. |
| Scoring boot space | **Off** | FINN's figure mixes seats-up and seats-folded. |
| "Starred because studies say…" style claims without a link | **No** | Every non-FINN claim is named and linked, or not made. |
| Offering "a month either way" whenever no car fits the dates | **Only where it finds a car** | Asked for 36 months of cars whose longest term is 24, it could never help, and led to a second "no car here" with nothing more to offer. The nearest dates a car here can be had for are offered instead (§9.5). |

---

## 16. Known gaps and open items

- **Fuel and electricity prices are unsourced assumptions.** They should be sourced (e.g. a published German
  average with its date) and linked like the rest, or the reader asked.
- **A "mustn't" rule lets unknowns through.** Today every mustn't rule is on a field FINN always sends (fuel
  and body type), so no car is affected — but a future mustn't rule on optional equipment should set aside
  unconfirmed cars, as a hard limit does.
- **The EEA's 2025 data is provisional**, and the table needs re-running as FINN adds models: a new plug-in
  model isn't matched until it does. 12 of the 39 plug-ins in the fleet snapshot don't match today: two
  Mazda CX-60 and two CX-80, two Honda CR-V e:PHEV and two Kia Sportage, the MG S9, a Hyundai Tucson, the
  BMW X5 xDrive50e, and a BMW 230i Coupé FINN files as a plug-in hybrid.
- **Band thresholds** are provisional (§8).
- **Boot space** waits on a seats-up source (§5.3).
- **Some engine notes predate the chat** and still describe a relative Compare page (fit.ts header); the
  scoring itself is intrinsic (§2).

---

## 17. Refreshing the data

| Data | Script | Then |
|---|---|---|
| FINN's fleet snapshot (tests, calibration) | \`node scripts/snapshot-finn-fleet.mjs\` | Run the calibration tests; check \`BASELINE_PREVALENCE\` items still hold |
| EU plug-in electricity table | \`node scripts/snapshot-eu-plug-in-electricity.mjs\` | Update the release name when the EEA finalises 2025 (\`co2cars_2025F…\`); re-run \`eu-electricity.test.ts\`; re-check the match rate |
| Sources | \`lib/sources.ts\` | Re-open each link; a moved document is a broken claim |
`},{id:`emissions`,file:`FINN-LENS-EMISSIONS-SCORING.md`,label:`Emissions and efficiency`,number:`05`,source:`docs/FINN-LENS-EMISSIONS-SCORING.md`,markdown:`# Finn Lens — Emissions & Efficiency Scoring

> **Status of this document.** A design record for the Environmental Impact priority as
> rebuilt in commit \`7f3e212\`, written so another engineer can change it without having to
> re-derive the reasoning. It describes what was actually built and the published evidence
> it rests on. Verified at the time of writing (\`7b455be\`, 2026-09-05): \`npx tsc --noEmit\`
> clean, \`npx vitest run\` green (28 files, 509 tests), 40 of them in \`environmental.test.ts\`.
>
> [\`HOW-FINN-LENS-DECIDES.md\`](HOW-FINN-LENS-DECIDES.md) §7 summarises this model for the current
> build (\`FINN-LENS-HANDOFF.md\`, which did before, is on the \`playground\` branch). This document is the
> long form: why it is the way it is, and what would have to change to change it. Its figures — the
> A–G boundaries, the 136 g/km and 17 kWh/100 km references, the plug-in hybrid ceiling — were checked
> against \`environmental.ts\` again for the 0.9.1 beta (12 October 2026). The explainer pieces it describes
> for the earlier settings and comparison screens — \`efficiencyReferenceFor\`, \`ENVIRONMENTAL_METHOD\` and the
> priority subtitle \`describeCoverage\` — were removed in that release's cleanup, since nothing in the chat
> showed them; the passages about them are a record of what was built then.
>
> **Amended 2026-09-06.** §12 covers the explanation layer added on top of the model — the
> scoring below is unchanged. Two claims in the copy were corrected at the same time and are
> marked in place: the efficiency benchmark is the combustion fleet average, not "a typical
> petrol car" (§5), and a plug-in hybrid's figure is now labelled for what it is (§6).
>
> **Amended 2026-09-11.** An audit of the efficiency explanation against its sources. The
> scoring, the class ladder, the fit bands, the PHEV treatment and every threshold are
> unchanged. What changed: the consumption benchmark is presented as **Finn Lens's reference**,
> not as what any car "typically" or "on average" uses; \`L/100km\` is said in words wherever it
> is judged; and two provenance claims were corrected — where 136 g/km is actually published,
> and how 17 kWh/100 km was derived. See §5 "Corrected 2026-09-11", §11 and §12. Verified:
> \`npx tsc --noEmit\` clean, \`npx vitest run\` green (35 files, 598 tests). A second pass the
> same day reduced the efficiency sentence to how the car compares with the FINN Lens benchmark,
> and checked every surface it appears on in a real browser — see §5.

---

## 1. Why it was rebuilt

The previous model produced four independent 0–100 sub-scores and averaged them. A reader
saw \`CO₂ 49/100 · class 50/100 · consumption 53/100 · fuel type 20/100\` and had no way to
interpret any of it.

\`\`\`
// the shape of the old model
score = mean(
  co2Score,         // 100 × (1 − g/km ÷ 250)
  co2ClassScore,    // A=100 … G=0
  consumptionScore, // 100 × (1 − L or kWh ÷ ceiling)
  powertrainScore,  // Electric 100, PHEV 55, Diesel 20, Petrol 20
)
\`\`\`

**Three of those four were the same measurement.**

- **The CO₂ class is a pure function of the CO₂ figure.** Since the 2024 Pkw-EnVKV amendment
  the German class is derived from WLTP combined g/km alone.
- **Consumption is the CO₂ figure too**, for anything that burns fuel: CO₂ per km *is*
  litres per km × the carbon in a litre.
- **Fuel type is not a measurement at all.** Scoring it marked a petrol car down twice for
  being petrol — once in its CO₂, once for the fuel that produced that CO₂.

The practical consequence: a user who wanted a petrol car was told *petrol is bad* four
times over, rather than which petrol car was the good one. The arithmetic was false
precision — averaging four numbers, three of which were the same number.

### A separate bug the audit turned up

\`lib/translate.ts\` had **no entry for \`Diesel\`** and spelled the hybrid \`"Plug-In-Hybrid"\`
where FINN sends \`"Plug-in Hybrid"\`. Both arrived with \`fuelType: undefined\`.

Blast radius beyond this feature: \`energyPriceFor()\` in \`cost.ts\` falls through to the petrol
price for anything not \`Electric\` or \`Diesel\`, so **every diesel was costed at petrol
prices**. The PHEV caveat also never fired, for any PHEV. Fixed in the same commit, guarded
by \`lib/translate.test.ts\`.

---

## 2. What the evidence says

Four findings decided the model. Each is quoted in the header comment of \`environmental.ts\`
so the reasoning travels with the code; full citations are in §10.

| Finding | Evidence | Consequence |
| --- | --- | --- |
| **Class ≡ CO₂** | Pkw-EnVKV §3a as amended Feb 2024 sets classes on absolute WLTP CO₂: A 0, B ≤95, C ≤115, D ≤135, E ≤155, F ≤175, G ≥176. ADAC on what changed: *"Der Bezug zum Fahrzeuggewicht entfällt."* | Class is displayed, never scored. Before 2024 it was weight-adjusted and did carry extra information; it no longer does. |
| **Consumption ≡ CO₂** | EC real-world monitoring gives petrol's 1.2 L/100 km gap as 28 g CO₂/km — that ratio *is* the 2,330 g of carbon in a litre. Diesel ≈ 2,640 g/L. | Consumption leaves the score entirely and becomes a separate, cohort-relative efficiency answer. |
| **PHEV gap** | ICCT: real-world CO₂ averages ~5× official; the gap grew from 265% (2021) to 400% (2023). Cause is a type-approval utility factor assuming more charging than happens. EC revised it in 2025, again due 2027. | PHEV scale compressed, not corrected. No real-world figure is invented. |
| **Fleet references** | ICCT research brief ID 482 (EEA data): combustion incl. hybrids ≈ 137 g/km WLTP in 2021 → ≈ 134 g/km in 2024; Lens uses 136. ICCT life-cycle report 2025 (Table 4, EEA data): medium-segment BEVs 16.2 kWh/100 km WLTP in 2023; Lens uses a rounded 17. *(Corrected 2026-09-11 — see §5.)* | Every efficiency threshold is derived from these two numbers rather than chosen. |

---

## 3. The model

Three parts. Only one of them scores.

**Environmental Impact.** Tailpipe CO₂ g/km, placed on the EU's own class scale. *This is
the only thing that moves the category score.* The boundaries are the regulation's.

**Efficiency.** A separate, cohort-relative reading of consumption — "frugal *for a petrol
car*". Contributes zero points. It exists because a litre and a kilowatt-hour are not
comparable quantities, and because a petrol buyer needs to know which petrol car is the
frugal one.

**Powertrain.** Context only. Selects the efficiency cohort and carries the caveats.
Contributes zero points.

**CO₂ class.** Displayed beside the figure as its familiar shorthand — and *computed* from
the figure by \`co2ClassFor()\` rather than read from FINN's field, because a pre-2024 car can
carry a letter that disagrees with its own emissions.

> **The design principle worth keeping.** The two answers are *allowed to disagree*, and
> that disagreement is the product value. A Mercedes EQS SUV is a *strong environmental
> match* and a *less efficient electric car*. A frugal petrol car is *highly efficient* and
> still a worse emitter than any EV. One score cannot hold both; two answers can.

---

## 4. The CO₂ class ladder

Each class occupies a *stretch* of the 0–100 scale, and every stretch sits wholly inside one
of Lens's existing fit bands (\`strong ≥65 · good ≥45 · partial ≥25\`, from \`fit.ts\`). So the
class decides the word the reader sees, and the figure decides where within it.

| Class | CO₂ | Score stretch | Fit band |
| --- | --- | --- | --- |
| **A** | 0 g/km | 100 | Strong match |
| **B** | 1 – 95 g/km | 88 → 70 | Strong match |
| **C** | 96 – 115 g/km | 64 → 52 | Good match |
| **D** | 116 – 135 g/km | 44 → 34 | Partial match |
| **E** | 136 – 155 g/km | 33 → 28 | Partial match |
| **F** | 156 – 175 g/km | 22 → 14 | Limited match |
| **G** | 176 g/km and up | 12 → 0 | Limited match |

Class G has no upper bound in law; the scale stops distinguishing at 195 g/km, one
band-width past where G starts.

\`positionForCo2()\` interpolates within a class, so a 118 g/km car and a 134 g/km car are
both class D and are *not* reported as the same car — while neither can ever outrank a
class C one.

> **The one product judgement in the file.** The class → position table (\`CLASS_POSITION\`)
> is calibrated so a car of average emissions reads as a **partial match** to someone who
> put the environment near the top of their list. D is the commonest class among cars that
> burn fuel. That is a deliberate call, not an accident — and it is the single table a
> future engineer would tune. Not the thresholds, not the labels.

---

## 5. Efficiency references are derived, not chosen

No threshold in this model was picked by hand. Each powertrain's **reference** falls out of
the ICCT combustion-car CO₂ observation read through the fuel's own carbon content:

\`\`\`
// cohortFor() — environmental.ts
petrol   136 g/km ÷ 2330 g/L × 100  =  5.84 L/100 km  shown "5.8 L/100km"
diesel   136 g/km ÷ 2640 g/L × 100  =  5.15 L/100 km  shown "5.2 L/100km"
electric (no CO₂ to derive from — every BEV is 0)
                                    =  17 kWh/100 km  rounded reference, see below

// band width: one CO₂ class as a share of the fleet average
EFFICIENCY_BAND = 20 ÷ 136 = 14.7%
\`\`\`

Using that same proportion for every cohort makes "highly efficient" the same distance from
ordinary whether it is measured in litres or in kilowatt-hours — and it is a width the label
itself already uses rather than one chosen to make cars look good.

### Cohort choice

**Powertrain cohort**, not vehicle class. Vehicle-class cohorts were rejected because FINN's
\`cartype\` is a free-text field with a single entry in \`germanToEnglish\` and no values in the
captured detail page — not a benchmark that could be defended. Simplest defensible beat
pretending to a precision the data doesn't support.

### Labels carry their own explanation

\`assessEfficiency()\` returns the label *and* its explanation together, so no surface
hard-codes the wording:

\`\`\`ts
{
  level: "moderate",
  label: "Moderate fuel use",
  step: "moderate",
  explanation: "Uses about as much petrol as the FINN Lens benchmark for petrol cars.",
  display: "5.5 L/100km",
  measure: "litres of petrol per 100 km",
  consumes: "This car consumes 5.5 litres of petrol per 100 km",
  reference: "5.8 L/100km",
  referenceLabel: "FINN Lens benchmark",
  referenceNote: "FINN Lens's comparison point, not an official average",
  provenance: { title: "Where does the FINN Lens benchmark come from?", body: "…" },
  caveatTitle: "How this car's figure is measured",
  reasoning: "It uses about 6% less petrol than the 5.8 L/100km FINN Lens benchmark, so " +
             "its fuel use is broadly in line with the benchmark.",
  caveat: "This car's figure comes from WLTP, the standardised test …",
}
\`\`\`

Vocabulary is five steps with what the car uses named: \`Very low\` / \`Low\` / \`Moderate\` / \`High\` /
\`Very high\` \`fuel use\` (or \`electricity use\`), coloured green, green, yellow, orange, red. See
§12, "Fuel-use labels". No "weakly" or "poorly".

### Corrected 2026-09-06 — what the benchmark actually is

The explanation used to read "a typical new petrol car" / "a typical new diesel car". That
overstated what the reference is. The figure it compares against is the **combustion fleet's
CO₂ average converted through this fuel's carbon content** — 136 g/km read through 2 330 g/L
or 2 640 g/L. No whole-market petrol-only or diesel-only WLTP consumption average is published
by the sources this was built on, so there was no "typical petrol car" behind the number.

The litre thresholds still differ between the two (5.8 vs 5.15 L/100 km) precisely because a
litre of diesel carries more carbon — which is a true and useful thing to tell a reader, and
what the copy now says.

### Corrected 2026-09-11 — a reference, not an average

The 09-06 fix swapped "a typical petrol car" for "the average new car that burns fuel". That
was still a population claim, and a self-contradicting one: the same "average car" was said to
use 5.8 L/100km in a petrol car's panel and 5.2 in a diesel's. Neither was measured on any car.
The usage sections labelled the figure **Typical for its kind**, the efficiency chip said it
"puts a typical diesel car at 5.2 L/100km", the prose said "around typical" and "more than most
electric cars", and the WLTP caveat said "both figures are official WLTP lab results" — the
reference is not a test result for any car.

What the reader now meets, in order:

| Question | Shown as |
| --- | --- |
| What does it use? | \`This car · 5.5 L/100km · This car consumes 5.5 litres of petrol per 100 km\` |
| Is that efficient? | \`Moderate fuel use\`, in yellow, and "It uses about 6% less petrol than the 5.8 L/100km FINN Lens benchmark, so its fuel use is broadly in line with the benchmark." |
| Compared with what? | \`FINN Lens benchmark · 5.8 L/100km · FINN Lens's comparison point, not an official average\` — drawn quieter than the car's own figure |
| What does the number mean? | An "i" beside the car's own value, headed "What does this number mean?": "L/100km means litres per 100 kilometres. 5.5 L/100km means this car uses about 5.5 litres of petrol to drive 100 km. Lower means less fuel to buy. This car's figure comes from the official EU test, so you can compare cars fairly. Real-world fuel use is usually higher, especially on the motorway, in cold weather or with a full car." One explanation about one number. Electric cars get kWh explained as the unit on an electricity bill. |
| Where is that from? | An "i" beside the reference value, headed "Where does the FINN Lens benchmark come from?": about 136 g of CO₂ per km as a comparison point, from European data on new petrol and diesel cars analysed by the ICCT; not a legal limit or target; converted into an equivalent petrol-use figure, which is where 5.8 L/100km comes from; "a FINN Lens comparison benchmark, not an official petrol-consumption average". Diesel adds why its figure is lower. The environmental result's question uses the same text. |
| What's the catch? | The full version is in the "i" above; the section closes on the short line \`TEST_DISCLAIMER\`: "Official EU test figures. Real-world use is usually higher." |

**Second pass, 2026-09-11.** The sentence under the label no longer grades the car a second
time ("too close to call it especially frugal", "genuinely frugal", "you pay for it every
month"). It says how the car compares and stops: "…so its fuel use is broadly in line with /
noticeably lower than / noticeably higher than the benchmark." The label carries the verdict,
and the band edges stay unstated. The caveat no longer says the reference is "built from WLTP
figures". Checked in Chromium against the built extension — pins drawer, Advice page and its
export rendering, and the in-page panel on finn.com, at 1280 px and 390 px — which led to two
small layout changes: the reference value is drawn quieter than the car's own figure, and the
opened provenance is ruled off from the caveat beneath it.

**Each explanation on its own figure.** Both explanations then moved out from under the
conclusion, where a reader couldn't tell which number either one was about. The WLTP caveat is
now an "i" beside the car's figure, and the provenance is an "i" beside the reference. Each is
headed with the question it answers. On the pins drawer and the Advice page it is the shared
\`Tip\` (hover, pin on click, arrow pointing at the number), via \`components/FigureInfo.tsx\`; an
exported file lays the text flat under its figure. The in-page panel opens it directly under its
number (\`figureInfo()\` in \`sections.ts\`). \`panel-copy.test.ts\` pins that each explanation is
attached to its own figure and appears only once.

\`EfficiencyAssessment.typical\` / \`typicalValue\` became \`reference\` / \`referenceValue\`, with
\`measure\`, \`referenceLabel\`, \`referenceNote\` and \`provenance\` beside them, so no renderer
composes — or \`.replace()\`s its way to — the wording. \`components/ReferenceSource.tsx\` and
\`referenceSource()\` in \`lens-panel/sections.ts\` render the fold.

**Plain-language pass, 2026-09-11.** Brought in line with the environmental result's rule
(§12): no reader should have to know car terminology to follow the explanation. The car's "i"
now explains the unit rather than the test; the provenance drops "combustion cars", "carbon
content" and kilograms per litre (the conversion constants stay in \`CARBON_PER_LITRE\` and in
this document); and the test disclaimer, true of every figure in the section, moved out from
behind one number's "i" to a single line under the conclusion. \`EfficiencyAssessment.caveat\` /
\`caveatTitle\` became \`meaning: { title, body }\` and \`disclaimer\`. A follow-up merged the unit
explanation and the test caveat into one \`meaning.body\` behind the car's "i", and shortened the
closing line to \`TEST_DISCLAIMER\` ("Official EU test figures. Real-world use is usually
higher."). The environmental result reuses the car's "i" as is, and puts
\`referenceDerivation\` behind its reference's "i": how the reference is reached, in plain words,
without repeating where 136 g/km comes from (§12).

**Why not a petrol-only or diesel-only average instead.** One exists for a slice of the market:
ICCT's 2025 life-cycle report gives sales-weighted WLTP figures for *medium-segment* cars sold
in 2023 — petrol 5.7, diesel 4.9 L/100 km. Close to the petrol reference; below the diesel one,
so the diesel reference is the more lenient of the two. Not adopted: they describe one segment,
FINN's \`cartype\` can't place a car in one (see *Cohort choice*), and the derived reference has a
property they lack — petrol and diesel are held to the same CO₂ observation, each in its own
unit.

**Why 136 and not 134.** ICCT brief ID 482 puts combustion cars at about 137 g/km in 2021 and
about 134 in 2024 ("only declined by 3 g/km since 2021"). 136 sits on that plateau and "about
136" stays true. Moving to 134 changes no score (scores come from the class), still shows 5.8
for petrol, shows 5.1 rather than 5.2 for diesel, and moves every band edge by under 0.1 L/100 km
(petrol "highly efficient" ≤ 4.98 → ≤ 4.89; diesel ≤ 4.39 → ≤ 4.32). A one-constant change for
the next data refresh. The Pocketbook's 108 g/km is the all-car average, electric included, and
was never the source of 136.

**Where 17 kWh/100 km comes from.** It was documented as "real-world ≈ 19 kWh running ~12% above
type-approval". The cited battery-size report says neither: its simulated real-world consumption
runs 29–44% above type-approval, and its 12% is an on-board charger loss parameter (Appendix D).
The number stands on better evidence — ICCT's life-cycle report puts medium-segment BEVs at
16.2 kWh/100 km WLTP (2023, EEA data) — and the copy now calls it a rounded reference rather than
"what new electric cars average".

---

## 6. Plug-in hybrids — compressed, not corrected

A PHEV's official CO₂ can be 26 g/km, which on the ladder would sit in class B and read as a
strong match. The ICCT evidence says real emissions run several times higher where the car is
charged less than the test assumes — and that the size of the gap depends on a driver FINN's
data cannot see.

So **nothing is invented**. The figure shown is still FINN's own. What is refused is the top
of the scale:

\`\`\`ts
if (score != null && fuel === "Plug-in Hybrid") {
  confidence = "optimistic";
  score = Math.round(score * (CLASS_POSITION.C.to / 100));
}
\`\`\`

**Why compressed rather than clipped.** The first implementation *clipped* at a ceiling. That
made a 26 g/km PHEV and a 75 g/km PHEV come out identical — throwing away the one distinction
the data genuinely supports. Scaling the whole range keeps PHEVs ordered against each other
while keeping all of them below cars whose figures don't need this caveat.

PHEVs also get **no efficiency label**. FINN publishes one weighted figure blending two
energy sources and no separate kWh reading, so there is no cohort it can honestly be placed
in. The UI says so explicitly rather than showing a grade.

---

## 7. Missing data

| What's absent | Score | Behaviour |
| --- | --- | --- |
| CO₂ only | \`null\` | Efficiency still reported. Band reads "Not enough data". \`missing\` names the CO₂ figure. |
| Consumption only | scored | Score stands on CO₂. No efficiency label — a missing consumption is *never* read as a frugal one. |
| Powertrain only | scored | Score stands. No cohort, so no efficiency label and no powertrain caveats. |
| CO₂ **and** consumption | — | \`assessEnvironment()\` returns \`null\`. The priority reports itself as unanswerable rather than guessing. |

Nothing is ever treated as zero. A 0 g/km reading from an electric car is a *measurement*; an
absent field is an absence, and the two are kept apart throughout.


### Fixed 2026-09-11 — an empty figure is missing, not zero

FINN's API sends \`null\` for a figure it doesn't have, and the model read figures with
\`Number()\`. \`Number(null)\` is \`0\`, so a car with no published CO₂ was read as a car that emits
none: Class A, "Very low emissions", and a strong environmental match, all on no data. FINN's own
\`co2_class\` was never the source of the letter (the class is computed from the figure), so the
letter was invented too.

Figures are now read through \`published()\` in \`environmental.ts\`: a number stays a number, a
non-empty string is parsed, and \`null\`, \`undefined\` and \`""\` are \`NaN\`, which the model already
treats as missing. A genuine \`0\` (an electric car) is still \`0\`. Consumption is read the same way.

With no CO₂ figure the priority is unscored and reads *Not enough data*, as before. What changed is
what the reader is told:

| Where | Says |
| --- | --- |
| Priority header | "No CO₂ figure published" (it used to fall through to "Equipment not listed by FINN") |
| Answer | "FINN doesn't publish this car's CO₂ figure or its CO₂ class." Consumption is not mentioned here, published or not: "How much it uses" says that in its own section |
| Class pill | *Class not published*, neutral, with an "i": the class comes from the CO₂ number, FINN doesn't publish it, so there's no class and FINN Lens won't guess one |
| CO₂ row | *No data* · "Not published by FINN" |
| Fuel use | not in this section (see "How much it uses is its own section" below) |

To make that possible, \`categoryDetail\` now carries the environmental reading even when there is no
CO₂ figure to score, and the three renderers draw the environmental block for the environmental
priority whatever the data, rather than only when there is an assessment. The generic "FINN's data
doesn't carry anything we can judge" line is not shown under it.

The category's internal score for an unscored priority is unchanged: like every other priority
without evidence, it takes the engine's neutral 50 in the weighted total, so a missing figure
neither lifts nor sinks a car in the ranking. It is never shown.

The reference is not a property of the car, so it is never missing with the car's figure.
\`efficiencyReferenceFor(fuel)\` gives it on its own, and \`assessEnvironmentOrGaps\` keeps what the car
runs on when FINN publishes neither figure (\`assessEnvironment\` still returns null there, for its
other callers). The only rows without a figure in the reference column are a plug-in hybrid's
("None · Nothing fair to compare with", on purpose) and a car whose fuel FINN doesn't name ("Depends
on the fuel").

### Numbers

Every number is written the English way: a dot for decimals and a comma for thousands, "5.8
L/100km", "16.2 kWh/100km", "1,000 km", "€1,029". \`format.ts\` formats with \`en-GB\`; it used
\`de-DE\`, which wrote "5,8" and "1.000 km" inside English sentences.

---

## 8. Code contract

### Exported surface — \`lib/reasoning-engine/environmental.ts\`

\`\`\`ts
assessEnvironment(vehicle: FinnCar): EnvironmentalAssessment | null
assessEfficiency(vehicle: FinnCar): EfficiencyAssessment | null
describeEnvironment(assessment): string       // the reader-facing sentence
co2ClassFor(gPerKm: number): string           // "A" … "G"
positionForCo2(gPerKm: number): number        // 0–100
ENVIRONMENTAL_METHOD: EnvironmentalMethodNote[]  // the collapsed explainer

type EnvironmentalAssessment = {
  score: number | null            // the only thing feeding the engine
  co2: EmissionsAssessment | null
  efficiency: EfficiencyAssessment | null
  powertrain: FuelType | null
  confidence: "measured" | "optimistic" | "unknown"
  caveats: string[]
  missing: string[]
}

// Added 2026-09-06. The figure no longer travels without its meaning.
type EmissionsAssessment = {
  level: "none" | "low" | "moderate" | "high"
  label: string        // "Above-average emissions"
  explanation: string  // what the figure means, in one sentence
  display: string      // "140 g/km · Class E"
  gPerKm: number
  className: string
}
\`\`\`

### How it reaches the rest of the engine

\`\`\`
scoring.ts    numericScore("environmental") → assessment.score
              CategoryDetail.environmental  carries the assessment
index.ts      priorityBreakdown()           → PriorityBreakdown.environmental
fit.ts        toFitPriority()               → FitPriority.impact
UI            reads priority.impact / reasoning.environmental
              → components/EnvironmentalResult (React)
              → lens-panel/sections.ts impactBreakdown() (hand-rolled DOM)
\`\`\`

The category score flows through the existing priority-weighting system untouched — no
environmental multiplier bypasses it, and the priority remains a preference rather than a
hard constraint.

### Files changed in \`7f3e212\`

| File | Change |
| --- | --- |
| \`lib/reasoning-engine/environmental.ts\` | Rewritten. The model. |
| \`lib/reasoning-engine/environmental.test.ts\` | Rewritten. 40 tests. |
| \`lib/reasoning-engine/scoring.ts\` | \`numericScore\` environmental branch; \`CategoryDetail.environmental\`. |
| \`lib/reasoning-engine/types.ts\` | Assessment type threaded through \`CategoryDetail\` / \`PriorityBreakdown\`. |
| \`lib/reasoning-engine/fit.ts\` | \`FitPriority.impact\` retyped. |
| \`lib/reasoning-engine/narrative/priority.ts\` | Prose now comes from \`describeEnvironment()\`. |
| \`entrypoints/content/lens-panel/sections.ts\` | Panel section: three readouts, collapsed methodology. |
| \`components/EnvironmentalMethod.tsx\` | Settings / step-3 explainer rewritten. |
| \`lib/translate.ts\` | **Bug fix.** Added \`Diesel\`; fixed PHEV spelling; kept variants. |
| \`lib/translate.test.ts\` | New. Guards every fuel the API declares. |

Since then the panel has been refactored into \`components/FitAnalysisView\`, which consumes
the same \`priority.impact\` contract unchanged.

---

## 9. Sanity results

Eighteen cars run through \`assessEnvironment()\` and \`buildFitAnalysis()\`. The rows that
matter are the ones where the two answers diverge.

| Car | Powertrain | CO₂ | Score | Band | Efficiency |
| --- | --- | ---: | ---: | --- | --- |
| Dacia Spring | Electric | 0 · A | 100 | Strong | Low electricity use · 13.9 kWh |
| Tesla Model 3 | Electric | 0 · A | 100 | Strong | Low electricity use · 13.2 kWh |
| BYD Dolphin Surf | Electric | 0 · A | 100 | Strong | Moderate electricity use · 15.9 kWh |
| Mercedes EQS SUV | Electric | 0 · A | 100 | Strong | Very high electricity use · 22.4 kWh |
| Toyota Yaris | Petrol | 102 · C | 60 | Good | Low fuel use · 4.4 L |
| VW Polo | Petrol | 119 · D | 42 | Partial | Moderate fuel use · 5.2 L |
| Jeep Compass | Petrol | 127 · D | 38 | Partial | Moderate fuel use · 5.6 L |
| VW Golf GTI | Petrol | 168 · F | 17 | Limited | High fuel use · 7.4 L |
| Ford Mustang 5.0 | Petrol | 270 · G | 0 | Limited | Very high fuel use · 11.6 L |
| Škoda Octavia TDI | Diesel | 112 · C | 54 | Good | Low fuel use · 4.2 L |
| BMW 320d | Diesel | 128 · D | 38 | Partial | Moderate fuel use · 4.9 L |
| VW Touareg V6 TDI | Diesel | 199 · G | 0 | Limited | Very high fuel use · 7.6 L |
| Mercedes A250e | Plug-in hybrid | 26 · B | 43 | Partial | — not graded |
| Range Rover PHEV | Plug-in hybrid | 75 · B | 38 | Partial | — not graded |
| Petrol, no CO₂ | Petrol | — | — | Not enough data | Moderate fuel use · 5.1 L |
| Petrol, no consumption | Petrol | 142 · E | 31 | Partial | — not graded |
| EV, no consumption | Electric | 0 · A | 100 | Strong | — not graded |

**What to read in it**

- **EQS SUV** — strong match, *less efficient*. The design working: zero tailpipe CO₂ and a
  thirsty EV are both true.
- **Yaris vs Mustang** — 60 vs 0. Efficient petrol beats inefficient petrol, within the same
  powertrain.
- **Octavia vs Touareg** — 54 vs 0. Same, within diesel.
- **A250e vs Range Rover** — 43 vs 38. PHEVs stay ordered against each other and both stay
  below every BEV.
- **Petrol at 120 vs diesel at 120** — identical scores. No double penalty for what a car
  burns.

---

## 10. Limits and follow-ups

- **No size adjustment.** A large efficient EV and a small thirsty one are judged on the same
  scale. Honest for CO₂; arguably harsh for efficiency. Fixing it needs a vehicle-class
  cohort, which needs \`cartype\` to become reliable data.
- **Full hybrids are invisible.** \`FinnApiConfig.fuel\` is a closed union of four, so a mild-
  or full-hybrid petrol arrives as plain petrol. Its lower CO₂ figure still scores correctly
  — but it can't be named as a hybrid, and it is judged against the petrol cohort.
- **Fleet references will drift.** \`COMBUSTION_FLEET_CO2\` (136; ICCT's latest is ≈ 134 for
  2024) and \`ELECTRIC_FLEET_KWH\` (17; ICCT's medium-segment 2023 figure is 16.2). Both are
  single named constants with their source in the docstring, and every sentence that quotes
  them is built from the constant; expect to revisit them annually.
- **The class → position table is tunable.** If the product wants average-emitting cars to
  read better or worse, \`CLASS_POSITION\` is the one place to change.
- **PHEV utility factors are moving.** The EC revised them in 2025 with another change due
  2027. When FINN's figures reflect the new factors the compression may need loosening;
  \`confidence: "optimistic"\` is the flag to search for.

---

## 11. Sources

Primary regulation and institutional research only. No blogs, no SEO sites, no
general-interest car press.

- **Pkw-Energieverbrauchskennzeichnungsverordnung (Pkw-EnVKV)** —
  <https://www.gesetze-im-internet.de/pkw-envkv/BJNR103700004.html>
  §3a: the A–G CO₂ class boundaries the ladder is built on.

- **ADAC — Effizienzklasse Pkw: Neues CO₂-Label ist realistischer** —
  <https://www.adac.de/rund-ums-fahrzeug/auto-kaufen-verkaufen/neuwagenkauf/co2-label-pkw-effizienzklassen/>
  Confirms the 2024 amendment dropped the vehicle-weight reference — the finding that makes
  class and figure redundant.

- **European Commission — Real-world CO₂ emissions and fuel consumption of cars and vans
  (2022 data)** —
  <https://climate.ec.europa.eu/news-other-reads/news/publication-real-world-co2-emissions-and-fuel-consumption-cars-and-vans-collected-2022-2024-07-26_en>
  On-board monitoring. Source of the petrol carbon factor and the WLTP-to-real-world gaps.

- **ICCT — Plug-in hybrids in Europe emit five times more than officially reported** —
  <https://theicct.org/pr-plug-in-hybrids-europe-emit-five-times-more-than-officially-reported/>
  The PHEV utility-factor gap: 265% (2021) → 400% (2023). Basis for the compression.

- **ICCT — CO₂ emissions from new passenger cars in Europe: Car manufacturers' performance in
  2024** (research brief ID 482, December 2025) —
  <https://theicct.org/wp-content/uploads/2025/12/ID-482-%E2%80%93-EEA-briefing-Research-Brief-A4-70179-v7.pdf>
  "The WLTP CO₂ emissions of ICEVs, including hybrid vehicles, have only declined by 3 g/km
  since 2021, remaining at about 134 g/km." The observation behind \`COMBUSTION_FLEET_CO2\`, and
  so the root of the petrol and diesel references.

- **ICCT — European Vehicle Market Statistics Pocketbook 2025/26** —
  <https://theicct.org/publication/european-vehicle-market-statistics-2025-dec25/>
  Context only: 108 g/km for *all* new cars in 2024, electric included. *(Corrected
  2026-09-11: previously cited as the source of 136 g/km, which it does not state.)*

- **ICCT — Life-cycle greenhouse gas emissions from passenger cars in the European Union: a
  2025 update** —
  <https://theicct.org/wp-content/uploads/2025/07/ID-392-%E2%80%93-Life-cycle-GHG_report_final.pdf>
  Table 4 (EEA data): sales-weighted WLTP consumption of medium-segment cars sold in 2023 —
  petrol 5.7 L, diesel 4.9 L, BEV 16.2 kWh per 100 km. The basis for the 17 kWh/100 km
  reference; the petrol and diesel figures are recorded in §5 and deliberately not used.

- **ICCT — The bigger the better? How battery size affects real-world consumption** —
  <https://theicct.org/wp-content/uploads/2024/04/ID-80-%E2%80%93-BEVs-size-Report-A4-70138-v9.pdf>
  Simulated real-world BEV consumption 29–44% above type-approval — support for the real-world
  caveat. *(Corrected 2026-09-11: previously cited as "≈ 19 kWh/100 km at ~12% above
  type-approval"; the 12% in it is an on-board charger loss parameter.)*

Every source above is also cited in the header comment of
\`lib/reasoning-engine/environmental.ts\`, so the reasoning travels with the code rather than
living only in this document. The constants each carry their own provenance in a docstring.

---

## 12. The explanation layer

> Added 2026-09-06. The scoring model above is untouched. What changed is the order the
> reader meets it in, and what each number arrives carrying.
>
> **Rebuilt 2026-09-11** for a reader who knows nothing about cars — see the first subsection
> below. The chips and the emissions-versus-efficiency aside described further down are
> retired; those subsections are kept as the record of why they existed.

### The problem

The model was defensible and the presentation was not. Every surface opened on how the
judgement is made — six method cards, expanded — and closed on what the car actually is. The
figures underneath were bare: \`CO₂ emissions 140 g/km\`, \`Consumption 5.4 L/100km\`, with
nothing to say whether either was good, bad, or ordinary. A reader who doesn't already know
what 140 g/km means learned nothing from being shown it.

Three surfaces rendered the same assessment at three different levels of completeness, and
one of them had silently lost most of it:

| Surface | Before |
| --- | --- |
| Advice — \`compare/advice/components/PrioritySection.tsx\` | Sentence + generic measurement table. No class, no efficiency label, no caveat. |
| In-page drawer — \`content/lens-panel/sections.ts\` | Everything, in the wrong order, methodology first and expanded. |
| Pins drawer — \`components/FitAnalysisView\` | **One sentence.** Figures, caveats and methodology dropped entirely. |

### Rebuilt 2026-09-11 — for a reader who knows nothing about cars

> Copy and layout only. The CO₂-only score, the class mapping, the bands, every reference
> (136 g/km, 5.8 / 5.2 L/100km, 17 kWh/100km), the plug-in hybrid compression and the
> missing-data behaviour are exactly as §3–§7 describe.

**The rule.** Explain it the way a friend who knows cars would: short, in plain words, answer
first. No percentages ("1% above reference" tells a reader nothing), no FAQ list, nothing folded
away except the "i"s on the numbers a reader might wonder about.

**One source of words.** \`lib/environment-copy.ts\` → \`readEnvironment(assessment, band)\` returns
\`{ headline, rating, band, summary, note, rows, source }\`. \`components/EnvironmentalResult.tsx\`
(Advice page, pins drawer) and \`impactBreakdown()\` in \`lens-panel/sections.ts\` (in-page panel)
only lay it out. It decides nothing: the band is the engine's.

\`\`\`
126 g/km  [Partial match]                         number and band chip: Advice only
This car produces 126 g of CO₂ for every kilometre you drive. That's about 7% below the FINN
Lens comparison point for petrol and diesel cars. It's not low enough for more than a partial
match for your environmental priority.
[About plug-in hybrids]                           plug-in hybrids only

┌ MEASURE            │ THIS CAR                           │ FINN LENS BENCHMARK
├ CO₂ while driving  │ 126 g/km  (Moderate emissions)     │ 136 g/km ⓘ
│   [Class D ⓘ]      │                                    │
│ This decides the   │ 126 grams of CO₂ per km            │ Average new petrol or diesel car
│ match.             │                                    │
└ Official EU test figures. Real-world use is usually higher.
A petrol car's CO₂ comes from the fuel it burns, so its fuel use goes up and down with this
result. See how much fuel it uses.   ← "how much fuel it uses" links to that section
                                                  petrol and diesel cars with a CO₂ figure only
\`\`\`

**How much it uses is its own section (2026-09-13).** The environmental result used to carry a
second, fuel-use row, and "How much it uses" stood down on the pinned card and in the in-page panel
whenever the environment was ranked. So where a car's consumption appeared depended on the reader's
setup. Now the environmental table carries CO₂ alone, and "How much it uses" is always drawn,
straight after the cost, on all three surfaces. Consumption never moved the environmental score, so
the result only points at it, and only where the two are connected: for a petrol or diesel car the
CO₂ figure is the fuel it burns (\`EnvironmentReading.usage\`). Its last words, "how much fuel it uses", are a
link that scrolls to the nearest "How much it uses" (\`lib/usage-anchor.ts\`): up the drawer in the
in-page panel, up the pinned car's card, or to the same tab's "Energy use" on the advice page. An electric car's electricity use
moves nothing here, and a plug-in hybrid's note already says how its fuel use bends the figure, so
neither gets the line.

**The "i"s.**

| Where | Title | Says |
| --- | --- | --- |
| Class pill, right of "CO₂ while driving" | *What does Class D mean?* | The A–G CO₂ label cars get in Germany, what this letter means ("Class D means moderate emissions"), and that it comes straight from the CO₂ number. |
| 136 g/km | *Where does 136 g/km come from?* | Roughly what new petrol and diesel cars sold in Europe put out on average (ICCT); just there to compare against, not a limit or target. |

**Where the class sits, and how the "i"s open.** The class pill sits in the CO₂ row's name
cell, to the right of "CO₂ while driving / This decides the match.", because it is that number
said as a letter. Every "i" opens a tooltip beside its number rather than laying text out under
the section. On the Advice page and pinned cards that is the shared React \`Tip\`; in the in-page
panel it is \`infoTip()\` in \`sections.ts\`, used by every "i" there (the environmental table, the
usage section, feature chips and cost rows). It is appended to the panel's shadow root outside the
scrolling column, positioned from the button (above, or below when there's no room), kept inside
the panel's width, follows the column as it scrolls, opens on hover and focus, pins on click, and
closes on a second click, Escape or a tap anywhere else, with one open at a time. The old inline
explanation blocks and the feature groups' shared explanation slot are gone.

**What the CO₂ means, in words and colour.** The CO₂ row's pill and the class pill both say what
the car's A–G class means, in its colour:

| Class | Words | Colour |
| --- | --- | --- |
| A | Very low emissions | green (\`success\`) |
| B | Low emissions | green |
| C | Fairly low emissions | green |
| D | Moderate emissions | yellow (\`warning\`) |
| E | Higher emissions | yellow |
| F | High emissions | orange (\`caution\`, \`finn-influence-orange\`) |
| G | Very high emissions | red (\`error\`) |

The class is the model's, computed from the CO₂ figure, so the words can never disagree with the
letter. The row's left edge takes the same colour. A plug-in hybrid is the exception: its letter
depends on how often it's charged, so its pill reads *If charged often* in the colour of its match,
and its class pill stays FINN blue rather than a green that would contradict its note.

The distance from 136 g/km is said once, in the answer: "That's about 7% below the FINN Lens
comparison point for petrol and diesel cars", followed by what that means for the match. The
table itself carries no percentages.

**Fuel, in plain words.** Fuel use is drawn only in "How much it uses": its card's verdict is the
car's fuel-use label, and what it runs on is the pill beside the card's name, tinted in the card's
tone as the class is on the CO₂ card. See "Fuel-use labels" below.

**Fuel-use labels (2026-09-11).** "Highly efficient / Moderately efficient / Less efficient" and
the table's "Uses less / About the same / Uses more" were two vocabularies for one reading, and
neither said what the car actually does. Both are replaced by one five-step label from
\`assessEfficiency\`, named after what the car uses, in the pattern of the CO₂ class words:

| Step | Label | Colour | Petrol | Diesel | Electric | CO₂ class it lines up with |
| --- | --- | --- | --- | --- | --- | --- |
| \`veryLow\` | Very low fuel use | green | ≤ 4.1 L | ≤ 3.6 L | ≤ 12 kWh | A–B |
| \`low\` | Low fuel use | green | 4.2–4.9 L | 3.7–4.3 L | 12.1–14.5 kWh | C |
| \`moderate\` | Moderate fuel use | yellow | 5.0–6.6 L | 4.4–5.9 L | 14.6–19.4 kWh | D–E |
| \`high\` | High fuel use | orange | 6.7–7.5 L | 6.0–6.6 L | 19.5–21.9 kWh | F |
| \`veryHigh\` | Very high fuel use | red | ≥ 7.6 L | ≥ 6.7 L | ≥ 22 kWh | G |

Electric cars read "… electricity use". The edges are the model's own: \`EFFICIENCY_BAND\` either
side of the reference (the existing \`level\` edges, unchanged, which a test pins) and twice that for
"very". The band is one CO₂ class wide, 20 g/km, so for petrol and diesel the steps fall where the
classes do and a car's fuel pill takes the same colour as its CO₂ pill, which a test also pins. An
electric car's two pills can disagree (a class A car with *Very high electricity use*), and that
is the point: two separate questions.

\`efficiency.step\` carries the step, \`efficiency.label\` the words; \`USE_TONE\` in
\`environment-copy.ts\` maps a step to its tone and \`efficiencyTone()\` in \`usage-copy.ts\` gives the
chip its classes, so the table and "How much it uses" can't disagree. Shown on the in-page panel,
the pinned car's card and the Advice page, and in the Advice page's challenger line: "Polo, the
recommendation, has moderate fuel use at 5.2 L/100km."

**Saying it's consumption (2026-09-11).** Under the car's own figure the line used to be the unit
in words, "litres of petrol per 100 km", which never said the number is how much the car
consumes. It's now \`efficiency.consumes\`, "This car consumes 4.7 litres of petrol per 100 km"
("… kWh of electricity per 100 km" for an electric car), in "How much it uses" on all three
surfaces and in the environmental table's fuel row. The sentence under the readouts used to open
with the same fact ("This car uses 4.7 litres of petrol to drive 100 km."), so it now starts from
the comparison: "It uses about 19% less petrol than the 5.8 L/100km FINN Lens benchmark, so its
fuel use is noticeably lower than the benchmark." The "i" is unchanged.

**Benchmark, and explanations in place (2026-09-11).** "FINN Lens reference" is now "FINN Lens
benchmark" wherever a reader sees it: the table and readout captions, \`referenceLabel\`, the
sentences ("…than the 5.8 L/100km FINN Lens benchmark, so its fuel use is broadly in line with the
benchmark.") and the explanation titles. The code keeps its \`reference\` names, and "comparison
point" still describes what the number is.

The "i"s in the environmental table and "How much it uses" no longer open tooltips. Each row has
one "i" at its far right, where an accordion's arrow would be; clicking it opens the row's
explanations under the row, and clicking again closes it. Rows open independently.

| Row | Opens |
| --- | --- |
| CO₂ while driving | What does Class D mean? · Where does 136 g/km come from? ("Why is there no class?" when there's no figure) |
| Fuel / electricity use | What does this number mean? · Where does 5.8 L/100km come from? |
| Plug-in hybrid's fuel and electricity use | nothing, so no "i"; the space is kept so the columns line up |
| This car (How much it uses) | What does this number mean? |
| FINN Lens benchmark (How much it uses) | Where does the FINN Lens benchmark come from? |

The class pill no longer has an "i" of its own; what the letter means opens from its row. The two
readouts in "How much it uses" became rows in a bordered card, so each has a far right to put its
"i" at. A button that opens one explanation is named after it; one that opens several is "More
about fuel use". \`components/ExplainedRow\` on the pages, \`explainedRow\` in the panel; an exported
file shows every row open. Feature chips and the panel's cost lines keep their tooltips.

**Layout.** The table header is pale FINN blue. A container query lays each row out as one column
when very narrow, the row's name over this car and the reference side by side from 18rem, and
three columns with the header from 28rem; captions and figures share grid rows, so a caption that
wraps can't push its figure out of line.

**By powertrain.**

| Car | What changes |
| --- | --- |
| Petrol / diesel | "litres of petrol" / "litres of diesel"; the diesel reference's "i" says why it's lower. |
| Electric | "This car produces no CO₂ while you drive it, so it's a strong match…"; \`0 g/km\`, *Very low emissions* (Class A, green); *Electricity use* against 17 kWh/100km; no fuel words. |
| Plug-in hybrid | "In the official EU test, this car produces 30 g… but only if you charge the battery often…"; a short note; *If charged often* in the match's colour and a FINN-blue class pill; *One combined figure / None* with no "i". |
| No consumption | The fuel row reads "Not published", with no reference, comparison or "i". |
| No CO₂ | No surface gets a reading (the category scores \`null\`); unchanged. |

The priority header's subtitle (\`describeCoverage\`) now reads "126 g of CO₂ per km" rather than
"126 g/km · Class D", since the class has its own pill directly beneath it.

**How it got here (same day).** Provenance chips → a table with seven closed questions → "i"s on
the figures with the class in the first sentence → comparison cards with folds and a five-question
list → this: the colourful table again, no accordion around it, no questions, the class as a pill
with an "i", and plain words in place of percentages.

**Export.** Each "i" has its \`FigureInfoExport\` twin, laid flat under its number in a PDF.

**Found on the way.** \`ENVIRONMENTAL_METHOD\` called A–G "the EU's own scale"; it is the German
label (copy fixed). Emoji icons rendered as empty boxes in Chromium, so rows use lucide \`cloud\` /
\`fuel\` / \`zap\`, generated into the panel's icon set.

**Pinned.** \`lib/environment-copy.test.ts\`: the answer verbatim for every band and powertrain; the
class pill's label and explanation for every letter; each row's figures, units, references, "i"s
and colour; the comparison words at every edge and that they agree with the efficiency label; no
percentages anywhere; plug-in hybrid and missing-consumption rows; the closing disclaimer; no
report language ("benchmark", "equivalent", "combustion", "WLTP"…), marketing words or em dashes;
and that the assessment is left untouched. \`panel-copy.test.ts\` pins the pill inside the CO₂ row's name cell and its tooltip, each "i"
opening and closing a tooltip with one open at a time, the answer before the table, no accordion or FAQ, which numbers carry an "i", words not percentages,
the disclaimer last, the plug-in hybrid row and the edge colours. \`environmental.test.ts\` pins the
plain-language \`referenceDerivation\`.

### The order, as first fixed (superseded 2026-09-11)

\`\`\`
1. what this car is        the emissions result, in words     ← the answer
2. what it rests on        the two figures, each with meaning
3. what they mean together where emissions and efficiency disagree
4. what it doesn't cover   the caveats, kept but shortened
5. how it's worked out     folded away behind one line
\`\`\`

\`components/EnvironmentalResult.tsx\` renders this for React (\`concise\` on the Advice page,
\`detailed\` in the pins drawer); \`impactBreakdown()\` in \`sections.ts\` renders the identical
order in hand-rolled DOM, because the in-page panel lives in a shadow root and may not carry
React. Both read the same fields from the same assessment — if a claim isn't on the
assessment it isn't on the screen.

Threading it to the Advice page needed \`PriorityReasoning.environmental\`
(\`narrative/types.ts\`): the assessment now travels whole rather than being flattened into
\`measurements\`, which is why that page can show a class letter and an efficiency label at all.

### The caveats: compressed, then narrowed to the two that earn their place

They were first shortened (a 200-character ceiling, pinned by test — the plug-in hybrid caveat
previously ran ~300 characters of methodology, which is what made it impossible to place below
the answer without swallowing it) and ordered most-specific-first.

The generic lifecycle line — *this counts what comes out of the car, not what building it
cost* — was then **removed from the per-car caveats and left in the method notes**. It is true
of every car equally, so as a per-car line it told the reader nothing about the car in front of
them, and a line readers learn to skip costs the caveats beside it their credibility. Two
remain, and both name something a reader would otherwise misread:

| Powertrain | Caveat |
| --- | --- |
| Electric | Zero is zero *from the car*; making the electricity isn't free, and FINN's data doesn't say where yours comes from. |
| Plug-in hybrid | The figure assumes regular charging; drive it on petrol and real emissions are several times higher. |
| Petrol / diesel | *(none — nothing about reading "140 g/km" is counter-intuitive)* |

### Two claims the copy was making that the data didn't support

1. **"A typical new petrol car."** See §5. Corrected to the fleet benchmark it actually is.
2. **"Low emissions," on a plug-in hybrid.** The pill said *Low emissions* directly above a
   caveat saying the real figure may be several times higher — the panel arguing with itself.
   The label is now *Low only if you charge it*, drawn in the neutral band rather than the
   flattering one. **The figure and the score are unchanged**: no corrected number is
   invented, for the reasons in §6.

**Two more, corrected 2026-10-07.**

3. **"Real-world use is usually higher."** A claim about cars in general, with no source shown
   beside it. \`TEST_DISCLAIMER\` is now "Official EU test figures, as FINN lists them. Your own
   use depends on how you drive.", and the car's "i" ends "Your own use depends on how and where
   you drive, which the test can't tell Lens." The plug-in hybrid caveat, which cites the
   European Commission's real-world report, is unchanged.
4. **"Noticeably" less or more.** The band's edge is \`EFFICIENCY_BAND\` either side of the
   benchmark, about 15%, and the copy now says so (\`EFFICIENCY_BAND_WORDS\`): "Uses less petrol
   than the FINN Lens benchmark for petrol cars: about 15% below it or more." The sentence under
   the readouts ends "…so its fuel use is lower than / within about 15% of / higher than the
   benchmark." "Frugal for its kind", the deal-breaker and deal-sealer, uses the same edge and
   names the benchmark — not "others that run on the same thing", which it never compared with.

\`ENVIRONMENTAL_METHOD\` was rewritten to open on what the priority measures rather than on
what it excludes, and \`lib/car-labels.ts\` no longer subtitles the priority with
"Judged on emissions, not on equipment" — every other priority's subtitle says something
about the car, and that one said something about Finn Lens.

### "Says who?" — the provenance chips (retired 2026-09-11)

The second round of feedback found the copy was answering *what* without answering *by whose
reckoning*. "Above-average emissions" reads as though a car has failed a standard, and
"Moderately efficient" as though a regulator publishes how much a car ought to burn. Neither is
true, and the three benchmarks in this model are three different kinds of thing:

| Label | What it is measured against | Kind of thing |
| --- | --- | --- |
| \`Class E\` | Pkw-EnVKV §3a A–G bands | **Set in law.** The only one. |
| \`Above-average emissions\` | 136 g/km, ICCT registration data | **An observation.** No legal force. |
| \`Moderately efficient\` | Finn Lens's reference: 5.8 / 5.2 L/100 km, 17 kWh/100 km | **Derived here.** A comparison point — not an official figure, and not what petrol, diesel or electric cars average. |
| \`Diesel\` | — | Context: it says how to read the other two. |

\`environmentalTags(assessment): EnvironmentalTag[]\` returns each label with its own \`title\` and
\`body\` answering that question, and both renderers hang them behind a tap on the chip — one open
at a time, because this is a footnote and not a second article. The emissions chip is explicit
that EU CO₂ limits bind *a manufacturer's whole range over a year*, so no individual car is over
or under one; the efficiency chip is explicit that its benchmark is worked back from the same
136 g/km through the carbon in a litre, which is also why the petrol and diesel figures differ.
Since 2026-09-11 that footnote is \`EfficiencyAssessment.provenance\`, the same text the usage
sections show behind the "i" beside the reference, so the chip and the
section can't tell two stories. The emissions chip no longer says EU limits bind a
manufacturer's range "over a year": 2025–2027 compliance is averaged over three years.

A plug-in hybrid gets a different emissions chip — its own figure is the thing in question, so
comparing it with what other cars emit would answer a question nobody asked.

The powertrain also now appears on the recommendation itself (\`AdviceHero\`, \`ChallengePicker\`),
not only inside the environmental reading. What a car runs on is among the first things that
decides whether a reader can live with it.

### What is pinned

\`environmental.test.ts\` gained a \`the shape of the explanation\` block: emissions lead the
prose (the regression it catches is the old sentence opening on the efficiency half), every
figure carries a label and an explanation, caveats survive and stay short, the tradeoff aside
appears only where the two figures genuinely disagree, and no copy anywhere — sentences,
labels, caveats, method notes — matches the marketing vocabulary this model can't support
("green choice", "clean car", "sustainable", "zero-impact", and the rest).

A \`where each number comes from\` block pins the provenance: that the class chip names the law,
that the emissions chip says the average is "not set by anyone as a target" and that EU limits
bind a manufacturer's range rather than a car, that the efficiency chip names Finn Lens's
reference and where it comes from, and that neither the electric car nor the plug-in hybrid is
shown a fleet comparison it doesn't have.

A \`what the efficiency reference is, and isn't\` block (2026-09-11) pins the arithmetic
(136 ÷ 2 330 and 136 ÷ 2 640), that \`L/100km\` is said in words before it is judged, that the
reference is labelled as Finn Lens's and never as what petrol, diesel or electric cars average
(nor "typical for its kind", "most cars"), that it is never called a limit, that WLTP is called a
standardised test with real-world use higher, that a missing CO₂ figure is never read as zero, and
that the EQS-SUV case stays two answers. \`panel-copy.test.ts\` and \`advice-card.test.ts\` pin the
same wording on the rendered surfaces.
`},{id:`life-bubbles`,file:`LIFE-BUBBLES-SPEC-v2.md`,label:`The conversation's design`,number:`06`,source:`docs/LIFE-BUBBLES-SPEC-v2.md`,markdown:`# Lens Chat: life bubbles — v2

**Status:** v2 · built on branch \`life-bubbles\` (from \`chat-first\`) · **Date:** 1 October 2026 · **Previous:** [v1](LIFE-BUBBLES-SPEC-v1.md)

A shorter Lens chat. The reader taps a few statements about their life, Lens
says what it understood and what it will check, the reader corrects it, and
Lens shows a short result that can be opened up.

---

## What changed from v1

v1 was reviewed. The review liked the bubbles, the deal-breakers and "worth a
look", and objected to how quickly a bubble turned into scoring. v2 keeps the
first three and changes the rest:

| v1 | v2 | Why |
|---|---|---|
| A bubble raised a bundle of features (comforts raised seven). | A bubble counts only its two or three most defensible items. The rest become "worth a look". | "I love my comforts" might mean just heated seats. Tapping a bubble shouldn't claim more than the reader said. |
| Every bubble was "important" unless a follow-up said otherwise, silently. | Every bubble shows how much it counts, in words, on the summary, with one tap to change it. Where a follow-up measures how often, that sets it. | Knowing someone's situation doesn't tell you how strongly they feel about it. A default is fine only if the reader can see it. |
| "Which of these matters most?" when more than three bubbles were picked. | Removed. | It made readers invent a ranking they don't have. |
| Corrections happened a whole bubble at a time. | The summary is where Lens says what it understood. Each checked item can be removed and each suggestion added. | Lens proposes and the reader corrects, without anyone having to learn how the scoring works. |
| Follow-ups were separate questions. | Where the answer changes *what* Lens checks, it's a row of chips that opens under the bubble on the same screen. Only "how often" and "how long" questions are asked separately, and never more than two. | Precision without making the chat longer. |
| Needs Lens can't check were quietly left out. | Each bubble names what FINN's data can't tell Lens ("rear legroom", "whether your child seat fits"). | Start from the reader's life, not from the database, and be honest about where the data stops. |

Unchanged:

- the deal-breakers (§6)
- the weighing arithmetic (§5)
- a folded drawer and a PDF that always has everything (§8)
- Appendix A

## 1. Why

People who tried the chat said two things:

- **The chat is too long.** About twenty questions.
- **The result and its drawer are too wordy.**

The problem isn't that Lens knows too much. **It's that Lens makes everyone
read everything it knows.** The first attempt at a fix, branch \`chat-depth\`,
asked readers how much Lens should ask and explain. Then it put the engine's
priorities and feature levels in the chat, which made everything but the
quick path longer and more technical.

## 2. Principles

- **The engine decides.** The chat collects what the reader said and hands it
  to the same scoring engine.
- **No AI.** Deterministic mappings only. Typed words are read by the built-in
  keyword reader.
- **Lens proposes, the reader corrects.** A bubble is the start of what Lens
  understands, not a preset. Nothing is weighed that the reader hasn't seen
  on the summary.
- **Situation isn't strength.** "I drive long distances" says what happens,
  not how much it matters. How much comes from a follow-up about how often,
  or from the reader, and it's always shown.
- **Only what Lens can verify.** Every claim traces to FINN's data or to a
  labelled assumption. When a real need can't be checked, Lens says so rather
  than swapping in something nearby.
- **Design from the reader's life, map to the data.** Bubbles and chips are
  written as a person would say them. Anything the data can't back is named
  as unchecked, not left out.
- **The questions have a budget.** A typical chat is about five questions. A
  new idea that adds questions has to replace one.
- **Common sense in what can be picked.** Answers that can't both be true
  exclude each other; limits exist only where "most often" applies.
- **Chips use "&", sentences use "and".**

## 3. The conversation

| # | Step | Counts as a question? |
|---|---|---|
| 1 | **"Tell me about your life. Tap everything that fits."** One screen of bubbles (§4). Some open a row of chips under themselves when tapped ("Where do you park?"). There's also "Something else…" for typed words. | Yes (one) |
| 2 | **Up to two "how often" follow-ups**, only for bubbles where frequency is the whole question: "I drive long distances" and "I sit in traffic a lot". | 0–2 |
| 3 | **Monthly limit and how long.** Plus how far they drive, only if they tapped long distances, traffic or budget. Otherwise the assumed 1,000 km is shown on the summary. | Yes (one screen) |
| 4 | **"Anything that's a deal-breaker?"** Optional (§6). | Yes, skippable |
| 5 | **"Here's what I understood"** (§7). Lens's reading of the reader's life, which they can correct. | No, it's the summary |
| 6 | **Result** (§8). | — |

That's **four to six questions**, against about twenty today. Anything already
said (typed earlier, or kept from saved settings) isn't asked again. "Edit
this answer" stays.

**How much Lens explains** isn't asked. The result is short by default and
"See why →" opens it. If a reader keeps opening it, Lens can open it for them
next time (§8).

## 4. The bubbles

Eleven core bubbles. Each lists:

- **Counts:** what Lens weighs once the bubble is tapped. It's deliberately
  small: the items most people with this life would agree with.
- **Checked:** equipment nearly every FINN car has. It isn't rewarded, but a
  car FINN confirms is missing it loses a little.
- **Chips:** a row that opens under the bubble on the same screen. It changes
  *what* is counted. It's optional: tapping nothing keeps the bubble's own
  items, unless the bubble says otherwise.
- **Asks:** a separate "how often" follow-up that sets how much the bubble
  counts.
- **Worth a look:** suggestions shown on the summary with a "+". They're
  counted only if the reader adds them, and only the ones the cars on the page
  actually differ on.
- **Can't check:** what matters for this life but isn't in FINN's data, said
  on the summary.

Everything under Counts, Checked and Worth a look exists in the engine today
(Appendix A).

### 4.1 "I have kids"

- **Counts:** Rear doors
- **Checked:** ISOFIX child seat anchors
- **Chips:** *A baby or toddler seat* · *A booster seat* · *They're older*
  - baby or toddler seat: it counts as a **must have**, and Electric tailgate joins Worth a look ("so you can open the boot while holding a child")
  - older: 3-zone climate control and Rear USB ports join Worth a look
- **Worth a look:** Split-folding rear seats, and whatever the chips added
- **Can't check:** rear legroom, whether a particular child seat fits, boot space (FINN's figure doesn't say whether the seats are up or folded)

### 4.2 "We need six seats or more"

- **Counts:** Six or more seats, as a **must have**
- **Suggests:** the "Six seats or more" deal-breaker, so five-seaters are set aside rather than just scored lower
- **Can't check:** how usable the third row is for adults

### 4.3 "I travel with a dog"

- **Counts:** Split-folding rear seats
- **Worth a look:** Electric tailgate, Rear doors
- **Can't check:** boot size and shape, how high the boot lip is

### 4.4 "I live in the city"

- **Counts:** Narrow width and Compact length (both measured on a sliding scale, not yes/no)
- **Checked:** Automatic gearbox, Parking sensors, Automatic emergency braking
- **Chips:** "Where do you park most often?", up to two:
  - *On the street* → Reversing camera
  - *A garage at home* → width counts more (checks Electrically folding mirrors)
  - *Multi-storey or underground* → 360° camera (checks Electrically folding mirrors)
  - *Open car parks* → Rear cross-traffic alert
  - *A driveway* → nothing extra
- **Worth a look:** Reversing camera, 360° camera, Blind spot warning (less any the chips already counted)
- **Can't check:** turning circle, how well you can see out

### 4.5 "I want help driving and parking"

- **Chips (pick at least one):** "With what?"
  - *Parking* → 360° camera (checks Parking sensors)
  - *Busy traffic and changing lanes* → Blind spot warning (checks Lane keeping assist)
  - *Reversing out* → Rear cross-traffic alert, Reversing camera
- **Checked:** Automatic emergency braking, Traffic sign recognition
- **Worth a look:** Matrix LED headlights, and the other chips' items
- **Can't check:** crash protection (FINN has no crash-test data)

### 4.6 "I drive long distances"

- **Counts:** Level 2 driver assistance, Lumbar support
- **Checked:** Adaptive cruise control, Cruise control, Built-in navigation
- **Also:** for electric cars, a range below 480 km or a 10–80% DC charge slower than 30 minutes holds the score back. Past those, it makes no difference.
- **Asks:** "How often?"
  - *Every day* or *Every week* → must have
  - *About once a month* → matters
  - *A few times a year* → nice to have
- **Also asks:** how far they drive a month, with the limit (step 3)
- **Worth a look:** Head-up display, Matrix LED headlights, Roof rails
- **Can't check:** seat comfort over hours, road noise, how it rides

### 4.7 "I sit in traffic a lot"

- **Counts:** Level 2 driver assistance (keeps speed, distance and lane together in stop-and-go traffic)
- **Checked:** Automatic gearbox, Adaptive cruise control
- **Asks:** "How long is your drive, one way?"
  - *Under 20 minutes* → nice to have
  - *20–45 minutes* → matters
  - *Over 45 minutes* → must have
- **Worth a look:** Keyless entry & start, Wireless CarPlay / Android Auto, Wireless phone charging
- **Can't check:** how smooth the gearbox is in traffic

### 4.8 "The weather here is tough"

- **Chips (pick at least one):** "What's it like?"
  - *Snow & ice* → Heated seats, Heated steering wheel
  - *Rain & fog* → Rain & light sensors, Fog lights
  - *Cold but mostly dry* → Heated seats
  - *Hot summers* → Ventilated seats
- **Checked:** Air conditioning
- **Worth a look:**
  - With snow & ice: All-wheel drive ("grip pulling away and climbing — it doesn't shorten braking"), Auxiliary heater, Heat pump (electric cars), Headlight washers
  - With hot summers: 3-zone climate control
- **Can't check:** how the car handles on snow
- **Shown, not scored:** which tyres FINN fits — all-season, winter, or a summer and a winter set (see As built)

### 4.9 "I drive at night a lot"

- **Counts:** Matrix LED headlights, Cornering lights
- **Worth a look:** Headlight washers, Rain & light sensors, Fog lights
- **Can't check:** how bright the headlights are, beyond their type

### 4.10 "I carry a lot"

- **Chips (pick at least one):** "What do you carry?"
  - *Big or bulky things* → Split-folding rear seats
  - *Bikes, skis or a roof box* → Roof rails
  - *A trailer or caravan* → Towbar, Tows 1,500 kg or more. Suggests the "Must tow" deal-breaker.
- **Worth a look:** Electric tailgate (bulky things), Towbar (bikes: a rack can go on it)
- **Can't check:** boot space (FINN's figure is ambiguous)

### 4.11 "Comfort matters to me"

- **Chips (pick any):** "Which comforts?"
  - *Warm seats* → Heated seats
  - *Keyless entry* → Keyless entry & start
  - *Phone without cables* → Wireless CarPlay / Android Auto, Wireless phone charging
  - *Everyone sets their own temperature* → 3-zone climate control
  - *Electric seats* → Electric front seats
  - *Good sound* → Premium sound system
  - *A sunroof* → Sunroof
- **Counts:** only what's picked. With nothing picked, it counts nothing and the summary shows the comforts as Worth a look ("Tell me which, and I'll count them").
- **Checked:** Apple CarPlay / Android Auto
- **Can't check:** how comfortable the seats are, how quiet the cabin is

### 4.12 "I care about the environment"

- **Counts:** Environmental Impact, the car's own CO₂ figure on the EU A–G scale. There's no equipment.
- **Chips:** "How much?" *It could decide it* (must have) · *It matters* · *A bonus* (nice to have)
- **Suggests:** the "Low CO₂ only (class A–C)" deal-breaker
- **Can't check:** emissions over the car's whole life or from making the electricity, or how much of a plug-in hybrid's driving its figure takes to be on electricity — FINN doesn't say.

### 4.13 "I'm on a budget"

- **Always asks the limit** (step 3). A chip on the limit, *Nothing over it*, makes it a deal-breaker.
- **Counts:** Efficiency, how little fuel or electricity the car uses against others of its kind. That feeds the running cost.
- **Needs a decision:** see §9, question 1. Today price is a limit, not a score.

### 4.14 Other candidates

Not in the core eleven. Add them only if testers miss them:

- **"I often drive other adults around"**: 3-zone climate control, Rear USB ports
- **"Safety comes first"**: Safety & Driver Assistance as a must have

## 5. Weighing it

The **chat-first** model:

- **How much each bubble counts:** *Must have* 4 · *Matters* 2 · *Nice to have* 1.
  - It's set by the "How often" answer or the bubble's chips.
  - Otherwise it starts at *Matters*, shown on the summary with one tap to change.
  - Never silent.
- **A priority's weight** is the sum of the bubbles that reach it.
- **Only counted items count.** A priority isn't also judged on everything else in it. Measured items (length, width) count on a sliding scale.
- **Item level follows the bubble:** Must have → Highly, Matters → Moderately, Nice to have → Somewhat. These words appear only in the drawer's "How I weighed it".
- **Once only:** an item counted by two bubbles counts once, at the higher level.
- **Rules can't be raises:** an item that's also a deal-breaker isn't counted, because every car left has it.
- **Removed items stay removed** for that bubble. If they're saved as settings, they stay removed in new chats too.

## 6. Deal-breakers (rules)

Unchanged from v1. These set cars aside before ranking. Only rules that split the cars on the page are offered.

| Rule | Reads |
|---|---|
| Electric only / Not electric | Fuel type |
| Automatic only | Gearbox |
| No SUV | Body type |
| Must tow | Towbar |
| Six seats or more | Seat count |
| All-wheel drive | Drive type |
| Four doors or more | Door count |
| Low CO₂ only (class A–C) | CO₂ g/km |
| Frugal for its kind only | Consumption against its benchmark |
| Nothing over my limit | Monthly estimate against the limit |

If every car breaks a rule, Lens judges them all as if the rules weren't there, and says so.

## 7. "Here's what I understood"

This summary is where Lens's reading gets corrected. One block per bubble, for example (illustrative):

\`\`\`text
You have kids · a baby or toddler seat              Must have ▾
  I'll check   Rear doors ×   ISOFIX ✓ (nearly every car has it)
  Might matter + Split-folding rear seats   + Electric tailgate
  I can't check rear legroom, or whether your child seat fits.

You live in the city · you park on the street       Matters ▾
  I'll check   Narrow width ×   Compact length ×   Reversing camera ×
  Might matter + 360° camera   + Blind spot warning
  I can't check the turning circle.
\`\`\`

- **×** takes an item out; **+** adds a suggestion. It counts at the bubble's level.
- **The ▾ menu** sets how much the bubble counts: Must have · Matters · Nice to have.
- **Below the bubbles:** monthly limit, how long, distance (or "about 1,000 km — assumed"), and deal-breakers, each with "Change".
- **"Looks good to me — let's go"** judges. Then "Keep these as your settings, or just for this chat?".

There are no priority names, percentages or Standard/Somewhat/Moderately/Highly
here. Those are in the drawer.

## 8. The result and the drawer

**Result card in the chat, default** (the car and figures are illustrative):

\`\`\`text
Your strongest match
Škoda Karoq                               €XXX a month, estimated

Why
  You park on the street  →  4.2 m long, reversing camera
  You have a toddler      →  rear doors, ISOFIX
  You drive long distances →  level 2 driver assistance

One thing to know
  It's €44 a month more than the MG S5.

See why →
\`\`\`

- **Why:** one line per bubble for up to three bubbles, each naming what this car has. Only what it has; gaps go to "One thing to know" or the drawer.
- **One thing to know:** the biggest trade-off, or a limit note (over budget, nothing fits the dates, every car broke a rule).
- **See why →** opens the rest in place: every reason, all trade-offs, the next three closest, and "Because you said…" (which bubbles put weight where).
- **Remembering:** if the reader opens "See why" on two results in a row, later results open that way too. "Keep it short" puts it back.

**Drawer:**

- **Open by default:** why it won, and what it costs.
- **Folded, one tap each:**
  - How it fits what you told me
  - What you'd give up
  - Why not the others
  - How I weighed it (priorities, shares, and each item's level)
  - Costs of use (fuel, mileage)
- **Save as PDF** always has everything.

## 9. Open questions

1. **Does "I'm on a budget" need a cost score?** Today price is only a limit.
   - Option A (no engine change): the limit plus Efficiency.
   - Option B: a new "Value" priority where a cheaper monthly estimate scores higher. That's new engine work.
2. **Is "Matters" the right default?** Or should a bubble with no "how often" answer start at *Nice to have*, so that importance is only ever raised by something the reader said?
3. **How many passengers?** Today it's a question and decides seats and doors. Here it's implied by "I have kids" and "six seats". Is that enough, or does "I have kids" need a *How many?* chip?
4. **Night driving and weather:** two bubbles, or one "Dark roads & bad weather"?
5. **Chips under bubbles:** does one screen stay readable when three or four bubbles have opened their chips? Worth a paper prototype before building.
6. **Removed items in saved settings:** keep them removed in new chats (as proposed), or start fresh each time?
7. **Branch:** build from \`chat-first\` (its scoring suits this). From \`chat-depth\`, bring over only "See why / Show me more".

### As built

How the open questions were settled on \`life-bubbles\`, each the lean the spec already had:

1. **Budget:** option A — the limit (always asked), "Nothing over it" as a deal-breaker, and Efficiency. No new engine score.
2. **Default:** *Matters*, shown on the summary as Lens's guess with one tap to change it.
3. **Passengers:** no count question; "I have kids" counts rear doors, "We need six seats or more" six seats.
4. **Night and weather:** two bubbles.
5. **Chips under bubbles:** built; worth the paper prototype still, with real readers.
6. **Removed items:** stay removed, in saved settings too.

Changed after trying it (5 October 2026):

- **Bubbles in four sections**, one screen each, rather than all thirteen at once: who rides with you; where and how you drive (how often follows straight after); what the car has to cope with; what else matters. More screens, each one short.
- **"Select all / Unselect all"** on chip rows where several can be true and there's no limit; it never picks two that can't both be true.
- **What you carry:** "Shopping & everyday bags" (electric tailgate) apart from "Bulky things: furniture, a pram, sports kit" (split-folding seats).
- **Comfort:** every comfort FINN lists that Lens can score, by its name — heated seats and steering wheel, ventilated seats, pre-heating, keyless entry & start, wireless CarPlay / Android Auto, wireless charging, 3-zone climate, electric seats, lumbar support, premium sound, sunroof, rear USB ports, head-up display. Leather seats and ambient lighting are said not to count.
- **The environment:** "How big a part should CO₂ play in my pick?" — a big part · as much as my other needs · a small part.
- **A budget:** "A hard limit: nothing over it" (cars over it set aside) or "Some give: a little over is fine" (up to about 15% over still counts — the engine's own soft limit). The limit question is "all costs together", and says what that is.
- **From when:** after how long — the soonest (next month) and the three after, or later.
- **Deal-breakers in sections:** from what you told me, money, fuel & emissions, the car itself.
- **Contradictions ruled out:** ~~mostly dry weather beside rain or snow~~ (since 7 October 2026 "Cold & dry" is **Cold winters**, wet or dry, and combines with rain; snow counts the cold itself), "no fixed limit" after "I'm on a budget", a few hundred km a month after long drives every day, an item counted twice, a heat pump suggested to someone who won't go electric.

Changed after trying it again (5 October 2026):

- **Deal-breakers & deal-sealers** replace the deal-breakers question: a row per thing, each set to Doesn't matter, a deal-breaker (must / mustn't — a rule, as before) or a deal-sealer (counts as a must have, sets nothing aside). Rows offer only what Lens can do: no "electric seals it", since being electric is ruled on, not scored.
- **Short labels, tooltips:** bubbles and chips have short labels ("Kids", "In the city", "Bulky things", "Hard limit"); the "i" is a tooltip with a brief explanation and what Lens checks, instead of a card opening under the chips.
- **Who rides with you:** kids, adults (beside you asks nothing extra; in the back counts rear doors) and a dog. "Six seats or more" moved to deal-breakers & sealers.

- **Recommended from what you said:** comfort chips that earlier answers point to are starred and come first, and their "i" says why — "Recommended because you said winters bring snow and ice, and you spend a lot of time on the road." Never picked for the reader; a bubble's own answers never recommend its own chips. Rain alone doesn't recommend warmth, and time on the road only adds to a heated wheel beside a cold-weather reason.

- **One scale for how much something counts** (6 October 2026): *Top priority · Important · Nice to have* (4 · 2 · 1, unchanged) replaces *Must have · Matters · Nice to have* and the CO₂ question's "a big part / as much as the rest / a small part". Each says what it means — Top priority counts twice as much as Important, Important twice as much as Nice to have — and a deal-sealer counts as a top priority. "Must have" now only ever means a deal-breaker, which rules cars out; none of the levels does.

- **How green, not how much** (6 October 2026): the environment asks "How green should the car be?" — *Clean for its fuel type* (judged on consumption against cars on the same fuel, so a frugal petrol scores well; suggests nothing), *Moderately green* (the CO₂ label, where plug-in hybrids usually sit; suggests low CO₂ as a deal-breaker) or *Totally green* (the CO₂ label as a top priority, where electric is 0 g/km on the road; suggests electric as a deal-breaker). How much it counts is the one scale on the summary.
- **Deal rows keep Must be / Must have / Mustn't be / Seals it** (tried as "Flexible / Hard line" and reverted the same day), each option's meaning on hover; a row Lens can only rule on says it can't seal the deal. "Low CO₂ (class A–C)" is called **Low CO₂ emissions**, with the class in its "i".

- **What it runs on, and plug-in hybrids** (6 October 2026): "What can it run on?" — electric, plug-in hybrid, petrol, diesel, any or all — is asked before deal-breakers, and replaces the Electric deal row. FINN lists every plug-in hybrid (44 of 728) with one combined litres figure and no electricity figure, so its electricity is the EU's official figure for the same car, from the EEA's registration data, matched on make, model, CO₂ and fuel figure, with the source linked and the caveat that both figures assume the EU test's mix of driving. Where nothing matches, it's named as missing — and under a hard limit, a car that can't be confirmed is set aside, saying exactly what's missing.
- **"See why" is what the car got right**: everything it has for each thing said, and how it was weighed. Gaps and trade-offs are in "The whole case".
- **Checked against FINN's raw responses** (7 October 2026): six pages of \`/api/cars\` as finn.com sent them, 127 cars. Tyres are FINN's own field, so §4.8 no longer lists them as something Lens can't check: FINN fits all-season tyres (110 of the 127), winter tyres (13) or a summer and a winter set (4), and the drawer says which — winter tyres had been read as "FINN doesn't say". An early-booking car is quoted at the discounted price from FINN's price list rather than the price before the discount (5 cars, €10 a month each), which is what finn.com's own cards charge. An electric car's range, which FINN sends as text, now reaches everything that reads it. FINN's data-audit notes ("Audit override: hasLeatherSeats") are taken out of the equipment text before the model reads it. The details are in [How FINN Lens decides §2.1](HOW-FINN-LENS-DECIDES.md#21-reading-finns-data).

Two things the spec promised needed engine or flow changes to be true:

- **"Checked" items** (§4) did nothing in the chat's ask-only scoring unless a need named them, and a named one was rewarded like a raise. The engine now takes them as \`preferences.checked\`: a car FINN confirms is missing one loses a little, having one earns nothing.
- **A bubble a deal-breaker fully settles** — six seats beside "Six seats or more" — leaves no need behind, so the story doesn't repeat the rule as a need; the summary says the rule settles it.

Changed in the beta's final check (12 October 2026):

- **No "Select all"**: every chip is one the reader picks; where you park takes up to two, the comforts up to seven.
- **Every answer does something.** Each chip was measured against FINN's 698-car snapshot. Two changed nothing and are gone: *A driveway* (it asked nothing of the car, and took one of the two parking picks) and *Keyless entry & start* (standard on 653 of 698 cars, so only ever checked, and it moved no score beside most comforts) — 13 comforts remain. *Booster seat* stays, as the answer for kids past a baby seat, and its "i" says so: kids count as Important, with rear doors and ISOFIX. A test holds every answer to changing something; *Moderately green* is the one exception, naming the environment's default.
- **"Also making sure it has" only where it's true.** A checked item can mark a car down only inside a priority something else is scored in, so the summary names a check only then, and a bubble's "i" only when it holds however that bubble is answered. "In traffic" alone no longer claims an automatic gearbox (it counts beside "In the city"), nor "In the city" emergency braking.
- **"See why"** is what the car got right, and the next closest. How it was weighed is in "The whole case", the winner's drawer.

---

## Appendix A: everything Lens takes into account today

Unchanged from v1.

From \`lib/reasoning-engine/constants.ts\` and \`lib/lens-chat/evidence.ts\`, as
of this date.

- **Raisable:** a reader or a bubble can make it count more (Somewhat 2×,
  Moderately 3×, Highly 4× a standard item).
- **Niche:** not counted at all until raised.
- **Checked:** nearly every car has it; it isn't rewarded, but a confirmed
  miss costs a little.

### A.1 Safety & Driver Assistance

| Item | Kind |
|---|---|
| Blind spot warning | Raisable |
| Rear cross-traffic alert | Raisable |
| Matrix LED headlights | Raisable (also counts under Long Distance at standard) |
| Automatic emergency braking | Checked |
| Lane keeping assist | Checked |
| Traffic sign recognition | Checked |
| Emergency call system (eCall) | Checked |
| Tyre pressure monitoring | Checked |

Crash protection isn't in FINN's data.

### A.2 City & Parking

| Item | Kind |
|---|---|
| Compact length | Raisable, measured: 4.0 m or shorter scores full, 4.3 m 80%, 4.6 m 55%, 4.9 m 30%, 5.2 m and longer nothing |
| Narrow width | Raisable, measured: 1.75 m or narrower full, 1.85 m 70%, 1.95 m 35%, 2.05 m and wider nothing |
| Reversing camera | Raisable |
| 360° camera | Raisable |
| Parking sensors | Checked |
| Parking assistant | Checked |
| Electrically folding mirrors | Checked |
| Automatic gearbox | Checked |

### A.3 Practicality

| Item | Kind |
|---|---|
| Rear doors | Raisable (from FINN's door count) |
| Five or more seats | Raisable (from seat count) |
| Split-folding rear seats | Raisable |
| Electric tailgate | Raisable |
| Towbar | Niche |
| Tows 1,500 kg or more | Niche (braked towing rating) |
| Roof rails | Niche |
| Six or more seats | Niche |
| ISOFIX child seat anchors | Checked |

Boot space isn't scored: FINN's figure sometimes means seats up and sometimes folded, without saying which.

### A.4 Long Distance Travel

| Item | Kind |
|---|---|
| Level 2 driver assistance | Raisable (FINN's assistance level) |
| Lumbar support | Raisable |
| Head-up display | Raisable |
| Spare wheel | Niche |
| Matrix LED headlights | Counted here at standard (home: Safety) |
| Cruise control | Checked |
| Adaptive cruise control | Checked |
| Built-in navigation | Checked |
| Electric range | Limit, electric only: below 480 km holds the score back |
| DC charging time (10–80%) | Limit, electric only: slower than 30 min holds the score back |

### A.5 Climate Suitability

| Item | Kind |
|---|---|
| Heated seats | Raisable |
| Heated steering wheel | Raisable |
| Rain & light sensors | Raisable |
| Cornering lights | Raisable |
| Ventilated seats | Raisable |
| Fog lights | Raisable |
| Auxiliary heater | Raisable |
| Headlight washers | Raisable |
| Heat pump | Raisable (matters for electric cars) |
| All-wheel drive | Niche |
| Air conditioning | Checked |

### A.6 Comfort

| Item | Kind |
|---|---|
| Wireless phone charging | Raisable |
| Keyless entry & start | Raisable |
| Premium sound system | Raisable |
| 3-zone climate control | Raisable |
| Electric front seats | Raisable |
| Wireless CarPlay / Android Auto | Raisable |
| Sunroof | Raisable |
| Rear USB ports | Raisable |
| Apple CarPlay / Android Auto | Checked |

### A.7 Environmental Impact (a figure, no equipment)

- The car's reported CO₂ in g/km, placed on the EU A–G classes: A 0, B up to 95, C 115, D 135, E 155, F 175, G above.
- Emissions while driven only, not the car's whole life.
- Plug-in hybrids are flagged: their figure assumes regular charging.

### A.8 Efficiency (a figure, no equipment)

- The car's reported consumption against a benchmark for its own kind:
  - petrol about 5.8 L/100 km
  - diesel about 5.2 L/100 km
  - electric 17 kWh/100 km
- These are derived from the 136 g/km new-combustion-car average, and a rounded mid-size EV figure.
- Plug-in hybrids aren't judged.

### A.9 Cost (every car, always)

- **FINN's monthly price** on the term that covers the reader's period (or FINN's default term), with nothing paid upfront, as FINN's current price list gives it — on an early-booking offer, the discounted price.
- **Fuel or charging** at an assumed price: petrol €1.75/L, diesel €1.70/L, electricity €0.32/kWh. This is labelled as an assumption, not a quote.
- **The FINN mileage package** the stated distance needs. FINN's price includes 500 km a month; if the reader doesn't say, Lens assumes 1,000 km and says so.
- **Nothing else:** parking and tolls aren't included.
- **Missing costs:** a line Lens can't estimate is left out of the total and named, never counted as €0.

### A.10 Read, but not scored

Shown in the drawer or used only for rules:

- **Equipment:**
  - LED headlights
  - Privacy glass
  - Leather seats
  - Ambient interior lighting
  - Front USB ports
  - Start/stop system
  - Electric parking brake
  - Alloy wheels
  - Hill start assist
  - Which tyres FINN fits: all-season, winter, or a summer and a winter set
- **Figures:** boot space (ambiguous), electric range as a figure
- **Used only by rules:** electric (fuel type), SUV (body), CO₂ class A–C, frugal for its kind

### A.11 Fit bands

Each car gets **Strong**, **Good**, **Partial** or **Limited match**, or "not enough data" when FINN lacks what's needed. The band is worked out from how much of what the reader asked for FINN lists on the car, and from its CO₂ or consumption where those count.
`},{id:`shortlist`,file:`FUTURE-SHORTLIST.md`,label:`Next: the shortlist`,number:`07`,source:`docs/FUTURE-SHORTLIST.md`,markdown:`# Future: the shortlist

> **Status:** agreed, not built. Written down on 2026-09-29 so it can be picked up after the chat work. Nothing here exists in the code yet.

## Why it's needed

A chat judges the cars on one finn.com page. A reader usually runs several searches: different filters, maybe different answers. Each search produces its own pick, and none of them is compared with the others. Five searches can leave a reader with five "best" cars from five different lists and no way to tell which is best overall. The way people settle that is by elimination: keep the ones worth keeping, then weigh them against each other.

Lens can't do that for them in one pass, because it can only see what FINN's page shows it. It has neither FINN's whole catalogue nor a way to apply FINN's filters and the reader's answers together. The shortlist is the reader's own answer to that gap.

The reader may also want to show the shortlist to someone else: a partner, or whoever is paying half.

## What the reader can do

1. **Pin a car to their shortlist, from a drawer.** The pin lives in the drawer behind a chip (a car's drawer and the winner's), not on FINN's cards. So it only exists once a chat has judged a car and the reader has opened the reasoning for it. A car gets pinned because of what Lens said about it, not in passing while scrolling.
2. **See the shortlist.** It spans chats and pages: cars pinned from different searches sit side by side.
3. **Judge the shortlist.** Run a judgement over just the pinned cars, with a chat's answers or the reader's saved settings (the reader chooses which, and it's always said). This comparison is what the separate searches couldn't give: the pick of the picks, with the same chips, drawers and trophy the page gets.
4. **Eliminate.** Unpin cars as they're ruled out, and re-judge.
5. **Export and share.** Save the shortlist as a file (PDF) to send on. The winner's full case can be included or left out, the reader's choice. The export says what the cars were judged against and when.

## Constraints to keep

- **One rule for whose answers.** The shortlist judgement names the chat, or the saved settings, it used. The playground ran into trouble here ("one rule for whose answers judge the reader's cars"); don't repeat it.
- **Pinned cars go stale.** Prices, terms and delivery dates change after a car is pinned. The playground refreshed pinned cars from FINN's own responses as they arrived (\`lib/refresh-pinned.ts\` on \`playground\`). Bring that back, or re-fetch on judge, and say when a pinned car's data is old or the car has gone.
- **Relative scores.** Boot space, range and CO₂ scores are relative to the set being judged. A car can therefore read differently in the shortlist than on the page it was pinned from. The drawer should say which set it's reading.
- **Nothing on the cards.** No pin buttons on FINN's cards, before or after a judgement.

## Where to start

\`playground\` has most of the pieces to borrow from: \`pinnedCars\` storage, the pinned-cars page (\`entrypoints/pins/\`), \`refresh-pinned.ts\`, and the PDF export with clickable links (\`lib/advice-pdf.ts\`, already on this branch). The engine takes any set of cars, so judging a shortlist is \`judgeWith(understanding, pinnedCars, …)\`.

## Open questions

- Should a shortlist have a cap (say, 8 cars) so the comparison stays readable?
- One shortlist, or one per "project" (e.g. "car for me" vs "car for my parents")?
- Should the export be a PDF only, or also a link? A link would need a server, which Lens doesn't have.
`}],mn=[{label:`Start here`,items:U.slice(0,3).map(hn)},{label:`How it decides`,items:U.slice(3,5).map(hn)},{label:`Design`,items:U.slice(5).map(hn)}];function hn(e){return{id:`docs/${e.id}`,label:e.label,number:e.number}}function gn(e){let[,t,...n]=decodeURIComponent(e.replace(/^#/,``)).split(`/`);return{doc:U.find(e=>e.id===t)??U[0],anchor:n.length?n.join(`/`):null}}function _n(e){return e.trim().toLowerCase().replace(/[^\p{L}\p{N}\p{M}\s_-]/gu,``).replace(/\s/g,`-`)}function vn({hash:e}){let{doc:t,anchor:n}=gn(e),r=(0,v.useMemo)(()=>({__html:V.parse(t.markdown,{async:!1,gfm:!0})}),[t]),i=(0,v.useRef)(null);return(0,v.useEffect)(()=>{let e=i.current;if(!e)return;let r=new Map;for(let t of e.querySelectorAll(`h1, h2, h3, h4, h5, h6`)){let e=_n(t.textContent??``),n=r.get(e)??0;r.set(e,n+1),t.id=n?`${e}-${n}`:e}for(let n of e.querySelectorAll(`a[href]`)){let e=n.getAttribute(`href`)??``;if(/^https?:/.test(e)){n.target=`_blank`,n.rel=`noopener noreferrer`;continue}if(e.startsWith(`#`)){n.setAttribute(`href`,`#docs/${t.id}/${e.slice(1)}`);continue}let[r=``,i]=e.split(`#`),a=U.find(e=>r.split(`/`).pop()===e.file);a?n.setAttribute(`href`,`#docs/${a.id}${i?`/${i}`:``}`):n.replaceWith(...n.childNodes)}let a=n?document.getElementById(decodeURIComponent(n)):null;a?a.scrollIntoView({block:`start`}):window.scrollTo(0,0)},[r,t.id,n]),(0,b.jsxs)(`div`,{className:`relative space-y-4 pb-6`,children:[(0,b.jsx)(`aside`,{className:`absolute top-0 right-full mr-10 hidden h-full w-52 xl:block`,children:(0,b.jsx)(`div`,{className:`sticky top-8`,children:(0,b.jsx)(H,{groups:mn,active:`docs/${t.id}`,variant:`rail`})})}),(0,b.jsx)(pn,{icon:(0,b.jsx)(_e,{}),eyebrow:`Documentation`,title:`The project's documentation`,children:(0,b.jsx)(`p`,{children:`How Finn Lens is built, how it decides, and what changed in each version — the repository's own documents, as they are in this build. Pick one from the contents.`})}),(0,b.jsx)(`div`,{className:`xl:hidden`,children:(0,b.jsx)(H,{groups:mn,active:`docs/${t.id}`,variant:`inline`})}),(0,b.jsxs)(`article`,{className:`rounded-2xl border border-finn-cotton bg-white p-5 sm:p-8`,children:[(0,b.jsxs)(`p`,{className:`mb-4 text-[12.5px] font-bold text-finn-black/70`,children:[`From the repository: `,(0,b.jsx)(`code`,{className:`font-mono`,children:t.source})]}),(0,b.jsx)(`section`,{ref:i,className:`doc-prose`,dangerouslySetInnerHTML:r})]})]})}var yn=[{label:`The basics`,items:[{id:`guide-what`,label:`What is Finn Lens?`,number:`01`},{id:`guide-why`,label:`Why it exists`,number:`02`}]},{label:`Using Lens`,items:[{id:`guide-how`,label:`How it works`,number:`03`},{id:`guide-results`,label:`Understanding results`,number:`04`}]},{label:`About this beta`,items:[{id:`guide-beta`,label:`Status and limitations`,number:`05`},{id:`guide-next`,label:`What might come next`,number:`06`},{id:`guide-built`,label:`How it was built`,number:`07`},{id:`guide-feedback`,label:`Feedback and bug reports`,number:`08`}]}],bn=yn.flatMap(e=>e.items.map(e=>e.id));function xn({version:e}){let t=ln(bn);return un(),(0,b.jsxs)(`div`,{className:`relative space-y-4 pb-6`,children:[(0,b.jsx)(`aside`,{className:`absolute top-0 right-full mr-10 hidden h-full w-52 xl:block`,children:(0,b.jsx)(`div`,{className:`sticky top-8`,children:(0,b.jsx)(H,{groups:yn,active:t,variant:`rail`})})}),(0,b.jsxs)(pn,{icon:(0,b.jsx)(de,{}),eyebrow:`Beta guide`,title:`The Finn Lens guide`,badge:(0,b.jsx)(`span`,{className:`rounded-full bg-finn-warning-lift px-2.5 py-1 text-[11px] font-bold text-finn-warning-ink`,children:e}),children:[(0,b.jsx)(`p`,{children:`Learn how Lens works, how to read its recommendations, and what to keep in mind while testing this version.`}),(0,b.jsxs)(`div`,{className:`rounded-xl bg-finn-pale-blue/70 p-3.5`,children:[(0,b.jsx)(`p`,{className:`text-[13px] font-bold text-finn-black`,children:`An early working prototype for evaluation`}),(0,b.jsx)(`p`,{className:`mt-1 text-[13px] leading-relaxed text-finn-black/80`,children:`Lens starts with your circumstances, compares the cars available on FINN against your needs, and explains the trade-offs. Its recommendations depend on your answers, the available vehicle data, and documented assumptions. They are not a guarantee that a car is right for you or that its actual running costs will match the estimate.`})]}),(0,b.jsxs)(`div`,{className:`flex flex-wrap gap-2`,children:[(0,b.jsx)(Cn,{children:`No AI in this beta`}),(0,b.jsx)(Cn,{children:`Personalized comparisons`}),(0,b.jsx)(Cn,{children:`Explainable results`})]})]}),(0,b.jsx)(`div`,{className:`xl:hidden`,children:(0,b.jsx)(H,{groups:yn,active:t,variant:`inline`})}),(0,b.jsxs)(x,{id:`guide-what`,icon:(0,b.jsx)(de,{className:`h-5 w-5`}),title:`What is Finn Lens?`,children:[(0,b.jsxs)(G,{children:[(0,b.jsxs)(`p`,{children:[`Finn Lens is an unofficial browser extension for`,` `,(0,b.jsx)(`strong`,{children:`finn.com`}),`, where cars are offered on monthly subscriptions. It helps you work out which available car best fits `,(0,b.jsx)(`em`,{children:`your`}),` circumstances.`]}),(0,b.jsx)(`p`,{children:`Tell Lens who rides with you, how and where you drive, what the car needs to handle, what you can spend, and how long you need it. Lens evaluates the cars on the page against your answers, ranks eligible options, and explains the reasoning and trade-offs.`}),(0,b.jsxs)(`p`,{children:[`Lens is `,(0,b.jsx)(`strong`,{children:`not made by or affiliated with FINN`}),`.`]})]}),(0,b.jsx)(wn,{children:`Lens is designed to answer "Which car fits my situation?" rather than simply "Which cars have these specifications?"`})]}),(0,b.jsx)(x,{id:`guide-why`,icon:(0,b.jsx)(he,{className:`h-5 w-5`}),title:`Why it exists`,children:(0,b.jsxs)(G,{children:[(0,b.jsx)(`p`,{children:`Filters help you narrow down cars by fuel, body type, price, or equipment. They don't necessarily help you weigh those things against one another.`}),(0,b.jsx)(`p`,{children:`Perhaps one car has the parking camera you'll use every day, another has a lower subscription price but higher estimated running costs, and a third doesn't fit your rental dates. A specification list leaves you to make those trade-offs yourself.`}),(0,b.jsx)(`p`,{children:`Lens starts with your circumstances, evaluates the relevant criteria using available data, and explains why a car ranks where it does, including what you might give up by choosing it.`})]})}),(0,b.jsx)(x,{id:`guide-how`,icon:(0,b.jsx)(xe,{className:`h-5 w-5`}),title:`How it works`,children:(0,b.jsxs)(`div`,{className:`space-y-6`,children:[(0,b.jsx)(K,{n:1,title:`Tell Lens about your situation`,children:(0,b.jsxs)(`p`,{children:[`Open the chat using the bubble on finn.com. Lens asks about your passengers, driving habits, practical needs, budget, rental dates and duration, mileage, fuel preferences, and deal-breakers. Tap an answer or type one. The`,` `,(0,b.jsx)(`strong`,{children:`i`}),` beside an answer explains what Lens checks.`]})}),(0,b.jsx)(K,{n:2,title:`Review what Lens understood`,children:(0,b.jsxs)(`p`,{children:[`Before evaluating cars, Lens shows how it interpreted your answers, which criteria it will check, and how much each preference counts. If something looks wrong, use`,` `,(0,b.jsx)(`strong`,{children:`This doesn't look right`}),` to adjust the criteria, change priorities, or answer a question again. You can save your settings for future chats.`]})}),(0,b.jsxs)(K,{n:3,title:`Requirements filter; preferences are weighed`,children:[(0,b.jsx)(`p`,{children:`Some answers determine whether a car is eligible to win. Others affect how well an eligible car scores. The distinction matters: a preference can influence the ranking without excluding a car.`}),(0,b.jsxs)(`div`,{className:`mt-3 grid gap-3 sm:grid-cols-2`,children:[(0,b.jsxs)(q,{title:`Requirements`,children:[(0,b.jsx)(`p`,{children:`A car that fails a requirement is excluded from the regular ranking.`}),(0,b.jsxs)(`ul`,{className:`mt-2 list-disc space-y-1.5 pl-5`,children:[(0,b.jsxs)(`li`,{children:[(0,b.jsx)(`strong`,{children:`Must have, Must be, or Mustn't be:`}),` `,`explicit deal-breakers, such as requiring an automatic gearbox.`]}),(0,b.jsx)(`li`,{children:`Fuels you didn't select.`}),(0,b.jsx)(`li`,{children:`Your rental dates. “A month either way” loosens them; “Doesn't matter” lifts them.`}),(0,b.jsx)(`li`,{children:`Your monthly budget, when you've asked Lens to treat it as a hard limit.`})]}),(0,b.jsx)(`p`,{className:`mt-2`,children:`If FINN's data can't confirm that a car meets a requirement, Lens may rule it out. If nothing qualifies, Lens can ask which constraint you could relax or offer the nearest available dates.`})]}),(0,b.jsxs)(q,{title:`Preferences`,children:[(0,b.jsx)(`p`,{children:`Preferences contribute to a car's fit. For example, asking about snow and ice can lead Lens to check for heated seats and a heated steering wheel.`}),(0,b.jsxs)(`ul`,{className:`mt-2 list-disc space-y-1.5 pl-5`,children:[(0,b.jsxs)(`li`,{children:[(0,b.jsx)(`strong`,{children:`Top priority:`}),` twice the weight of Important.`]}),(0,b.jsxs)(`li`,{children:[(0,b.jsx)(`strong`,{children:`Important:`}),` standard weighting.`]}),(0,b.jsxs)(`li`,{children:[(0,b.jsx)(`strong`,{children:`Nice to have:`}),` half the weight of Important.`]})]}),(0,b.jsxs)(`p`,{className:`mt-2`,children:[(0,b.jsx)(`strong`,{children:`Seals it`}),` gives a preference Top priority weighting. It does not make that feature mandatory. Use a must-have requirement when something is non-negotiable.`]})]})]})]}),(0,b.jsxs)(K,{n:4,title:`Cars are scored against your answers`,children:[(0,b.jsx)(`p`,{children:`Lens scores how well each car matches your criteria and weights those criteria by importance. It doesn't add its own preferences, and a car's score doesn't depend on which other cars happen to be on the page.`}),(0,b.jsx)(Tn,{title:`How individual criteria affect the score`,children:(0,b.jsxs)(`ul`,{className:`list-disc space-y-2 pl-5`,children:[(0,b.jsx)(`li`,{children:`Measurements, CO₂, and consumption can contribute on a scale rather than as a simple yes-or-no check. Consumption is compared against a reference for the car's fuel type.`}),(0,b.jsx)(`li`,{children:`Equipment that nearly every FINN car has, such as emergency braking, earns nothing for being there. A car FINN says lacks it loses a little, wherever something else you asked for is scored in the same group. The summary only lists the ones that do.`}),(0,b.jsxs)(`li`,{children:[(0,b.jsx)(`strong`,{children:`Overlaps count once.`}),` When two of your answers point to the same item, it's counted a single time, at the higher of the two levels.`]}),(0,b.jsxs)(`li`,{children:[(0,b.jsx)(`strong`,{children:`Unknown isn't no.`}),` When the data doesn't establish whether a car has a feature, Lens can leave that criterion unscored and identify relevant uncertainty in the result.`]})]})})]}),(0,b.jsxs)(K,{n:5,title:`Cost determines eligibility, not preference`,children:[(0,b.jsx)(`p`,{children:`A cheaper car doesn't score higher simply because it costs less. With a monthly limit, estimated cost decides which cars may win: one over it can't be the pick while a car within it exists. A hard limit goes further and rules cars over it out.`}),(0,b.jsx)(`p`,{className:`mt-2`,children:`The estimated monthly cost can include:`}),(0,b.jsxs)(`ul`,{className:`mt-2 list-disc space-y-1.5 pl-5`,children:[(0,b.jsxs)(`li`,{children:[(0,b.jsx)(`strong`,{children:`Subscription:`}),` FINN's monthly price, including VAT, using the shortest available term that covers your rental dates.`]}),(0,b.jsxs)(`li`,{children:[(0,b.jsx)(`strong`,{children:`Fuel or charging:`}),` estimated from the consumption FINN lists for the car and assumed prices: petrol €1.75/litre, diesel €1.70/litre, and electricity €0.32/kWh.`]}),(0,b.jsxs)(`li`,{children:[(0,b.jsx)(`strong`,{children:`Mileage package:`}),` the price of the smallest FINN mileage package that covers your monthly distance, if it's more than the price includes.`]})]}),(0,b.jsx)(`div`,{className:`mt-3 rounded-xl border border-finn-cotton bg-white p-3.5`,children:(0,b.jsxs)(`div`,{className:`flex items-start gap-2`,children:[(0,b.jsx)(be,{"aria-hidden":`true`,className:`mt-0.5 h-4 w-4 shrink-0 text-finn-accent-blue`}),(0,b.jsxs)(`div`,{className:`min-w-0`,children:[(0,b.jsx)(`p`,{className:`text-[13px] font-bold text-finn-black`,children:`Where the mileage price comes from`}),(0,b.jsx)(`p`,{className:`mt-1 text-[13px] leading-relaxed text-finn-black/80`,children:`FINN's data lists each car's mileage packages and what each adds to the monthly price, from 500 km a month, at no extra cost, up to 5,000 km. Lens takes them from there, and adds FINN's per-kilometre price only for distance beyond the largest package. For a car whose data doesn't list its packages, Lens assumes 500 km a month is included and says so.`})]})]})}),(0,b.jsx)(`p`,{className:`mt-3`,children:`If you haven't specified your mileage, Lens uses an assumed distance of 1,000 km per month for its estimate. Treat the total as an estimate, not a guaranteed quote.`})]}),(0,b.jsx)(K,{n:6,title:`Lens explains the result`,children:(0,b.jsx)(`p`,{children:`See which car came out ahead, why it won, where it falls short, and how it compares with alternatives. You can inspect an individual car's explanation and save the results as a PDF.`})}),(0,b.jsxs)(Tn,{title:`Where the vehicle facts come from`,children:[(0,b.jsxs)(G,{children:[(0,b.jsx)(`p`,{children:`Lens uses the data available from FINN, including equipment, measurements, consumption and CO₂ figures, prices, subscription terms, and delivery windows.`}),(0,b.jsx)(`p`,{children:`Where a particular figure isn't available, Lens may use an external reference. For example, plug-in hybrid electricity consumption can come from EU registration data, and CO₂ classes use Germany's classification rules.`})]}),(0,b.jsxs)(`div`,{className:`mt-3 space-y-2`,children:[(0,b.jsx)(En,{label:`FINN data`,description:`Information provided by the listing or vehicle data.`}),(0,b.jsx)(En,{label:`External reference`,description:`Information from another source, used where FINN data is missing.`}),(0,b.jsx)(En,{label:`Lens estimate or assumption`,description:`A calculated value or an input Lens uses because the exact value isn't available.`})]})]})]})}),(0,b.jsxs)(x,{id:`guide-results`,icon:(0,b.jsx)(Te,{className:`h-5 w-5`}),title:`Understanding the results`,children:[(0,b.jsx)(G,{children:(0,b.jsx)(`p`,{children:`Each evaluated car receives a verdict chip. The labels tell you how well it matches your answers and whether it can win.`})}),(0,b.jsxs)(`dl`,{className:`mt-4 divide-y divide-finn-cotton overflow-hidden rounded-2xl border border-finn-cotton bg-white`,children:[(0,b.jsxs)(J,{chip:(0,b.jsx)(h,{}),children:[(0,b.jsx)(`strong`,{children:`Best for you.`}),` Lens's pick: the best fit among the cars that meet your requirements.`]}),(0,b.jsxs)(J,{chip:(0,b.jsx)(h,{label:`Closest match`}),children:[(0,b.jsx)(`strong`,{children:`Closest match.`}),` Lens's pick when nothing on the page fits your budget, your dates or a deal-breaker you chose to keep. It's the nearest thing, not a match, and Lens says which limit it misses.`]}),(0,b.jsxs)(J,{chip:(0,b.jsxs)(`span`,{className:`flex flex-wrap gap-1.5`,children:[(0,b.jsx)(m,{band:`strong`,label:`Strong match`}),(0,b.jsx)(m,{band:`good`,label:`Good match`}),(0,b.jsx)(m,{band:`partial`,label:`Partial match`}),(0,b.jsx)(m,{band:`limited`,label:`Limited match`})]}),children:[(0,b.jsx)(`strong`,{children:`Match strength.`}),` How well the car fits your preferences according to its score. Strong starts at 65/100, Good at 45, Partial at 25, and Limited is below 25. The chip also shows the car's place in the ranking, and “over budget” when it costs more than your limit.`]}),(0,b.jsxs)(J,{chip:(0,b.jsx)(m,{band:`unknown`,label:`Not enough data`}),children:[(0,b.jsx)(`strong`,{children:`Not enough data.`}),` The available information doesn't cover enough of your top two priorities to judge the car confidently.`]}),(0,b.jsxs)(J,{chip:(0,b.jsx)(m,{band:`unknown`,label:`Ruled out`}),children:[(0,b.jsx)(`strong`,{children:`Ruled out.`}),` The car fails a requirement, such as “not for your dates”. Its drawer says which one, and why.`]})]}),(0,b.jsxs)(`div`,{className:`mt-4 grid gap-3 sm:grid-cols-2`,children:[(0,b.jsx)(q,{title:`What a result tells you`,children:(0,b.jsxs)(`ul`,{className:`list-disc space-y-1.5 pl-5`,children:[(0,b.jsx)(`li`,{children:`How cars compare against the things you told Lens, using available vehicle information.`}),(0,b.jsxs)(`li`,{children:[`Why the pick won and what you'd give up by choosing it: click its chip, or `,(0,b.jsx)(`strong`,{children:`The whole case`}),` in the chat. `,(0,b.jsx)(`strong`,{children:`See why`}),` lists what it got right.`]}),(0,b.jsx)(`li`,{children:`What information is missing and could affect the comparison.`}),(0,b.jsx)(`li`,{children:`A PDF of any car's case, from its drawer, except a car that was ruled out.`})]})}),(0,b.jsx)(q,{title:`What a result can't tell you`,children:(0,b.jsxs)(`ul`,{className:`list-disc space-y-1.5 pl-5`,children:[(0,b.jsx)(`li`,{children:`Whether a car is good in general. The score measures fit to your answers, not overall quality.`}),(0,b.jsx)(`li`,{children:`Information FINN doesn't publish, such as reliability, crash-test results, seat comfort, driving feel, or the actual car's condition and history.`}),(0,b.jsx)(`li`,{children:`Exact running costs. The monthly total is an estimate and excludes costs such as parking and tolls.`})]})})]}),(0,b.jsxs)(`div`,{className:`mt-4 rounded-xl bg-finn-pale-blue/70 p-4`,children:[(0,b.jsx)(`p`,{className:`text-[13px] font-bold text-finn-black`,children:`Before you subscribe`}),(0,b.jsxs)(`p`,{className:`mt-1 text-[13px] leading-relaxed text-finn-black/80`,children:[`Results depend on your answers, the scoring model, and the data available at evaluation time. Verify the price, contract term, delivery date, mileage package, and equipment on the individual FINN listing. Use `,(0,b.jsx)(`strong`,{children:`View on FINN`}),` in the car's drawer to check the original details.`]})]})]}),(0,b.jsxs)(x,{id:`guide-beta`,icon:(0,b.jsx)(ve,{className:`h-5 w-5`}),title:`Beta status and limitations`,children:[(0,b.jsxs)(G,{children:[(0,b.jsxs)(`p`,{children:[`This is beta version `,(0,b.jsx)(`strong`,{children:e}),`. Lens is still being evaluated, so it may contain bugs, missing information, or produce a result that looks wrong.`]}),(0,b.jsx)(`p`,{children:`The limitations below describe the current prototype. They aren't necessarily limitations a future version would have with access to better data.`})]}),(0,b.jsx)(`h3`,{className:`mt-6 text-[14.5px] font-black text-finn-black`,children:`Known limitations`}),(0,b.jsxs)(`div`,{className:`mt-3 grid items-start gap-3 sm:grid-cols-2`,children:[(0,b.jsxs)(Sn,{title:`Where it runs`,children:[(0,b.jsx)(W,{title:`Tested only on Chrome.`,children:`Firefox and other Chromium browsers, such as Edge or Brave, haven't been tested.`}),(0,b.jsx)(W,{title:`English only.`,children:`The beta supports only English, even though it runs on FINN's German site.`}),(0,b.jsx)(W,{title:`Dependent on FINN's pages and data.`,children:`If FINN changes its page structure or the data it exposes, Lens may stop reading listings until it is updated.`})]}),(0,b.jsxs)(Sn,{title:`How it judges`,children:[(0,b.jsx)(W,{title:`No AI in this beta.`,children:`Choices are interpreted by fixed rules, not a language model. The rules cover supported needs, costs, mileage, dates and requirements.`}),(0,b.jsx)(W,{title:`Some qualities can't be judged reliably.`,children:`The data may not establish boot capacity with the seats up, seat comfort, crash-test results, the actual car's condition, or every driver-assistance feature.`}),(0,b.jsx)(W,{title:`Provisional score bands.`,children:`The thresholds for Strong, Good, Partial and Limited matches haven't been finally calibrated.`}),(0,b.jsx)(W,{title:`Generalized wording.`,children:`Some explanations use Lens's own groupings, such as “city & parking”, rather than repeating your exact wording.`})]}),(0,b.jsxs)(Sn,{title:`Costs and dates`,children:[(0,b.jsx)(W,{title:`Estimated costs.`,children:`Fuel and electricity prices are Lens assumptions, not live prices, and running costs depend on the distance you give Lens (or its 1,000 km a month when you don't). Parking and tolls are excluded.`}),(0,b.jsx)(W,{title:`Plug-in hybrids.`,children:`FINN's data doesn't give their electricity consumption, so Lens uses EU registration data where it can. Some models are missing, and an incomplete cost can decide whether a car qualifies under a hard budget limit.`}),(0,b.jsx)(W,{title:`Rental dates and terms.`,children:`Many cars are offered only on a 12-month term. Fixed dates may leave few eligible cars, so Lens may offer the nearest available dates instead.`})]}),(0,b.jsxs)(Sn,{title:`Scale and storage`,children:[(0,b.jsx)(W,{title:`Large listings.`,children:`Lens evaluates matching cars up to its current limit of about 150 at a time. When a listing exceeds that, it says how many cars it evaluated out of how many matched.`}),(0,b.jsx)(W,{title:`Local storage.`,children:`Chats and settings stay in this browser. Lens keeps up to 40 recent chats and removes older ones. You can inspect and delete stored data in Settings; uninstalling the extension removes it.`})]})]}),(0,b.jsxs)(`div`,{className:`mt-4 rounded-xl border border-dashed border-finn-black/20 p-4`,children:[(0,b.jsx)(`h3`,{className:`text-[13.5px] font-black text-finn-black`,children:`Not yet tested`}),(0,b.jsx)(`p`,{className:`mt-1 text-[13px] leading-relaxed text-finn-black/80`,children:`These may work, but nobody has checked them yet.`}),(0,b.jsxs)(`ul`,{className:`mt-2 list-disc space-y-1.5 pl-5 text-[13px] leading-relaxed text-finn-black/85`,children:[(0,b.jsx)(`li`,{children:`Using Lens in two FINN tabs at the same time. Simultaneous changes to chats may overwrite one another.`}),(0,b.jsx)(`li`,{children:`Narrow windows and phone-sized screens, where the chat becomes a full-width sheet.`}),(0,b.jsx)(`li`,{children:`Keyboard-only use and screen readers.`}),(0,b.jsx)(`li`,{children:`FINN pages other than car listings and individual car pages.`})]})]})]}),(0,b.jsxs)(x,{id:`guide-next`,icon:(0,b.jsx)(De,{className:`h-5 w-5`}),title:`What might come next`,children:[(0,b.jsx)(`div`,{className:`mb-4 inline-flex rounded-full bg-finn-warning-lift px-3 py-1 text-[12px] font-bold text-finn-warning-ink`,children:`A possibility, not part of this beta`}),(0,b.jsxs)(G,{children:[(0,b.jsx)(`p`,{children:`Today, Lens asks a fixed set of questions and uses keyword rules to interpret typed answers. One possible next step is a more natural conversation, where you describe your circumstances in your own words and Lens asks follow-up questions when something is unclear.`}),(0,b.jsx)(`p`,{children:`A language model, possibly Google's Gemini, could translate that conversation into the structured answers Lens already uses: needs, priorities, requirements, and constraints.`}),(0,b.jsx)(`p`,{children:`The scoring engine would still evaluate cars using the available vehicle data. AI would help interpret what you mean, rather than independently decide which car is best.`}),(0,b.jsx)(`p`,{children:`No AI is used in this beta, and this direction may never be implemented.`})]})]}),(0,b.jsxs)(x,{id:`guide-built`,icon:(0,b.jsx)(ye,{className:`h-5 w-5`}),title:`How it was built`,children:[(0,b.jsx)(G,{children:(0,b.jsxs)(`p`,{children:[`Finn Lens is an independent project by `,(0,b.jsx)(`strong`,{children:`Orjwan Al-Rajaby`}),`. It isn't a FINN product, and it isn't for sale.`]})}),(0,b.jsxs)(`div`,{className:`mt-4 grid items-start gap-3 sm:grid-cols-2`,children:[(0,b.jsx)(q,{title:`Orjwan's work`,children:(0,b.jsxs)(`ul`,{className:`list-disc space-y-1.5 pl-5`,children:[(0,b.jsx)(`li`,{children:`The idea, and the problem it starts from.`}),(0,b.jsx)(`li`,{children:`Investigating finn.com: how its pages are rendered, on the server and in the browser, and how an extension can work alongside them.`}),(0,b.jsx)(`li`,{children:`Working out what each field in FINN's car data means, and what it doesn't say.`}),(0,b.jsx)(`li`,{children:`The product's direction, and its decision model: what Lens asks, what counts, what rules a car out, and how much each answer weighs.`}),(0,b.jsx)(`li`,{children:`The first versions: the extension's foundation and its reading of FINN's car data (August 2026).`})]})}),(0,b.jsx)(q,{title:`Built with Claude Code`,children:(0,b.jsx)(`p`,{children:`From September 2026, Orjwan directed the development with Claude Code, Anthropic's AI coding assistant, which wrote most of the code from then on: every commit in this version's history since then is marked as co-authored with it. Orjwan decided what to build and what to change, and tested it on finn.com.`})})]}),(0,b.jsxs)(G,{className:`mt-4`,children:[(0,b.jsx)(`p`,{children:`Lens went through several designs before this one: pinning cars to compare, a settings screen of priorities, and a chat answered by an AI model. The guided conversation in this beta is what that led to.`}),(0,b.jsxs)(`p`,{children:[`The code is a `,(0,b.jsx)(`strong`,{children:`beta codebase`}),`. It typechecks, has around 950 automated tests, and was audited for this release, but it grew with the product rather than to engineering standards set up front, and hasn't had the review a production product would.`]}),(0,b.jsx)(`p`,{children:`Lens isn't published on the Chrome Web Store. This beta is shared as a package to load into Chrome directly.`})]})]}),(0,b.jsxs)(x,{id:`guide-feedback`,icon:(0,b.jsx)(Se,{className:`h-5 w-5`}),title:`Feedback and bug reports`,children:[(0,b.jsxs)(G,{children:[(0,b.jsxs)(`p`,{children:[`Found a bug, an incorrect result, something confusing, or an idea for improvement? Send your report to`,` `,(0,b.jsx)(`strong`,{children:`the person who supplied you with this beta`}),`.`]}),(0,b.jsx)(`p`,{children:`You don't need to diagnose the problem. Describe what you were trying to do, what happened, and how someone else could reproduce it.`})]}),(0,b.jsxs)(`div`,{className:`mt-5`,children:[(0,b.jsx)(`h3`,{className:`text-[14.5px] font-black text-finn-black`,children:`What to put in a report`}),(0,b.jsx)(`p`,{className:`mt-1 text-[13.5px] leading-relaxed text-finn-black/80`,children:`Your chats are kept only on your computer, so whoever reads your report can't open them. Lens can only be checked by doing what you did, step by step. Include whatever you can, in this order:`}),(0,b.jsxs)(`ol`,{className:`mt-3 space-y-2`,children:[(0,b.jsxs)(Y,{n:1,title:`What kind of issue it is`,children:[(0,b.jsx)(`strong`,{children:`A bug`}),`: something broke, didn't respond, or behaved unexpectedly. Or `,(0,b.jsx)(`strong`,{children:`a faulty or incomplete result`}),`: a pick or score looks wrong, something is missing, or the explanation doesn't match the recommendation. Suggestions are welcome too.`]}),(0,b.jsx)(Y,{n:2,title:`Steps to reproduce it`,children:(0,b.jsxs)(`ul`,{className:`mt-1 list-disc space-y-1 pl-5`,children:[(0,b.jsx)(`li`,{children:`The full finn.com address you were on, including any filters you'd set.`}),(0,b.jsx)(`li`,{children:`Each answer you gave Lens, in order, whether you tapped it or typed it.`}),(0,b.jsxs)(`li`,{children:[`Anything you changed under `,(0,b.jsx)(`strong`,{children:`This doesn't look right`}),`: items taken out or added, how much something counts, answers changed.`]}),(0,b.jsx)(`li`,{children:`What you did after the result, such as opening a car's drawer or changing your answers.`})]})}),(0,b.jsx)(Y,{n:3,title:`What happened`,children:`What Lens showed or did, the car it concerns, and any error message.`}),(0,b.jsx)(Y,{n:4,title:`What you expected`,children:`What you thought should happen instead, and why.`}),(0,b.jsxs)(Y,{n:5,title:`Screenshots and the PDF`,children:[`Screenshots of the chat and the page. For a result, the PDF too: click the car's chip and choose `,(0,b.jsx)(`strong`,{children:`Save as PDF`}),` in its drawer.`]}),(0,b.jsxs)(Y,{n:6,title:`Anything else that might help`,children:[`Your browser and its version, and anything you noticed along the way. This is Lens `,e,`.`]})]})]}),(0,b.jsx)(`div`,{className:`mt-4 rounded-xl bg-finn-pale-blue/70 p-4`,children:(0,b.jsxs)(`div`,{className:`flex items-start gap-2`,children:[(0,b.jsx)(be,{"aria-hidden":`true`,className:`mt-0.5 h-4 w-4 shrink-0 text-finn-accent-blue`}),(0,b.jsxs)(`div`,{className:`text-[13px] leading-relaxed text-finn-black/85`,children:[(0,b.jsx)(`p`,{className:`font-bold`,children:`A useful report doesn't need to be technical.`}),(0,b.jsx)(`p`,{className:`mt-1`,children:`For example: "I selected these answers, changed this priority, and expected this car to win, but Lens picked another one. Here's why I expected a different result."`}),(0,b.jsx)(`p`,{className:`mt-2`,children:`A surprising result is useful even if it isn't a bug. It may reveal a scoring issue, missing data, or a trade-off Lens should explain more clearly.`})]})]})})]})]})}function Sn({title:e,children:t}){return(0,b.jsxs)(`div`,{className:`rounded-xl border border-finn-cotton bg-white p-4`,children:[(0,b.jsx)(`p`,{className:`text-[11px] font-black uppercase tracking-wide text-finn-accent-blue`,children:e}),(0,b.jsx)(`ul`,{className:`mt-2 space-y-2.5`,children:t})]})}function W({title:e,children:t}){return(0,b.jsxs)(`li`,{className:`text-[13px] leading-relaxed text-finn-black/85`,children:[(0,b.jsx)(`strong`,{className:`text-finn-black`,children:e}),` `,t]})}function Cn({children:e}){return(0,b.jsx)(`span`,{className:`rounded-full border border-finn-cotton bg-white px-2.5 py-1 text-[11px] font-semibold text-finn-black/70`,children:e})}function G({children:e,className:t=``}){return(0,b.jsx)(`div`,{className:`space-y-3 text-[14px] leading-relaxed text-finn-black/85 ${t}`,children:e})}function wn({children:e}){return(0,b.jsx)(`div`,{className:`mt-4 rounded-r-xl border-l-[3px] border-finn-accent-blue bg-finn-pale-blue/60 px-4 py-3 text-[13px] leading-relaxed text-finn-black/85`,children:e})}function K({n:e,title:t,children:n}){return(0,b.jsxs)(`div`,{className:`flex gap-3`,children:[(0,b.jsx)(`span`,{"aria-hidden":`true`,className:`flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-finn-highlight-navy text-[13px] font-black text-white`,children:e}),(0,b.jsxs)(`div`,{className:`min-w-0 flex-1`,children:[(0,b.jsx)(`h3`,{className:`text-[14.5px] font-black leading-snug text-finn-black`,children:t}),(0,b.jsx)(`div`,{className:`mt-1 text-[13.5px] leading-relaxed text-finn-black/85`,children:n})]})]})}function q({title:e,children:t}){return(0,b.jsxs)(`div`,{className:`rounded-xl border border-finn-cotton bg-white p-4 text-[13.5px] leading-relaxed text-finn-black/85`,children:[(0,b.jsx)(`p`,{className:`mb-2 text-[13.5px] font-black text-finn-black`,children:e}),t]})}function J({chip:e,children:t}){return(0,b.jsxs)(`div`,{className:`grid gap-2 px-4 py-3 sm:grid-cols-[minmax(0,220px)_1fr] sm:gap-4`,children:[(0,b.jsx)(`dt`,{className:`flex items-start`,children:e}),(0,b.jsx)(`dd`,{className:`text-[13.5px] leading-relaxed text-finn-black/85`,children:t})]})}function Tn({title:e,children:t}){return(0,b.jsxs)(`details`,{className:`group rounded-xl border border-finn-cotton bg-white`,children:[(0,b.jsxs)(`summary`,{className:`flex cursor-pointer list-none items-center justify-between gap-3 rounded-xl px-4 py-3 text-[13px] font-bold text-finn-black transition-colors hover:bg-finn-pale-blue focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-finn-accent-blue [&::-webkit-details-marker]:hidden`,children:[(0,b.jsx)(`span`,{children:e}),(0,b.jsx)(_,{"aria-hidden":`true`,className:`h-4 w-4 shrink-0 text-finn-black/55 transition-transform group-open:rotate-180`})]}),(0,b.jsx)(`div`,{className:`border-t border-finn-cotton px-4 py-3 text-[13px] leading-relaxed text-finn-black/85`,children:t})]})}function En({label:e,description:t}){return(0,b.jsxs)(`div`,{className:`flex flex-col gap-3 rounded-lg bg-finn-snow p-3`,children:[(0,b.jsx)(`span`,{className:`mt-0.5 shrink-0 rounded-md bg-white px-2 py-1 text-[10px] font-black uppercase tracking-wide text-finn-black/70`,children:e}),(0,b.jsx)(`p`,{className:`pl-2 text-[12.5px] leading-relaxed text-finn-black/75`,children:t})]})}function Y({n:e,title:t,children:n}){return(0,b.jsxs)(`li`,{className:`flex gap-3 rounded-xl border border-finn-cotton bg-white p-3.5`,children:[(0,b.jsx)(`span`,{"aria-hidden":`true`,className:`flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-finn-pale-blue text-[12px] font-black text-finn-accent-blue`,children:e}),(0,b.jsxs)(`div`,{className:`min-w-0 flex-1`,children:[(0,b.jsx)(`p`,{className:`text-[13.5px] font-black text-finn-black`,children:t}),(0,b.jsx)(`div`,{className:`mt-0.5 text-[13px] leading-relaxed text-finn-black/85`,children:n})]})]})}var Dn=`/assets/01-meet-lens-DfQWvgNz.webp`,On=`/assets/02-who-rides-with-you-DarkDGq2.webp`,kn=`/assets/03-where-and-how-you-drive-CVFSameY.webp`,An=`/assets/04-what-the-car-copes-with-CNTmiN57.webp`,jn=`/assets/05-recommended-comforts-IBXPZQeu.webp`,Mn=`/assets/06-what-else-matters-oBkOz2y2.webp`,Nn=`/assets/07-deal-breakers-and-sealers-BFoInbXR.webp`,Pn=`/assets/08-all-wheel-drive-tip-6Ktdw1zt.webp`,Fn=`/assets/09-summary-of-answers-BK2eUv2e.webp`,In=`/assets/10-confirm-the-summary-DMw8S9ZB.webp`,Ln=`/assets/11-adjust-panel-CqziBWqu.webp`,Rn=`/assets/12-save-settings-nvAM51If.webp`,zn=`/assets/13-result-chips-C5oBpvV5.webp`,Bn=`/assets/14-result-drawer-8gG41lY0.webp`;function Vn(e){return`https://github.com/orjwan-alrajaby/finn-lens/raw/main/releases/finn-lens-${e}-chrome.zip`}var Hn=`#docs/beta/install-it-chrome-on-a-computer-about-two-minutes`,Un=[{id:`demo-meet-lens`,number:`01`,label:`Meet Lens`},{id:`demo-tell-lens`,number:`02`,label:`Tell Lens about your life`},{id:`demo-review-understanding`,number:`03`,label:`Review and refine Lens's understanding`},{id:`demo-explore-results`,number:`04`,label:`Explore your results`},{id:`demo-try-it`,number:`05`,label:`Try it yourself`}],Wn=[{items:Un}],Gn=Un.map(e=>e.id),X=[{src:Dn,alt:`Finn Lens introduction`},{src:On,alt:`Passenger and child-seat questions`},{src:kn,alt:`Driving habits and parking questions`},{src:An,alt:`Weather and carrying requirements`},{src:jn,alt:`Comfort preferences and recommended features`},{src:Mn,alt:`Additional preferences and natural-language summary`},{src:Nn,alt:`Colour-coded choices and explanations`},{src:Pn,alt:`All-wheel-drive explanation`},{src:Fn,alt:`Summary of answers and priorities`},{src:In,alt:`Prompt to confirm the summary`},{src:Ln,alt:`Editable summary and adjustment panel`},{src:Rn,alt:`Save settings prompt`},{src:zn,alt:`Finn Lens results and fit indicators`},{src:Bn,alt:`Detailed breakdown of a car's evaluation`}],Kn=(0,v.createContext)(()=>{});function qn({release:e}){let t=ln(Gn);un();let[n,r]=(0,v.useState)(null);return(0,b.jsxs)(Kn.Provider,{value:e=>r(X.findIndex(t=>t.src===e)),children:[(0,b.jsxs)(`div`,{className:`relative space-y-4`,children:[(0,b.jsx)(`aside`,{className:`absolute top-0 right-full mr-10 hidden h-full w-52 xl:block`,children:(0,b.jsx)(`div`,{className:`sticky top-8`,children:(0,b.jsx)(H,{groups:Wn,active:t,variant:`rail`})})}),(0,b.jsx)(pn,{icon:(0,b.jsx)(Ce,{}),eyebrow:`Product demo`,title:`Product walkthrough`,children:(0,b.jsx)(`p`,{children:`This walkthrough follows the user's journey through Finn Lens, from figuring out what matters to them to understanding how the available cars compare. Click any screenshot to see it full size.`})}),(0,b.jsx)(`div`,{className:`xl:hidden`,children:(0,b.jsx)(H,{groups:Wn,active:t,variant:`inline`})}),(0,b.jsx)(`section`,{id:`demo-meet-lens`,className:`scroll-mt-6`,children:(0,b.jsxs)(Z,{number:`1`,title:`Meet Lens`,icon:(0,b.jsx)(Se,{}),children:[(0,b.jsx)(`p`,{children:`When you first install Finn Lens, it opens the listings page on finn.com and introduces itself through the chat.`}),(0,b.jsx)($,{src:Dn,alt:`Finn Lens introduction`}),(0,b.jsx)(`p`,{children:`Lens explains what it does, how the conversation works, and what to expect from the results. You can answer by selecting options or, where a question allows it, entering a value of your own.`}),(0,b.jsx)(`p`,{children:`The idea is straightforward: before judging the cars, Lens wants to understand the person choosing them.`})]})}),(0,b.jsx)(`section`,{id:`demo-tell-lens`,className:`scroll-mt-6`,children:(0,b.jsxs)(Z,{number:`2`,title:`Tell Lens about your life`,icon:(0,b.jsx)(Oe,{}),children:[(0,b.jsx)(`p`,{children:`The conversation consists of questions and follow-up questions. Your answers help Lens build a picture of your circumstances, identify relevant vehicle features, and determine which preferences matter most.`}),(0,b.jsxs)(Q,{title:`2.1. Who rides with you?`,children:[(0,b.jsx)($,{src:On,alt:`Passenger and child-seat questions`}),(0,b.jsx)(`p`,{children:`Lens starts by asking who regularly travels with you. Children in child seats, older passengers, teenagers, and dogs can have different implications for what makes a car suitable.`}),(0,b.jsx)(`p`,{children:`Some answers lead to follow-up questions. For example, selecting children prompts you to specify the kind of child seat you need.`}),(0,b.jsx)(`p`,{children:`Lens also explains what it will check and why. In this example, it identifies rear doors as relevant and checks for ISOFIX child-seat anchors.`}),(0,b.jsx)(`p`,{children:`The information icon provides additional context, so users can understand what an answer means to Lens rather than simply selecting an option and hoping for the best.`})]}),(0,b.jsxs)(Q,{title:`2.2. Where and how do you drive?`,children:[(0,b.jsx)($,{src:kn,alt:`Driving habits and parking questions`}),(0,b.jsx)(`p`,{children:`Next, Lens asks about your driving habits and the environments you regularly encounter.`}),(0,b.jsx)(`p`,{children:`City driving, traffic, long-distance journeys, and parking situations can all affect which features are useful to you.`}),(0,b.jsx)(`p`,{children:`Some answers lead to more specific questions. Selecting city driving, for example, lets you describe where you usually park.`}),(0,b.jsx)(`p`,{children:`Lens then connects those answers to relevant vehicle features. In the open-car-park example, it explains that reversing out of a parking space into traffic is a situation where rear cross-traffic alert may be useful.`}),(0,b.jsx)(`p`,{children:`The purpose isn't to recommend every available driver-assistance feature. It's to identify the ones that make sense for your circumstances.`})]}),(0,b.jsxs)(Q,{title:`2.3. What does the car need to cope with?`,children:[(0,b.jsx)($,{src:An,alt:`Weather and carrying requirements`}),(0,b.jsx)(`p`,{children:`Lens also asks about the conditions the car needs to handle and what you regularly carry.`}),(0,b.jsx)(`p`,{children:`For example, someone dealing with cold winters, snow and ice may benefit from different equipment than someone primarily driving in hot weather. Similarly, carrying shopping is different from regularly transporting bulky items, bikes, or other equipment.`}),(0,b.jsx)(`p`,{children:`Follow-up questions help Lens narrow down the relevant requirements.`}),(0,b.jsx)(`p`,{children:`If you select hot summers, for instance, Lens explains that it will check for ventilated seats, consider three-zone climate control, and check for air conditioning.`}),(0,b.jsx)(`p`,{children:`These explanations make the connection between your answers and the vehicle features Lens evaluates more explicit.`})]}),(0,b.jsxs)(Q,{title:`2.4. Build on earlier answers`,children:[(0,b.jsx)($,{src:jn,alt:`Comfort preferences and recommended features`}),(0,b.jsx)(`p`,{children:`As the conversation progresses, Lens can recommend additional options based on what you've already told it.`}),(0,b.jsx)(`p`,{children:`In this example, I indicated that I experience cold winters with snow and ice and spend considerable time driving. When I reached the comfort preferences, Lens recommended a heated steering wheel.`}),(0,b.jsx)(`p`,{children:`The tooltip explains why:`}),(0,b.jsx)(`blockquote`,{className:`rounded-r-xl border-l-[3px] border-[#0072ea] bg-[#edf5ff] px-4 py-3 text-[13.5px] leading-relaxed text-[#17243b]/85`,children:`Recommended because you said winters bring snow and ice, winters are cold, and you spend a lot of time on the road.`}),(0,b.jsx)(`p`,{children:`This is an important distinction. Lens isn't merely presenting a static list of features for the user to select. It uses earlier answers to suggest features that may be relevant to the user's circumstances.`}),(0,b.jsx)(`p`,{children:`The user remains in control, though. A recommendation is a suggestion, not an obligation to include that feature in their priorities.`})]}),(0,b.jsxs)(Q,{title:`2.5. Tell Lens what else matters to you`,children:[(0,b.jsx)($,{src:Mn,alt:`Additional preferences and natural-language summary`}),(0,b.jsx)(`p`,{children:`Beyond practical requirements, Lens asks about other preferences, including comfort and environmental considerations.`}),(0,b.jsx)(`p`,{children:`You can choose specific comfort features and say how green the car should be. Lens also asks about your budget and how long you need the car.`}),(0,b.jsx)(`p`,{children:`It then recounts your answers in natural language.`}),(0,b.jsx)(`p`,{children:`For example, the conversation might look like this:`}),(0,b.jsxs)(`div`,{className:`space-y-3 rounded-xl border border-[#e8e5df] bg-[#faf9f6] p-4 text-[13.5px] leading-relaxed text-[#17243b]/85`,children:[(0,b.jsxs)(`p`,{children:[(0,b.jsx)(`strong`,{children:`You:`}),` Comfort matters to me — ventilated seats, lumbar support and premium sound. I care about the environment — clean for its fuel type.`]}),(0,b.jsxs)(`p`,{children:[(0,b.jsx)(`strong`,{children:`Lens:`}),` Got it — comfort matters to you and you care about the environment.`]})]}),(0,b.jsx)(`p`,{children:`Budget and rental duration are handled separately from these preferences. In this example, Lens interprets a monthly budget of €700 as a constraint and works out the rental term needed to cover the requested period.`}),(0,b.jsx)(`p`,{children:`This distinction matters: a preference helps Lens compare suitable cars, while a hard constraint can rule out a car that doesn't meet the requirement.`})]}),(0,b.jsxs)(Q,{title:`2.6. Understand the choices Lens recommends`,children:[(0,b.jsx)($,{src:Nn,alt:`Colour-coded choices and explanations`}),(0,b.jsx)(`p`,{children:`Lens uses visual indicators to distinguish different kinds of choices, and the information tooltips explain what individual options mean and why they may be relevant.`}),(0,b.jsx)(`p`,{children:`For example, if you've indicated that you regularly encounter snow and ice, Lens may recommend considering all-wheel drive (AWD).`}),(0,b.jsx)($,{src:Pn,alt:`All-wheel-drive explanation`}),(0,b.jsx)(`p`,{children:`The tooltip explains the trade-off: AWD can improve traction when accelerating on snow, but it doesn't improve braking on snow or replace appropriate winter tyres.`}),(0,b.jsx)(`p`,{children:`The source link provides supporting information for the claim, allowing users to inspect the reasoning rather than having to take Lens's word for it.`}),(0,b.jsx)(`p`,{children:`The point isn't that every recommendation will be right for every person. It's that the recommendation should come with enough context for the user to decide whether it makes sense.`})]})]})}),(0,b.jsx)(`section`,{id:`demo-review-understanding`,className:`scroll-mt-6`,children:(0,b.jsxs)(Z,{number:`3`,title:`Review and refine Lens's understanding`,icon:(0,b.jsx)(me,{}),children:[(0,b.jsx)(`p`,{children:`Before evaluating the cars, Lens summarizes what it has learned from the conversation.`}),(0,b.jsxs)(Q,{title:`3.1. See how your answers are interpreted`,children:[(0,b.jsx)($,{src:Fn,alt:`Summary of answers and priorities`}),(0,b.jsx)(`p`,{children:`The summary brings together your answers, the requirements Lens derived from them, and the relative importance assigned to your preferences.`}),(0,b.jsx)(`p`,{children:`The priority levels work as follows:`}),(0,b.jsxs)(`ul`,{className:`list-disc space-y-2 pl-5`,children:[(0,b.jsxs)(`li`,{children:[(0,b.jsx)(`strong`,{children:`Top priority (4):`}),` Counts twice as much as Important. A car can still win without meeting a top priority, but it needs to compensate by performing better elsewhere.`]}),(0,b.jsxs)(`li`,{children:[(0,b.jsx)(`strong`,{children:`Important (2):`}),` Receives the standard priority weight and contributes fully to the comparison.`]}),(0,b.jsxs)(`li`,{children:[(0,b.jsx)(`strong`,{children:`Nice to have (1):`}),` Counts half as much as Important and can help distinguish between otherwise similar cars.`]})]}),(0,b.jsx)(`p`,{children:`A dashed outline on how much something counts marks Lens's own guess from your answers, rather than a level you picked yourself.`}),(0,b.jsx)(`p`,{children:`This distinction helps you identify where Lens is interpreting your needs instead of simply recording your choices.`})]}),(0,b.jsxs)(Q,{title:`3.2. Confirm or correct the summary`,children:[(0,b.jsx)($,{src:In,alt:`Prompt to confirm the summary`}),(0,b.jsx)(`p`,{children:`Once the summary is ready, Lens asks whether its understanding looks right or needs adjustment.`}),(0,b.jsx)(`p`,{children:`If something is wrong, you can select the option indicating that the summary doesn't look right.`}),(0,b.jsx)($,{src:Ln,alt:`Editable summary and adjustment panel`}),(0,b.jsx)(`p`,{children:`The adjustment panel presents the same underlying information in an editable form. You can review the questions and answers, the requirements Lens derived from them, and how it interpreted their importance.`}),(0,b.jsx)(`p`,{children:`You can then adjust the selections until the summary better reflects what you actually meant.`}),(0,b.jsx)(`p`,{children:`This is deliberate: Lens should give users an opportunity to correct its interpretation before using that interpretation to evaluate cars.`})]}),(0,b.jsxs)(Q,{title:`3.3. Decide whether to save your settings`,children:[(0,b.jsx)($,{src:Rn,alt:`Save settings prompt`}),(0,b.jsx)(`p`,{children:`Once you've confirmed your answers, Lens asks whether you'd like to save them as your settings or use them only for the current conversation.`}),(0,b.jsx)(`p`,{children:`Saved settings provide a starting point for future chats, so you don't have to repeat the entire process each time. You can still change your answers in a future conversation, and you can review or forget your saved settings through Settings.`}),(0,b.jsx)(`p`,{children:`Choosing to use the answers only for the current chat lets you proceed without saving them as your default preferences.`})]})]})}),(0,b.jsx)(`section`,{id:`demo-explore-results`,className:`scroll-mt-6`,children:(0,b.jsxs)(Z,{number:`4`,title:`Explore your results`,icon:(0,b.jsx)(fe,{}),children:[(0,b.jsx)(`p`,{children:`Once the requirements have been confirmed, Lens evaluates the cars on the listings page and displays the results.`}),(0,b.jsxs)(Q,{title:`4.1. See how each car fits`,children:[(0,b.jsx)($,{src:zn,alt:`Finn Lens results and fit indicators`}),(0,b.jsx)(`p`,{children:`Lens attaches a clickable result chip to each car it evaluates. The chips distinguish the top pick from cars that may still be suitable and cars that have been ruled out.`}),(0,b.jsx)(`p`,{children:`The chips aren't just labels. Clicking one opens a drawer with a breakdown of that car's evaluation, whether it won or not.`}),(0,b.jsx)(`p`,{children:`This means you can inspect the runner-up, understand why a car lost against the winner, or find out why another car was ruled out entirely.`}),(0,b.jsx)(`p`,{children:`The goal isn't simply to identify one winner and leave you to guess what happened to the other options. Every evaluated car has a reason for its result, and Lens gives you a way to explore it.`})]}),(0,b.jsxs)(Q,{title:`4.2. Inspect the reasoning behind a result`,children:[(0,b.jsx)($,{src:Bn,alt:`Detailed breakdown of a car's evaluation`}),(0,b.jsx)(`p`,{children:`Clicking a car's result chip opens its evaluation drawer, where you can inspect the reasoning behind its outcome.`}),(0,b.jsx)(`p`,{children:`For the top pick, the breakdown helps explain why it came out ahead. For another suitable car, it can show where it fell short compared with the winner. For a car that was ruled out, it explains why it didn't qualify.`}),(0,b.jsx)(`p`,{children:`This lets you compare the reasoning across different cars instead of treating the top pick as an answer you have to accept on faith.`}),(0,b.jsx)(`p`,{children:`A top pick is ultimately the result of applying Lens's predefined scoring model to your stated needs and priorities. It isn't a guarantee that the car is the right choice for everyone.`})]})]})}),(0,b.jsx)(`section`,{id:`demo-try-it`,className:`scroll-mt-6`,children:(0,b.jsxs)(Z,{number:`5`,title:`Try it yourself`,icon:(0,b.jsx)(ie,{}),children:[(0,b.jsx)(`p`,{children:`Finn Lens isn't on the Chrome Web Store. This beta is shared as a package you load into Chrome yourself, on a computer — it takes about two minutes.`}),(0,b.jsxs)(`a`,{href:Vn(e),className:`inline-flex items-center gap-2 rounded-full bg-[#003087] px-5 py-2.5 text-[13.5px] font-black text-white transition-colors hover:bg-[#0072ea] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0072ea]`,children:[(0,b.jsx)(ie,{"aria-hidden":`true`,className:`h-4 w-4`}),`Download the `,e,` beta (.zip)`]}),(0,b.jsxs)(`ol`,{className:`list-decimal space-y-2 pl-5 marker:font-black marker:text-[#003087]`,children:[(0,b.jsxs)(`li`,{children:[`Unzip it. You get a folder holding `,(0,b.jsx)(`code`,{className:`font-mono text-[12.5px]`,children:`manifest.json`}),`.`]}),(0,b.jsxs)(`li`,{children:[`Open `,(0,b.jsx)(`code`,{className:`font-mono text-[12.5px]`,children:`chrome://extensions`}),` and switch on `,(0,b.jsx)(`strong`,{children:`Developer mode`}),` (top right).`]}),(0,b.jsxs)(`li`,{children:[`Click `,(0,b.jsx)(`strong`,{children:`Load unpacked`}),` and choose that folder. Keep the folder where it is: Chrome loads Lens from it each time.`]}),(0,b.jsxs)(`li`,{children:[`Lens opens finn.com in a new tab, and its chat opens by itself. If it doesn't, click the `,(0,b.jsx)(`strong`,{children:`Lens`}),` bubble in the bottom-right corner.`]})]}),(0,b.jsxs)(`p`,{children:[`It runs only on www.finn.com, and tabs that were already open need a reload. Chrome may warn about extensions in developer mode; that's expected for a build that isn't from the store. The same steps, with more on this beta, are in`,` `,(0,b.jsx)(`a`,{href:Hn,className:`font-bold text-[#0072ea] underline`,children:`the beta note`}),`.`]})]})}),(0,b.jsx)(`section`,{className:`rounded-2xl border border-[#e8e5df] bg-white p-5 sm:p-6`,children:(0,b.jsxs)(`div`,{className:`flex items-start gap-3`,children:[(0,b.jsx)(`div`,{className:`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#fff4d8]`,children:(0,b.jsx)(de,{"aria-hidden":`true`,className:`h-4 w-4 text-[#855b00]`})}),(0,b.jsxs)(`div`,{className:`min-w-0 flex-1`,children:[(0,b.jsx)(`h2`,{className:`text-base font-black text-[#17243b]`,children:`A note on the current beta`}),(0,b.jsxs)(`div`,{className:`mt-3 space-y-3 text-[13.5px] leading-relaxed text-[#17243b]/80`,children:[(0,b.jsx)(`p`,{children:`Finn Lens currently uses a predefined scoring system to evaluate cars against the user's requirements and priorities. The conversational interface helps gather and interpret those requirements, but natural-language AI integration is a potential future enhancement, not part of the current beta.`}),(0,b.jsx)(`p`,{children:`The quality of the results depends on the vehicle data available, the assumptions built into the scoring model, and the accuracy of the user's answers. The results should therefore be treated as decision support, not definitive advice.`}),(0,b.jsx)(`p`,{children:`Finn Lens is an independent project and is not an official FINN product.`})]})]})]})})]}),n==null?null:(0,b.jsx)(Zn,{index:n,onIndex:r,onClose:()=>r(null)})]})}function Z({number:e,title:t,icon:n,children:r}){return(0,b.jsxs)(`article`,{className:`overflow-hidden rounded-2xl border border-[#e8e5df] bg-white`,children:[(0,b.jsxs)(`header`,{className:`flex items-center gap-3 border-b border-[#e8e5df] bg-[#fbfcfe] px-5 py-4 sm:px-6`,children:[(0,b.jsx)(`span`,{className:`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#003087] text-sm font-black text-white`,children:e}),(0,b.jsx)(`div`,{className:`min-w-0 flex-1`,children:(0,b.jsx)(`h2`,{className:`text-base font-black text-[#17243b] sm:text-lg`,children:t})}),(0,b.jsx)(`span`,{className:`mt-1 shrink-0 text-[#0072ea] [&>svg]:h-5 [&>svg]:w-5`,children:n})]}),(0,b.jsx)(`div`,{className:`space-y-4 px-5 py-5 text-[13.5px] leading-relaxed text-[#17243b]/85 sm:px-6 sm:py-6`,children:r})]})}function Q({title:e,children:t}){return(0,b.jsxs)(`section`,{className:`mt-6 border-l-2 border-[#d7e8ff] pl-4 sm:pl-5`,children:[(0,b.jsx)(`h3`,{className:`mb-3 text-sm font-black leading-snug text-[#17243b] sm:text-[15px]`,children:e}),(0,b.jsx)(`div`,{className:`space-y-3`,children:t})]})}function $({src:e,alt:t}){let n=(0,v.useContext)(Kn);return(0,b.jsxs)(`figure`,{className:`my-6`,children:[(0,b.jsxs)(`button`,{type:`button`,onClick:()=>n(e),"aria-label":`Enlarge: ${t}`,className:`group relative block w-full cursor-zoom-in overflow-hidden rounded-lg border border-slate-200 transition-shadow hover:shadow-md focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0072ea]`,children:[(0,b.jsx)(`img`,{src:e,alt:t,className:`block h-auto w-full`,loading:`lazy`}),(0,b.jsxs)(`span`,{className:`absolute right-3 bottom-3 inline-flex items-center gap-1.5 rounded-full bg-[#17243b]/80 px-3 py-1.5 text-[12px] font-bold text-white opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100`,children:[(0,b.jsx)(oe,{"aria-hidden":`true`,className:`h-3.5 w-3.5`}),`Enlarge`]})]}),(0,b.jsxs)(`figcaption`,{className:`mt-2 flex items-center justify-between gap-3 text-[13px] text-[#17243b]/75`,children:[(0,b.jsx)(`span`,{children:t}),(0,b.jsxs)(`span`,{className:`inline-flex shrink-0 items-center gap-1.5 text-[12.5px]`,children:[(0,b.jsx)(Ae,{className:`h-3.5 w-3.5`,"aria-hidden":`true`}),`Click to enlarge`]})]})]})}var Jn=1,Yn=4,Xn=e=>Math.min(Yn,Math.max(Jn,e));function Zn({index:e,onIndex:t,onClose:n}){let r=X[e],[i,a]=(0,v.useState)(1),[o,s]=(0,v.useState)({x:0,y:0}),c=(0,v.useRef)(null),l=(0,v.useRef)(null),u=(0,v.useRef)(new Map),d=(0,v.useRef)(null),f=e>0,p=e<X.length-1,m=n=>{let r=e+n;r>=0&&r<X.length&&t(r)};(0,v.useEffect)(()=>{a(1),s({x:0,y:0})},[e]),(0,v.useEffect)(()=>{let e=document.activeElement,t=document.body.style.overflow;return document.body.style.overflow=`hidden`,l.current?.focus(),()=>{document.body.style.overflow=t,e?.focus()}},[]);let h=(e,t=0,n=0)=>{let r=Xn(e);s(e=>r===1?{x:0,y:0}:{x:t-(t-e.x)*r/i,y:n-(n-e.y)*r/i}),a(r)};(0,v.useEffect)(()=>{let e=e=>{if(e.key===`Escape`)n();else if(e.key===`ArrowLeft`)m(-1);else if(e.key===`ArrowRight`)m(1);else if(e.key===`+`||e.key===`=`)h(i*1.5);else if(e.key===`-`)h(i/1.5);else if(e.key===`0`)h(1);else return;e.preventDefault()};return window.addEventListener(`keydown`,e),()=>window.removeEventListener(`keydown`,e)});let g=(e,t)=>{let n=c.current.getBoundingClientRect();return{x:e-n.left-n.width/2,y:t-n.top-n.height/2}},te=()=>{let[e,t]=[...u.current.values()];return e&&t?Math.hypot(e.x-t.x,e.y-t.y):0};return(0,b.jsxs)(`div`,{role:`dialog`,"aria-modal":`true`,"aria-label":r.alt,className:`fixed inset-0 z-50 flex flex-col bg-[#0b1220] text-white`,children:[(0,b.jsxs)(`div`,{className:`relative z-10 flex items-center gap-3 bg-[#0b1220] px-4 py-3 sm:px-6`,children:[(0,b.jsxs)(`p`,{className:`min-w-0 flex-1 truncate text-[14px] font-bold`,children:[r.alt,(0,b.jsxs)(`span`,{className:`ml-2 font-normal text-white/70`,children:[e+1,` / `,X.length]})]}),(0,b.jsx)(Qn,{label:`Zoom out`,onClick:()=>h(i/1.5),disabled:i<=Jn,children:(0,b.jsx)(ke,{className:`h-5 w-5`})}),(0,b.jsxs)(`span`,{className:`w-12 text-center font-mono text-[13px] tabular-nums text-white/80`,children:[Math.round(i*100),`%`]}),(0,b.jsx)(Qn,{label:`Zoom in`,onClick:()=>h(i*1.5),disabled:i>=Yn,children:(0,b.jsx)(Ae,{className:`h-5 w-5`})}),(0,b.jsx)(Qn,{label:`Back to full view`,onClick:()=>h(1),disabled:i===1,children:(0,b.jsx)(we,{className:`h-5 w-5`})}),(0,b.jsx)(`button`,{ref:l,type:`button`,onClick:n,"aria-label":`Close`,className:`ml-1 inline-flex h-10 w-10 items-center justify-center rounded-full bg-white/10 hover:bg-white/20 focus-visible:outline-2 focus-visible:outline-white`,children:(0,b.jsx)(ee,{className:`h-5 w-5`})})]}),(0,b.jsxs)(`div`,{ref:c,className:`relative min-h-0 flex-1 touch-none overflow-hidden select-none ${i>1?`cursor-grab active:cursor-grabbing`:`cursor-zoom-in`}`,onWheel:e=>{let t=g(e.clientX,e.clientY);h(i*(e.deltaY<0?1.2:1/1.2),t.x,t.y)},onDoubleClick:e=>{let t=g(e.clientX,e.clientY);h(i>1?1:2.5,t.x,t.y)},onPointerDown:e=>{e.currentTarget.setPointerCapture(e.pointerId),u.current.set(e.pointerId,{x:e.clientX,y:e.clientY}),d.current={startX:e.clientX,startY:e.clientY,offset:o,zoom:i,distance:te()}},onPointerMove:e=>{if(!u.current.has(e.pointerId)||!d.current)return;u.current.set(e.pointerId,{x:e.clientX,y:e.clientY});let t=d.current;u.current.size===2&&t.distance>0?a(Xn(t.zoom*te()/t.distance)):i>1&&s({x:t.offset.x+e.clientX-t.startX,y:t.offset.y+e.clientY-t.startY})},onPointerUp:e=>{let t=d.current;if(u.current.delete(e.pointerId),t&&i===1&&u.current.size===0){let n=e.clientX-t.startX;Math.abs(n)>60&&Math.abs(n)>Math.abs(e.clientY-t.startY)&&m(n<0?1:-1)}d.current=u.current.size?{...t,startX:e.clientX,startY:e.clientY,offset:o,zoom:i,distance:te()}:null},onPointerCancel:e=>{u.current.delete(e.pointerId),d.current=null},children:[(0,b.jsx)(`img`,{src:r.src,alt:r.alt,draggable:!1,className:`absolute inset-0 m-auto max-h-full max-w-full object-contain p-2 sm:p-6`,style:{transform:`translate(${o.x}px, ${o.y}px) scale(${i})`,transition:d.current?`none`:`transform 120ms ease-out`}}),(0,b.jsx)($n,{side:`left`,label:`Previous screenshot`,onClick:()=>m(-1),disabled:!f}),(0,b.jsx)($n,{side:`right`,label:`Next screenshot`,onClick:()=>m(1),disabled:!p})]}),(0,b.jsx)(`p`,{className:`relative z-10 bg-[#0b1220] px-4 py-2.5 text-center text-[12.5px] text-white/75 sm:px-6`,children:`Scroll or double-click to zoom · drag to move around · ← → for the others · Esc to close`})]})}function Qn({label:e,onClick:t,disabled:n,children:r}){return(0,b.jsx)(`button`,{type:`button`,onClick:t,disabled:n,"aria-label":e,title:e,className:`inline-flex h-10 w-10 items-center justify-center rounded-full bg-white/10 hover:bg-white/20 focus-visible:outline-2 focus-visible:outline-white disabled:opacity-35 disabled:hover:bg-white/10`,children:r})}function $n({side:e,label:t,onClick:n,disabled:r}){return r?null:(0,b.jsx)(`button`,{type:`button`,onClick:n,onPointerDown:e=>e.stopPropagation(),"aria-label":t,className:`absolute top-1/2 ${e===`left`?`left-3 sm:left-5`:`right-3 sm:right-5`} inline-flex h-12 w-12 -translate-y-1/2 items-center justify-center rounded-full bg-[#17243b]/85 text-white shadow-lg ring-1 ring-white/30 hover:bg-[#003087] focus-visible:outline-2 focus-visible:outline-white`,children:e===`left`?(0,b.jsx)(pe,{className:`h-7 w-7`}):(0,b.jsx)(l,{className:`h-7 w-7`})})}var er={settings:{title:`Finn Lens settings`,description:`Your saved answers, and everything Lens keeps in this browser.`},guide:{title:`Finn Lens beta guide`,description:`What Lens does, how it decides, and what this beta can't do yet.`},demo:{title:`Finn Lens product demo`,description:`A walkthrough of a reader's journey through Finn Lens.`},docs:{title:`Finn Lens documentation`,description:`How it's built, how it decides, and what changed — as the repository documents it.`}},tr=e=>e.startsWith(`#guide`)?`guide`:e.startsWith(`#demo`)?`demo`:e.startsWith(`#docs`)?`docs`:`settings`,nr=e=>[`#guide`,`#settings`,`#demo`].includes(e),rr=(e,t)=>`${e} ${e===1?t:`${t}s`}`,ir=e=>new Date(e).toLocaleDateString(`en-GB`,{day:`numeric`,month:`long`,year:`numeric`});function ar(e,t){if(!t)return null;switch(e){case`chats`:return[rr(t.chats,`chat`),t.judged?`${t.judged} judged`:null].filter(Boolean).join(`, `);case`cars`:return rr(t.cars,`car`);case`settings`:return t.hasSettings?`Saved`:`None saved`;default:return t.present.includes(e)?`Some`:`Nothing`}}function or(){let[e,t]=(0,v.useState)(void 0),[r,i]=(0,v.useState)(null),[a,s]=(0,v.useState)(null),[c,l]=(0,v.useState)(null),[u,d]=(0,v.useState)(()=>window.location.hash),f=tr(u);(0,v.useEffect)(()=>{let e=()=>d(window.location.hash);return window.addEventListener(`hashchange`,e),()=>window.removeEventListener(`hashchange`,e)},[]),(0,v.useEffect)(()=>{document.title=er[f].title,nr(window.location.hash)&&window.scrollTo(0,0)},[f]);let m=(0,v.useCallback)(async()=>{let[e,n]=await Promise.all([p(),Me()]);t(e),i(n)},[]);(0,v.useEffect)(()=>{m();let e=(e,t)=>{t===`local`&&m()};return n.storage.onChanged.addListener(e),()=>n.storage.onChanged.removeListener(e)},[m]);let h=async e=>{await Ne(e),s(null),l(e.length>1?`Everything Lens kept is gone.`:`${y.find(t=>t.id===e[0])?.title} — deleted.`),await m()},ee=async()=>{await o(null),await n.runtime.sendMessage({type:`OPEN_LENS_ON_FINN`,url:null})},_=e?re(e.understanding):null,ie=y.filter(e=>e.id!==`leftovers`||r?.present.includes(`leftovers`));return(0,b.jsxs)(`main`,{className:`min-h-screen bg-finn-snow font-sans text-finn-black`,children:[(0,b.jsxs)(`header`,{className:`bg-gradient-to-br from-finn-highlight-navy to-finn-accent-blue text-white`,children:[(0,b.jsxs)(`div`,{className:`mx-auto flex max-w-3xl items-center gap-4 px-6 pt-8 pb-5`,children:[(0,b.jsx)(`span`,{className:`flex h-14 w-14 items-center justify-center rounded-full bg-white shadow-sm`,children:(0,b.jsx)(`img`,{src:`/icon/128.png`,alt:``,className:`h-12 w-12 object-contain ${ue}`})}),(0,b.jsxs)(`div`,{children:[(0,b.jsxs)(`h1`,{className:`flex items-center gap-2 text-[24px] font-black leading-tight tracking-tight`,children:[er[f].title,(0,b.jsx)(g,{className:`text-[11px]`})]}),(0,b.jsx)(`p`,{className:`text-[13px] text-white/75`,children:er[f].description})]})]}),(0,b.jsxs)(`nav`,{"aria-label":`Finn Lens`,className:`mx-auto flex max-w-3xl flex-wrap gap-2 px-6 pb-5`,children:[(0,b.jsx)(sr,{href:`#settings`,current:f===`settings`,children:`Settings`}),(0,b.jsx)(sr,{href:`#guide`,current:f===`guide`,children:`Beta guide`}),(0,b.jsx)(sr,{href:`#demo`,current:f===`demo`,children:`Product demo`}),(0,b.jsx)(sr,{href:`#docs`,current:f===`docs`,children:`Documentation`})]})]}),f===`guide`?(0,b.jsx)(`div`,{className:`mx-auto max-w-3xl px-6 py-8`,children:(0,b.jsx)(xn,{version:n.runtime.getManifest().version_name??n.runtime.getManifest().version})}):f===`demo`?(0,b.jsx)(`div`,{className:`mx-auto max-w-3xl px-6 py-8`,children:(0,b.jsx)(qn,{release:n.runtime.getManifest().version})}):f===`docs`?(0,b.jsx)(`div`,{className:`mx-auto max-w-3xl px-6 py-8`,children:(0,b.jsx)(vn,{hash:u})}):(0,b.jsxs)(`div`,{className:`mx-auto max-w-3xl space-y-6 px-6 py-8`,children:[(0,b.jsx)(pn,{icon:(0,b.jsx)(Ee,{}),eyebrow:`Settings`,title:`Your answers and your data`,children:(0,b.jsx)(`p`,{children:`The answers new chats start from, and everything Lens keeps in this browser: what it is, how much, and a way to delete any of it. Nothing here is sent anywhere.`})}),c?(0,b.jsx)(`p`,{role:`status`,className:`rounded-2xl bg-finn-fit-good-pale px-4 py-3 text-[13px] font-bold text-finn-fit-good`,children:c}):null,(0,b.jsx)(x,{icon:(0,b.jsx)(ce,{className:`h-5 w-5`}),title:`Your answers`,subtitle:`What new chats start from. You change them by talking to Lens, not here.`,children:e===void 0?null:_?(0,b.jsxs)(b.Fragment,{children:[_.bubbles?.length?(0,b.jsx)(`ul`,{className:`mb-3 space-y-2 rounded-2xl bg-white p-4 ring-1 ring-finn-cotton`,children:_.bubbles.map(e=>(0,b.jsxs)(`li`,{children:[(0,b.jsxs)(`p`,{className:`flex items-baseline gap-2 text-[13.5px] font-black`,children:[e.heading,e.counting===!1?null:(0,b.jsx)(ne,{importance:e.importance,guess:!e.importanceSaid})]}),e.figure||e.counts.length||e.shared?.length?(0,b.jsxs)(`p`,{className:`text-[12px] text-finn-iron`,children:[`Lens checks:`,` `,[e.figure,...e.counts.map(e=>e.label),...(e.shared??[]).map(e=>e.label)].filter(Boolean).join(` · `)]}):e.settled||e.empty?(0,b.jsx)(`p`,{className:`text-[12px] text-finn-iron`,children:e.settled??e.empty}):null]},e.id))}):null,_.needs?.length?(0,b.jsx)(`ul`,{className:`mb-3 space-y-2 rounded-2xl bg-white p-4 ring-1 ring-finn-cotton`,children:_.needs.map(e=>(0,b.jsxs)(`li`,{children:[(0,b.jsxs)(`p`,{className:`flex items-baseline gap-2 text-[13.5px] font-black`,children:[e.label,(0,b.jsx)(ne,{importance:e.importance})]}),e.looksFor.length?(0,b.jsxs)(`p`,{className:`text-[12px] text-finn-iron`,children:[`Lens looks for:`,` `,e.looksFor.join(` · `)]}):null]},e.id))}):null,_.bubbles?.some(e=>e.counting!==!1)||_.needs?.length?(0,b.jsx)(`div`,{className:`mb-3`,children:(0,b.jsx)(te,{guesses:!!_.bubbles?.some(e=>e.counting!==!1&&!e.importanceSaid)})}):null,(0,b.jsx)(`dl`,{className:`divide-y divide-finn-cotton overflow-hidden rounded-2xl ring-1 ring-finn-cotton`,children:_.lines.map(t=>(0,b.jsxs)(`div`,{className:`grid grid-cols-[150px_1fr] gap-4 bg-white px-4 py-3 text-[13px]`,children:[(0,b.jsx)(`dt`,{className:`font-bold text-finn-iron`,children:t.label}),(0,b.jsx)(`dd`,{className:`font-semibold`,children:t.label===`For`&&e?.rentalMonths?`${e?.rentalMonths} months, from the month after you start a chat`:t.value})]},t.label))}),(0,b.jsxs)(`p`,{className:`mt-2 text-[12px] text-finn-iron`,children:[`Saved `,ir(e?.savedAt??``),`.`]}),(0,b.jsxs)(`div`,{className:`mt-4 flex flex-wrap gap-2`,children:[(0,b.jsx)(lr,{onClick:()=>void ee(),children:`Change them in a chat`}),(0,b.jsx)(ur,{onClick:()=>s([`settings`]),children:`Forget my answers`})]})]}):(0,b.jsxs)(`div`,{children:[(0,b.jsxs)(`p`,{className:`text-[13px] leading-relaxed`,children:[`You haven't saved any answers yet. When a chat asks `,(0,b.jsx)(`em`,{children:`“Shall I keep these as your settings?”`}),`, choosing `,(0,b.jsx)(`strong`,{children:`Save as my settings`}),` keeps them here, and every new chat starts from them.`]}),(0,b.jsx)(`div`,{className:`mt-4`,children:(0,b.jsx)(lr,{onClick:()=>void ee(),children:`Start a chat on finn.com`})})]})}),(0,b.jsxs)(x,{icon:(0,b.jsx)(ge,{className:`h-5 w-5`}),title:`Your data`,subtitle:r?`Lens keeps about ${r.kilobytes.toLocaleString(`en-GB`)} kB in this browser. None of it is sent anywhere.`:`Everything Lens keeps in this browser.`,children:[(0,b.jsx)(`ul`,{className:`space-y-2`,children:ie.map(e=>(0,b.jsx)(`li`,{className:`rounded-2xl bg-white p-4 ring-1 ring-finn-cotton`,children:a?.length===1&&a[0]===e.id?(0,b.jsx)(cr,{title:`Delete “${e.title.charAt(0).toLowerCase()}${e.title.slice(1)}”?`,body:e.consequence,onConfirm:()=>void h([e.id]),onCancel:()=>s(null)}):(0,b.jsxs)(`div`,{className:`flex items-start gap-4`,children:[(0,b.jsxs)(`div`,{className:`min-w-0 flex-1`,children:[(0,b.jsxs)(`p`,{className:`flex items-baseline gap-2 text-[14px] font-black`,children:[e.title,(0,b.jsx)(`span`,{className:`text-[12px] font-bold text-finn-iron`,children:ar(e.id,r)})]}),(0,b.jsx)(`p`,{className:`mt-0.5 text-[12.5px] leading-snug text-finn-iron`,children:e.description})]}),(0,b.jsxs)(`button`,{type:`button`,onClick:()=>s([e.id]),disabled:!r?.present.includes(e.id),className:`inline-flex shrink-0 items-center gap-1.5 rounded-full bg-finn-cotton px-3.5 py-2 text-[12px] font-black text-finn-black transition-colors hover:bg-finn-fit-limited-pale hover:text-finn-fit-limited disabled:cursor-default disabled:opacity-40 disabled:hover:bg-finn-cotton disabled:hover:text-finn-black`,children:[(0,b.jsx)(se,{"aria-hidden":`true`,className:`h-3.5 w-3.5`}),e.id===`cars`?`Clear the cache`:`Delete`]})]})},e.id))}),(0,b.jsx)(`div`,{className:`mt-4 rounded-2xl border border-dashed border-finn-fit-limited/30 p-4`,children:a&&a.length>1?(0,b.jsx)(cr,{title:`Delete everything Lens keeps?`,body:`Every chat, your saved answers and the cars Lens has read. Lens will greet you like it's the first time.`,onConfirm:()=>void h(y.map(e=>e.id)),onCancel:()=>s(null)}):(0,b.jsxs)(`div`,{className:`flex items-center gap-4`,children:[(0,b.jsx)(`p`,{className:`min-w-0 flex-1 text-[12.5px] text-finn-iron`,children:`Start over completely: every chat, your answers, and the cars Lens has read.`}),(0,b.jsx)(`button`,{type:`button`,onClick:()=>s(y.map(e=>e.id)),className:`shrink-0 rounded-full bg-finn-fit-limited-pale px-4 py-2 text-[12px] font-black text-finn-fit-limited hover:bg-finn-fit-limited hover:text-white`,children:`Delete everything`})]})})]}),(0,b.jsx)(x,{icon:(0,b.jsx)(ae,{className:`h-5 w-5`}),title:`About Finn Lens`,children:(0,b.jsxs)(`ul`,{className:`space-y-2 text-[13px] leading-relaxed`,children:[(0,b.jsxs)(`li`,{children:[`Lens is `,(0,b.jsx)(`strong`,{children:`unofficial`}),`: it isn't made by, or affiliated with,`,` `,(0,b.jsx)(`a`,{href:le,target:`_blank`,rel:`noopener noreferrer`,className:`font-bold text-finn-accent-blue underline underline-offset-2`,children:`FINN`}),`.`]}),(0,b.jsx)(`li`,{children:`It only works on finn.com. It reads FINN's car data: what FINN's pages load as you browse, and FINN's own API for cars on the page it doesn't have yet.`}),(0,b.jsx)(`li`,{children:`Everything it keeps stays in this browser, and nothing you tell it leaves it. There's no account and no Lens server: its only requests are to finn.com for car data, and for the car photos FINN's data links to.`}),(0,b.jsxs)(`li`,{children:[`New to Lens? The`,` `,(0,b.jsx)(`a`,{href:`#guide`,className:`font-bold text-finn-accent-blue underline underline-offset-2`,children:`beta guide`}),` `,`says what it does, how it decides, and what this beta can't do yet.`]})]})})]})]})}function sr({href:e,current:t,children:n}){return(0,b.jsx)(`a`,{href:e,"aria-current":t?`page`:void 0,className:`whitespace-nowrap rounded-full px-4 py-2 text-[13px] font-black transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white ${t?`bg-white text-finn-highlight-navy`:`bg-white/10 text-white ring-1 ring-white/25 hover:bg-white/20`}`,children:n})}function cr({title:e,body:t,onConfirm:n,onCancel:r}){return(0,b.jsxs)(`div`,{role:`alertdialog`,"aria-label":e,children:[(0,b.jsx)(`p`,{className:`text-[14px] font-black`,children:e}),(0,b.jsx)(`p`,{className:`mt-0.5 text-[12.5px] text-finn-iron`,children:t}),(0,b.jsxs)(`div`,{className:`mt-3 flex gap-2`,children:[(0,b.jsx)(`button`,{type:`button`,onClick:n,className:`rounded-full bg-finn-fit-limited px-4 py-2 text-[12px] font-black text-white hover:opacity-90`,children:`Delete`}),(0,b.jsx)(ur,{onClick:r,children:`Keep it`})]})]})}function lr({onClick:e,children:t}){return(0,b.jsx)(`button`,{type:`button`,onClick:e,className:`rounded-full bg-finn-accent-blue px-4 py-2.5 text-[13px] font-black text-white transition-colors hover:bg-finn-highlight-navy`,children:t})}function ur({onClick:e,children:t}){return(0,b.jsx)(`button`,{type:`button`,onClick:e,className:`rounded-full bg-finn-cotton px-4 py-2.5 text-[13px] font-black text-finn-black transition-colors hover:bg-finn-pale-blue hover:text-finn-accent-blue`,children:t})}var dr=document.getElementById(`root`);if(!dr)throw Error(`Root element not found`);je.createRoot(dr).render((0,b.jsx)(v.StrictMode,{children:(0,b.jsx)(a,{children:(0,b.jsx)(or,{})})}));